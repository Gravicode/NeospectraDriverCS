package sws.p2AppManager;

import java.util.Observable;
import java.util.Observer;
import sws.p2AppManager.utils.p2Enumerations;

public abstract class p2AppManager extends Observable implements Observer {
  public abstract void setWorkingDirectory(String paramString);
  
  public abstract String getWorkingDirectory();
  
  public abstract String getDeviceId();
  
  public abstract String getSDKVersion();
  
  public abstract p2Enumerations.p2AppManagerStatus initializeCore(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus checkDeviceStatus(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runSpec(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus wavelengthCalibration(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus wavelengthCalibrationBG(String... paramVarArgs);
  
  public abstract double[][] getSpecData();
  
  public abstract double getErrorData();
  
  public abstract p2Enumerations.p2AppManagerStatus runInterSpecDSP(double[][] paramArrayOfDouble, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runInterSpec(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus updateFFT_SettingsInterSpec(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus updateFFT_SettingsSpec(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus saveInterSpecGainSettings(String paramString, double[][] paramArrayOfDouble);
  
  public abstract p2Enumerations.p2AppManagerStatus saveSpecGainSettings(String paramString, double[][] paramArrayOfDouble);
  
  public abstract p2Enumerations.p2AppManagerStatus runSNR(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runStability(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runCalibCorr(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runInterSpecGainAdj(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runSpecGainAdjBG(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runSpecGainAdjSample(String... paramVarArgs);
  
  public abstract double[][] getRawData();
  
  public abstract double[][] getInterSpecData();
  
  public abstract double[][] getGainAdjustInterSpecData();
  
  public abstract double[][] getGainAdjustSpecData();
  
  public abstract double[][] getSNR_Data();
  
  public abstract double[][] getStabilityData();
  
  public abstract p2Enumerations.p2AppManagerStatus runCapTime_Calibration(String... paramVarArgs);
  
  public abstract double[][] getCapTimeData();
  
  public abstract p2Enumerations.p2AppManagerStatus runDelayCompensation_Calibration(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus runCalibrationCore_Calibration(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus generateCalibration(String... paramVarArgs);
  
  public abstract double[][] getCalibrationData();
  
  public abstract p2Enumerations.p2AppManagerStatus runCapCurrent(String... paramVarArgs);
  
  public abstract double[][] getCapCurrentData();
  
  public abstract p2Enumerations.p2AppManagerStatus switchDevice(String... paramVarArgs);
  
  public abstract void setSettings(String... paramVarArgs);
  
  public abstract void setOpticalSettings(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus burnSampleID(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus burnSampleFolders(String[] paramArrayOfString);
  
  public abstract p2Enumerations.p2AppManagerStatus restoreDefaultSettings(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus burnSettings(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus burnSpecificSettings(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus readSampleFolders(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus readTemp(String... paramVarArgs);
  
  public abstract double[][] getTempData();
  
  public abstract p2Enumerations.p2AppManagerStatus readASICRegisters(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus writeASICRegisters(long[] paramArrayOfLong);
  
  public abstract long[] getASICRegisters();
  
  public abstract p2Enumerations.p2AppManagerStatus calculateResponse_ClosedLoop(String... paramVarArgs);
  
  public abstract double[][] getResponseData();
  
  public abstract p2Enumerations.p2AppManagerStatus calculateParameters_ClosedLoop(String... paramVarArgs);
  
  public abstract double[][] getParametersData();
  
  public abstract p2Enumerations.p2AppManagerStatus CoefficientsTrimming_ClosedLoop(String... paramVarArgs);
  
  public abstract double[][] getCoefficientsTrimmingData();
  
  public abstract p2Enumerations.p2AppManagerStatus PhaseTrimming_ClosedLoop(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus PhaseTrimmingFast_ClosedLoop(String... paramVarArgs);
  
  public abstract double[][] getPhaseTrimmingData();
  
  public abstract p2Enumerations.p2AppManagerStatus StabilityCheck_ClosedLoop(String... paramVarArgs);
  
  public abstract double[][] getStabilityCheckData();
  
  public abstract p2Enumerations.p2AppManagerStatus WaveformPreview_ClosedLoop(String... paramVarArgs);
  
  public abstract double[][] getWaveformPreviewData();
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\p2AppManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */