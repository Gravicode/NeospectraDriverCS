package sws.p2AppManager.dspAPI;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import sws.p2AppManager.utils.p2Constants;

public class p2SpectroDSP {
  public static String a = "DSP_Pre_Interferogram_param_conf.in";
  
  public static String b = "DSP_Post_Calib_wl_calib_data.out";
  
  private static p2SpectroDSP f;
  
  private static boolean g = false;
  
  public static final int c = 4;
  
  public static final int d = 17;
  
  public static final int e = 22;
  
  private boolean h = true;
  
  private p2SpectroDSP() {
    try {
      spectro_spectrometerDSP_init();
    } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
      System.out.println("UnsatisfiedLinkError error in spectrometerDSP_init()");
    } 
  }
  
  public static p2SpectroDSP a() {
    if (f == null)
      f = new p2SpectroDSP(); 
    return f;
  }
  
  private native boolean spectro_spectrometerDSP_init();
  
  private native boolean spectrometerDSP_clean();
  
  private native boolean interferogram_initialization(double[] paramArrayOfDouble1, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, double[] paramArrayOfDouble2, int paramInt2);
  
  private native boolean interferogram_preprocessing(int paramInt1, int paramInt2, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4);
  
  private native boolean interferogram_capToDistance(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, int paramInt, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5);
  
  private native boolean interferogram_interpolation(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6);
  
  private native int interferogram_findLPF_Length();
  
  private native int interferogram_findLPF_Index();
  
  private native boolean interferogram_removeMovingAverage(double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4);
  
  private native boolean interferogram_wavelengthSelfCorrection(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, int[] paramArrayOfInt1, int[] paramArrayOfInt2, double[] paramArrayOfDouble7);
  
  private native int interferogram_apodizationGetSize();
  
  private native int interferogram_findFFT_Length(int paramInt1, int paramInt2);
  
  private native boolean interferogram_apodization(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt, double[] paramArrayOfDouble3);
  
  private native boolean interferogram_powerSpectralDensityCalculation(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, int[] paramArrayOfInt);
  
  private native boolean interferogram_integration(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, double[] paramArrayOfDouble3, int paramInt3, double[] paramArrayOfDouble4, int paramInt4, int paramInt5, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, int paramInt6, int paramInt7, int paramInt8, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8, double[] paramArrayOfDouble9, double[] paramArrayOfDouble10, double[] paramArrayOfDouble11, double[] paramArrayOfDouble12, int[] paramArrayOfInt1, double[] paramArrayOfDouble13, double[] paramArrayOfDouble14, double[] paramArrayOfDouble15, double[] paramArrayOfDouble16, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  private native boolean interferogram_endFFT(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, int paramInt3, double[] paramArrayOfDouble5, int paramInt4, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8);
  
  private native boolean capInterp(double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8, double[] paramArrayOfDouble9);
  
  private native boolean delayCompSearching(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt1, double[] paramArrayOfDouble3, int paramInt2, double[] paramArrayOfDouble4, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, int paramInt6, int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean);
  
  private native boolean SpectrometerDSP_Calib(double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, int paramInt3, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, int paramInt4, double[] paramArrayOfDouble7, int paramInt5, double[] paramArrayOfDouble8, int paramInt6, double[] paramArrayOfDouble9, int paramInt7, double[] paramArrayOfDouble10, int paramInt8, double[] paramArrayOfDouble11, int paramInt9, double paramDouble1, double paramDouble2, double paramDouble3, boolean paramBoolean1, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, int paramInt10, int paramInt11, double paramDouble8, boolean paramBoolean2, double[] paramArrayOfDouble12, int paramInt12, int paramInt13, int paramInt14, int paramInt15, double[] paramArrayOfDouble13, double[] paramArrayOfDouble14, double[] paramArrayOfDouble15, double[] paramArrayOfDouble16, double[] paramArrayOfDouble17, double[] paramArrayOfDouble18, int[] paramArrayOfInt, double[] paramArrayOfDouble19, double[] paramArrayOfDouble20);
  
  private native boolean SpectrometerDSP_capAndCurrent(double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, double[] paramArrayOfDouble3, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8, double[] paramArrayOfDouble9, double[] paramArrayOfDouble10, double[] paramArrayOfDouble11, double[] paramArrayOfDouble12, double[] paramArrayOfDouble13);
  
  private native boolean abstractClosedLoop_closedLoop_initialization(double[] paramArrayOfDouble, int paramInt);
  
  private native boolean abstractClosedLoop_closedLoop_capAmpCalc(double[] paramArrayOfDouble1, int paramInt, double[] paramArrayOfDouble2);
  
  private native boolean abstractClosedLoop_closedLoop_signalPreprocessing(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double[] paramArrayOfDouble);
  
  private native boolean abstractClosedLoop_closedLoop_memsParametersDetection(double[] paramArrayOfDouble1, int paramInt, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
  
  private native boolean abstractClosedLoop_closedLoop_fwdGainCalc(double[] paramArrayOfDouble1, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double[] paramArrayOfDouble2);
  
  private native boolean abstractClosedLoop_closedLoop_loopCoefficientsCalc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt, double paramDouble5, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8, double[] paramArrayOfDouble9, double[] paramArrayOfDouble10, double[] paramArrayOfDouble11, double[] paramArrayOfDouble12, double[] paramArrayOfDouble13, double[] paramArrayOfDouble14, double[] paramArrayOfDouble15, double[] paramArrayOfDouble16);
  
  private native boolean abstractClosedLoop_closedLoop_phaseConversion(double paramDouble1, double paramDouble2, double[] paramArrayOfDouble);
  
  private native boolean abstractClosedLoop_closedLoop_phaseValidation(double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, double paramDouble, double[] paramArrayOfDouble3);
  
  private native boolean abstractClosedLoop_closedLoop_optimumPhaseDetection(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, int paramInt, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, int[] paramArrayOfInt, double[] paramArrayOfDouble6);
  
  private native boolean abstractClosedLoop_closedLoop_optimumPhaseDetectionFast(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, int[] paramArrayOfInt, double[] paramArrayOfDouble5);
  
  private native boolean abstractClosedLoop_closedLoop_settingsCheck(double[] paramArrayOfDouble1, int paramInt1, double[] paramArrayOfDouble2, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8, double[] paramArrayOfDouble9);
  
  private native boolean abstractClosedLoop_closedLoop_calculateKdigFromRegisterValue(double paramDouble, double[] paramArrayOfDouble);
  
  private native boolean abstractClosedLoop_closedLoop_gainMarginCalc(double[] paramArrayOfDouble1, int paramInt1, double paramDouble1, int paramInt2, double paramDouble2, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6);
  
  private native boolean interferogram_SNR_Measurement(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt3, double paramDouble4, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8, double[] paramArrayOfDouble9, double[] paramArrayOfDouble10, double[] paramArrayOfDouble11, double[] paramArrayOfDouble12, double[] paramArrayOfDouble13, double[] paramArrayOfDouble14, double[] paramArrayOfDouble15, double[] paramArrayOfDouble16, double[] paramArrayOfDouble17, double[] paramArrayOfDouble18, double[] paramArrayOfDouble19);
  
  private native boolean interferogram_wavelengthCorrect(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt1, double[] paramArrayOfDouble3, int paramInt2, int paramInt3, int paramInt4, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5);
  
  private native boolean interferogram_repeatabilityAndStability(double[] paramArrayOfDouble1, int paramInt1, int paramInt2, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, int paramInt3, int paramInt4, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8);
  
  private native boolean interferogram_commonWavenumberGeneration(double paramDouble1, double paramDouble2, int paramInt1, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4);
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, int paramInt, double[] paramArrayOfDouble4) throws a {
    try {
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_UpdateFFT_param_conf.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_UpdateFFT_X_Vector.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_UpdateFFT_I_Vector.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          bufferedWriter.write(paramArrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_UpdateFFT_normalizeSpectrum.in"));
        bufferedWriter.write(paramInt + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_UpdateFFT_INT_wl_corr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble4.length; b1++)
          bufferedWriter.write(paramArrayOfDouble4[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      int i = interferogram_findFFT_Length((int)paramArrayOfDouble1[22], (int)paramArrayOfDouble1[17]);
      int j = i / 2;
      double[] arrayOfDouble1 = new double[j];
      double[] arrayOfDouble2 = new double[j];
      int[] arrayOfInt = { 0 };
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      if (paramInt == 1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      boolean bool4 = interferogram_initialization(paramArrayOfDouble1, paramArrayOfDouble1.length, bool1, bool2, bool3, paramArrayOfDouble4, paramArrayOfDouble4.length);
      if (bool4 == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in interferogram_initialization function! Please contact your vendor for support.");
      } 
      double[] arrayOfDouble3 = new double[paramArrayOfDouble2.length];
      bool4 = interferogram_apodization(paramArrayOfDouble2, paramArrayOfDouble3, paramArrayOfDouble2.length, arrayOfDouble3);
      if (bool4 == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in interferogram_apodization function! Please contact your vendor for support.");
      } 
      bool4 = interferogram_powerSpectralDensityCalculation(paramArrayOfDouble2, arrayOfDouble3, paramArrayOfDouble2.length, arrayOfDouble1, arrayOfDouble2, arrayOfInt);
      if (bool4 == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in interferogram_powerSpectralDensityCalculation function! Please contact your vendor for support.");
      } 
      arrayOfDouble3 = null;
      double[][] arrayOfDouble = new double[2][];
      arrayOfDouble[0] = new double[arrayOfInt[0]];
      System.arraycopy(arrayOfDouble1, 0, arrayOfDouble[0], 0, arrayOfInt[0]);
      arrayOfDouble[1] = new double[arrayOfInt[0]];
      System.arraycopy(arrayOfDouble2, 0, arrayOfDouble[1], 0, arrayOfInt[0]);
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_UpdateFFT_v.out"));
        for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
          bufferedWriter.write(arrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_UpdateFFT_b.out"));
        for (byte b1 = 0; b1 < arrayOfDouble2.length; b1++)
          bufferedWriter.write(arrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      arrayOfDouble1 = null;
      arrayOfDouble2 = null;
      arrayOfInt = null;
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, int paramInt5, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8) throws a {
    try {
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + a));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_INT_noSlices.in"));
        bufferedWriter.write(paramInt1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_INT_avgShiftBits.in"));
        bufferedWriter.write(paramInt2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_c2x_cal.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_opticalLPF1.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          bufferedWriter.write(paramArrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_opticalLPF2.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble4.length; b1++)
          bufferedWriter.write(paramArrayOfDouble4[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_wl_corr_cal.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble5.length; b1++)
          bufferedWriter.write(paramArrayOfDouble5[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_corr_cal.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble6.length; b1++)
          bufferedWriter.write(paramArrayOfDouble6[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_INT_Corrected_Uncorrected.in"));
        bufferedWriter.write(paramInt5 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_I_sliceWhiteNeg.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble7.length; b1++)
          bufferedWriter.write(paramArrayOfDouble7[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_I_sliceWhitePos.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble8.length; b1++)
          bufferedWriter.write(paramArrayOfDouble8[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      int i = interferogram_findFFT_Length((int)paramArrayOfDouble1[22], (int)paramArrayOfDouble1[17]);
      int j = i / 2;
      double[] arrayOfDouble1 = new double[(int)paramArrayOfDouble1[17]];
      double[] arrayOfDouble2 = new double[(int)paramArrayOfDouble1[17]];
      double[] arrayOfDouble3 = new double[(int)paramArrayOfDouble1[17]];
      double[] arrayOfDouble4 = new double[j];
      double[] arrayOfDouble5 = new double[j];
      double[] arrayOfDouble6 = new double[j];
      double[] arrayOfDouble7 = new double[j];
      int[] arrayOfInt1 = { 0 };
      int[] arrayOfInt2 = { 0 };
      int[] arrayOfInt3 = { 0 };
      int[] arrayOfInt4 = { 0 };
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      if (paramInt4 == 1) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      if (paramInt3 == 1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Interferogram_uiConf.in"));
        bufferedWriter.write("0\n");
        bufferedWriter.write("0\n");
        bufferedWriter.write(bool1 + "\n");
        bufferedWriter.write(bool2 + "\n");
        bufferedWriter.write(bool3 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      double[] arrayOfDouble8 = { paramArrayOfDouble6[0] };
      double[] arrayOfDouble9 = { paramArrayOfDouble6[1] };
      boolean bool4 = interferogram_integration(bool1, bool2, bool3, paramArrayOfDouble2, paramArrayOfDouble2.length, paramArrayOfDouble5, paramArrayOfDouble5.length, paramArrayOfDouble3, paramArrayOfDouble3.length, paramArrayOfDouble4, paramArrayOfDouble4.length, paramArrayOfDouble1.length, paramArrayOfDouble7, paramArrayOfDouble8, paramArrayOfDouble7.length, paramInt1, paramInt2, paramArrayOfDouble1, arrayOfDouble8, arrayOfDouble9, arrayOfDouble1, arrayOfDouble2, arrayOfDouble3, arrayOfInt1, arrayOfDouble4, arrayOfDouble5, arrayOfDouble6, arrayOfDouble7, arrayOfInt2, arrayOfInt3, arrayOfInt4);
      paramArrayOfDouble6[0] = arrayOfDouble8[0];
      paramArrayOfDouble6[1] = arrayOfDouble9[0];
      if (bool4 == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in interferogram_integration function! Please contact your vendor for support.");
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_corr_cal.out"));
        for (byte b1 = 0; b1 < paramArrayOfDouble6.length; b1++)
          bufferedWriter.write(paramArrayOfDouble6[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_xs.out"));
        for (byte b1 = 0; b1 < arrayOfInt1[0]; b1++)
          bufferedWriter.write(arrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_Is_intensityVector.out"));
        for (byte b1 = 0; b1 < arrayOfInt1[0]; b1++)
          bufferedWriter.write(arrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_I_lin_intensityVectorCorrected.out"));
        for (byte b1 = 0; b1 < arrayOfInt1[0]; b1++)
          bufferedWriter.write(arrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_intensityVectorCorrectedLength.out"));
        bufferedWriter.write(arrayOfInt1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_powerSpectralVectorsLength.out"));
        bufferedWriter.write(arrayOfInt2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_leftZeros"));
        bufferedWriter.write(arrayOfInt3[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_rightZeros"));
        bufferedWriter.write(arrayOfInt4[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_v_waveNumberVector.out"));
        for (byte b1 = 0; b1 < arrayOfInt2[0]; b1++)
          bufferedWriter.write(arrayOfDouble4[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_v_lin_waveNumberVectorCorrected.out"));
        for (byte b1 = 0; b1 < arrayOfInt2[0]; b1++)
          bufferedWriter.write(arrayOfDouble5[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_B_powerSpectralDensity.out"));
        for (byte b1 = 0; b1 < arrayOfInt2[0]; b1++)
          bufferedWriter.write(arrayOfDouble6[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Interferogram_B_lin_powerSpectralDensityCorrected.out"));
        for (byte b1 = 0; b1 < arrayOfInt2[0]; b1++)
          bufferedWriter.write(arrayOfDouble7[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      double[][] arrayOfDouble = new double[5][];
      arrayOfDouble[0] = new double[arrayOfInt1[0]];
      System.arraycopy(arrayOfDouble1, 0, arrayOfDouble[0], 0, arrayOfInt1[0]);
      arrayOfDouble[1] = new double[arrayOfInt1[0]];
      arrayOfDouble[3] = new double[arrayOfInt2[0]];
      arrayOfDouble[2] = new double[arrayOfInt2[0]];
      if (paramInt5 == 0) {
        System.arraycopy(arrayOfDouble3, 0, arrayOfDouble[1], 0, arrayOfInt1[0]);
        System.arraycopy(arrayOfDouble7, 0, arrayOfDouble[3], 0, arrayOfInt2[0]);
      } else {
        System.arraycopy(arrayOfDouble2, 0, arrayOfDouble[1], 0, arrayOfInt1[0]);
        System.arraycopy(arrayOfDouble6, 0, arrayOfDouble[3], 0, arrayOfInt2[0]);
      } 
      System.arraycopy(arrayOfDouble5, 0, arrayOfDouble[2], 0, arrayOfInt2[0]);
      arrayOfDouble[4] = paramArrayOfDouble6;
      arrayOfDouble1 = null;
      arrayOfDouble2 = null;
      arrayOfDouble3 = null;
      arrayOfDouble4 = null;
      arrayOfDouble5 = null;
      arrayOfDouble6 = null;
      arrayOfDouble7 = null;
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble, double[][] paramArrayOfDouble1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt, double paramDouble4) throws a {
    try {
      double[] arrayOfDouble1 = new double[paramArrayOfDouble1.length * paramArrayOfDouble.length];
      double[] arrayOfDouble2 = new double[paramArrayOfDouble.length];
      double[] arrayOfDouble3 = new double[paramArrayOfDouble.length * (paramArrayOfDouble1.length - 1)];
      double[] arrayOfDouble4 = new double[paramArrayOfDouble.length];
      double[] arrayOfDouble5 = new double[1];
      double[] arrayOfDouble6 = new double[1];
      double[] arrayOfDouble7 = new double[1];
      double[] arrayOfDouble8 = new double[1];
      double[] arrayOfDouble9 = new double[1];
      double[] arrayOfDouble10 = new double[1];
      double[] arrayOfDouble11 = new double[1];
      double[] arrayOfDouble12 = new double[1];
      double[] arrayOfDouble13 = new double[1];
      double[] arrayOfDouble14 = new double[1];
      double[] arrayOfDouble15 = new double[1];
      double[] arrayOfDouble16 = new double[1];
      double[] arrayOfDouble17 = new double[1];
      double[] arrayOfDouble18 = new double[1];
      for (i = 0; i < paramArrayOfDouble1.length; i++)
        System.arraycopy(paramArrayOfDouble1[i], 0, arrayOfDouble1, i * paramArrayOfDouble1[i].length, paramArrayOfDouble1[i].length); 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_SNR_waveNumVector_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
          bufferedWriter.write(paramArrayOfDouble[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_SNR_spectrumArray_Ptr.in"));
        for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
          bufferedWriter.write(arrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_SNR_lambdaMin.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_SNR_lambdaMax.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_SNR_scanningWindowSize.in"));
        bufferedWriter.write(paramDouble3 + "\n");
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_SNR_noRefWavelengths.in"));
        bufferedWriter.write(paramInt + "\n");
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      boolean bool = interferogram_SNR_Measurement(paramArrayOfDouble, arrayOfDouble1, arrayOfDouble1.length / paramArrayOfDouble.length, paramArrayOfDouble.length, paramDouble1, paramDouble2, paramDouble3, paramInt, paramDouble4, arrayOfDouble2, arrayOfDouble3, arrayOfDouble4, arrayOfDouble5, arrayOfDouble6, arrayOfDouble7, arrayOfDouble8, arrayOfDouble9, arrayOfDouble10, arrayOfDouble11, arrayOfDouble12, arrayOfDouble13, arrayOfDouble14, arrayOfDouble15, arrayOfDouble16, arrayOfDouble17, arrayOfDouble18);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in interferogram_SNR_Measurement function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[17][];
      arrayOfDouble[0] = arrayOfDouble2;
      arrayOfDouble[1] = arrayOfDouble3;
      arrayOfDouble[2] = arrayOfDouble4;
      arrayOfDouble[3] = arrayOfDouble5;
      arrayOfDouble[4] = arrayOfDouble6;
      arrayOfDouble[5] = arrayOfDouble7;
      arrayOfDouble[6] = arrayOfDouble8;
      arrayOfDouble[7] = arrayOfDouble9;
      arrayOfDouble[8] = arrayOfDouble10;
      arrayOfDouble[9] = arrayOfDouble11;
      arrayOfDouble[10] = arrayOfDouble12;
      arrayOfDouble[11] = arrayOfDouble13;
      arrayOfDouble[12] = arrayOfDouble14;
      arrayOfDouble[13] = arrayOfDouble15;
      arrayOfDouble[14] = arrayOfDouble16;
      arrayOfDouble[15] = arrayOfDouble17;
      arrayOfDouble[16] = arrayOfDouble18;
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_SNR_waveLengthOutput_Ptr.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[0].length; b1++)
          bufferedWriter.write(arrayOfDouble[0][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      for (j = 0; j < paramArrayOfDouble1.length - 1; j++) {
        try {
          BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_SNR_lines100[" + j + "]_Ptr.out"));
          for (int k = 0; k < paramArrayOfDouble.length; k++)
            bufferedWriter.write(arrayOfDouble[1][j * paramArrayOfDouble.length + k] + "\n"); 
          bufferedWriter.close();
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_SNR_SNR_Ptr.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[2].length; b1++)
          bufferedWriter.write(arrayOfDouble[2][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException j) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_SNR_outputs.out"));
        bufferedWriter.write("maxSNR_Ptr : " + arrayOfDouble[3][0] + "\n");
        bufferedWriter.write("SNR_AT_2p1_Ptr : " + arrayOfDouble[4][0] + "\n");
        bufferedWriter.write("SNR_AT_1p9_Ptr : " + arrayOfDouble[5][0] + "\n");
        bufferedWriter.write("SNR_Spread_Ptr : " + arrayOfDouble[6][0] + "\n");
        bufferedWriter.write("waveRange_10_dB_Ptr : " + arrayOfDouble[7][0] + "\n");
        bufferedWriter.write("waveRange_3_dB_Ptr : " + arrayOfDouble[8][0] + "\n");
        bufferedWriter.write("waveRange_100_SNR_Ptr : " + arrayOfDouble[9][0] + "\n");
        bufferedWriter.write("lambda_2_10_dB_Ptr : " + arrayOfDouble[10][0] + "\n");
        bufferedWriter.write("lambda_1_10_dB_Ptr : " + arrayOfDouble[11][0] + "\n");
        bufferedWriter.write("lambda_2_3_dB_Ptr : " + arrayOfDouble[12][0] + "\n");
        bufferedWriter.write("lambda_1_3_dB_Ptr : " + arrayOfDouble[13][0] + "\n");
        bufferedWriter.write("lambda_2_100_dB_Ptr : " + arrayOfDouble[14][0] + "\n");
        bufferedWriter.write("lambda_1_100_dB_Ptr : " + arrayOfDouble[15][0] + "\n");
        bufferedWriter.write("PSD_2p1_1p2_Ratio_Ptr : " + arrayOfDouble[16][0] + "\n");
        bufferedWriter.close();
      } catch (IOException j) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[][] paramArrayOfDouble, double[] paramArrayOfDouble2, int paramInt) throws a {
    try {
      double[] arrayOfDouble1 = new double[paramArrayOfDouble.length * paramArrayOfDouble1.length];
      double[] arrayOfDouble2 = new double[paramArrayOfDouble1.length];
      double[] arrayOfDouble3 = new double[paramArrayOfDouble.length];
      double[] arrayOfDouble4 = new double[paramArrayOfDouble2.length * paramArrayOfDouble.length];
      double[] arrayOfDouble5 = new double[paramArrayOfDouble2.length * paramArrayOfDouble.length];
      double[] arrayOfDouble6 = new double[paramArrayOfDouble2.length];
      double[] arrayOfDouble7 = new double[paramArrayOfDouble2.length];
      double[] arrayOfDouble8 = new double[paramArrayOfDouble2.length];
      for (i = 0; i < paramArrayOfDouble.length; i++)
        System.arraycopy(paramArrayOfDouble[i], 0, arrayOfDouble1, i * paramArrayOfDouble[i].length, paramArrayOfDouble[i].length); 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_stability_waveNumVector_Ptr.in"));
        for (byte b2 = 0; b2 < paramArrayOfDouble1.length; b2++)
          bufferedWriter.write(paramArrayOfDouble1[b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_stability_spectrumArray_Ptr.in"));
        for (byte b2 = 0; b2 < arrayOfDouble1.length; b2++)
          bufferedWriter.write(arrayOfDouble1[b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_stability_referenceWavelengths_Ptr.in"));
        for (byte b2 = 0; b2 < paramArrayOfDouble2.length; b2++)
          bufferedWriter.write(paramArrayOfDouble2[b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_stability_wavenumberCorrectionSelection.in"));
        bufferedWriter.write(paramInt + "\n");
        bufferedWriter.close();
      } catch (IOException i) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      boolean bool = interferogram_repeatabilityAndStability(arrayOfDouble1, paramArrayOfDouble.length, paramArrayOfDouble1.length, paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble2.length, paramInt, arrayOfDouble2, arrayOfDouble4, arrayOfDouble5, arrayOfDouble7, arrayOfDouble8);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in interferogram_repeatabilityAndStability function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[8][];
      for (b1 = 0; b1 < paramArrayOfDouble.length; b1++)
        arrayOfDouble3[b1] = (b1 + true); 
      System.arraycopy(paramArrayOfDouble2, 0, arrayOfDouble6, 0, paramArrayOfDouble2.length);
      arrayOfDouble[0] = arrayOfDouble2;
      arrayOfDouble[1] = arrayOfDouble1;
      arrayOfDouble[2] = arrayOfDouble3;
      arrayOfDouble[3] = arrayOfDouble4;
      arrayOfDouble[4] = arrayOfDouble5;
      arrayOfDouble[5] = arrayOfDouble6;
      arrayOfDouble[6] = arrayOfDouble7;
      arrayOfDouble[7] = arrayOfDouble8;
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_stability_waveLengthOutput_Ptr.out"));
        for (byte b2 = 0; b2 < arrayOfDouble[0].length; b2++)
          bufferedWriter.write(arrayOfDouble[0][b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException b1) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_stability_measNum_Ptr.out"));
        for (byte b2 = 0; b2 < arrayOfDouble[2].length; b2++)
          bufferedWriter.write(arrayOfDouble[2][b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException b1) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_stability_lambdaLines_Ptr.out"));
        for (byte b2 = 0; b2 < arrayOfDouble[3].length; b2++)
          bufferedWriter.write(arrayOfDouble[3][b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException b1) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_stability_B_Lines_Ptr.out"));
        for (byte b2 = 0; b2 < arrayOfDouble[4].length; b2++)
          bufferedWriter.write(arrayOfDouble[4][b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException b1) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_stability_wavelengthError_Ptr.out"));
        for (byte b2 = 0; b2 < arrayOfDouble[6].length; b2++)
          bufferedWriter.write(arrayOfDouble[6][b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException b1) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_stability_absorbanceError_Ptr.out"));
        for (byte b2 = 0; b2 < arrayOfDouble[7].length; b2++)
          bufferedWriter.write(arrayOfDouble[7][b2] + "\n"); 
        bufferedWriter.close();
      } catch (IOException b1) {
        IOException iOException;
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, int paramInt1, int paramInt2, int paramInt3, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5) throws a {
    try {
      double[] arrayOfDouble1 = new double[paramArrayOfDouble4.length];
      double[] arrayOfDouble2 = new double[paramArrayOfDouble2.length];
      double[] arrayOfDouble3 = new double[paramArrayOfDouble2.length];
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      if (paramInt3 == 1) {
        bool3 = false;
      } else {
        bool3 = true;
      } 
      if (paramInt2 == 1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      boolean bool4 = interferogram_endFFT(bool1, bool2, bool3, paramArrayOfDouble1, paramArrayOfDouble1.length, paramArrayOfDouble5, paramArrayOfDouble5.length, paramArrayOfDouble2, paramArrayOfDouble3, paramArrayOfDouble2.length, paramArrayOfDouble4, paramArrayOfDouble4.length, arrayOfDouble2, arrayOfDouble3, arrayOfDouble1);
      if (bool4 == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in interferogram_endFFT function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[4][];
      arrayOfDouble[0] = paramArrayOfDouble4;
      arrayOfDouble[1] = arrayOfDouble1;
      arrayOfDouble[2] = arrayOfDouble2;
      arrayOfDouble[3] = arrayOfDouble3;
      arrayOfDouble1 = null;
      arrayOfDouble2 = null;
      arrayOfDouble3 = null;
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt, double paramDouble1, double paramDouble2) throws a {
    try {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      double[] arrayOfDouble3 = new double[1];
      double[] arrayOfDouble4 = new double[1];
      double[] arrayOfDouble5 = new double[1];
      double[] arrayOfDouble6 = new double[1];
      double[] arrayOfDouble7 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_capInterp_xADC_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_capInterp_paramConf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_capInterp_NPS_interpReg.in"));
        bufferedWriter.write(paramInt + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_capInterp_interpThreshold.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_capInterp_interpOffset.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = capInterp(paramArrayOfDouble1, paramArrayOfDouble1.length, paramArrayOfDouble2, paramArrayOfDouble2.length, paramInt, paramDouble1, paramDouble2, arrayOfDouble1, arrayOfDouble2, arrayOfDouble3, arrayOfDouble4, arrayOfDouble5, arrayOfDouble6, arrayOfDouble7);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in capInterp function! Please contact your vendor for support.");
      } 
      double[] arrayOfDouble8 = new double[7];
      arrayOfDouble8[0] = arrayOfDouble1[0];
      arrayOfDouble8[1] = arrayOfDouble2[0];
      arrayOfDouble8[2] = arrayOfDouble3[0];
      arrayOfDouble8[3] = arrayOfDouble4[0];
      arrayOfDouble8[4] = arrayOfDouble5[0];
      arrayOfDouble8[5] = arrayOfDouble6[0];
      arrayOfDouble8[6] = arrayOfDouble7[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_capInterp_threshold1_Ptr.out"));
        bufferedWriter.write(arrayOfDouble1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_capInterp_threshold2_Ptr.out"));
        bufferedWriter.write(arrayOfDouble2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_capInterp_threshold3_Ptr.out"));
        bufferedWriter.write(arrayOfDouble3[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_capInterp_threshold4_Ptr.out"));
        bufferedWriter.write(arrayOfDouble4[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_capInterp_xInitial_Ptr.out"));
        bufferedWriter.write(arrayOfDouble5[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_capInterp_xStep_Ptr.out"));
        bufferedWriter.write(arrayOfDouble6[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_capInterp_xFinal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble7[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble8;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3) throws a {
    try {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      boolean[] arrayOfBoolean = new boolean[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_whiteLightPos.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_whiteLightNeg.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_opticalLPF1_Coeff_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          bufferedWriter.write(paramArrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_opticalLPF2_Coeff_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble4.length; b1++)
          bufferedWriter.write(paramArrayOfDouble4[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_progDlyPrev.in"));
        bufferedWriter.write(paramInt1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_zpdSignPrev.in"));
        bufferedWriter.write(paramInt2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_binarySearch.in"));
        bufferedWriter.write(paramBoolean + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_delay_currentCount.in"));
        bufferedWriter.write(paramInt3 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = delayCompSearching(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble1.length, paramArrayOfDouble3, paramArrayOfDouble3.length, paramArrayOfDouble4, paramArrayOfDouble4.length, paramInt1, paramInt2, paramBoolean, paramInt3, arrayOfInt1, arrayOfInt2, arrayOfBoolean);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in delayCompSearching function! Please contact your vendor for support.");
      } 
      double[] arrayOfDouble = new double[3];
      arrayOfDouble[0] = arrayOfInt1[0];
      arrayOfDouble[1] = arrayOfInt2[0];
      if (arrayOfBoolean[0] == true) {
        arrayOfDouble[2] = 1.0D;
      } else {
        arrayOfDouble[2] = 0.0D;
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_delay_progDlyRegister_Ptr.out"));
        bufferedWriter.write(arrayOfInt1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_delay_zpdSign_Ptr.out"));
        bufferedWriter.write(arrayOfInt2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_delay_compFlag_Ptr.out"));
        bufferedWriter.write(arrayOfBoolean[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, double[] paramArrayOfDouble5, double[] paramArrayOfDouble6, double[] paramArrayOfDouble7, double[] paramArrayOfDouble8, double[] paramArrayOfDouble9, double[] paramArrayOfDouble10, double[] paramArrayOfDouble11, double paramDouble1, double paramDouble2, double paramDouble3, boolean paramBoolean1, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, int paramInt1, int paramInt2, double paramDouble8, double[] paramArrayOfDouble12, boolean paramBoolean2, double[] paramArrayOfDouble13, int paramInt3) throws a {
    try {
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_laserReadingPos_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_laserReadingPosLength.in"));
        bufferedWriter.write(paramArrayOfDouble1.length + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_laserReadingNeg_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_laserReadingNegLength.in"));
        bufferedWriter.write(paramArrayOfDouble2.length + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_whiteLightReadingPos_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          bufferedWriter.write(paramArrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_whiteLightReadingLength_Ptr.in"));
        bufferedWriter.write(paramArrayOfDouble3.length + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_whiteLightReadingNeg_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble4.length; b1++)
          bufferedWriter.write(paramArrayOfDouble4[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_MC_ReadingPos_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble5.length; b1++)
          bufferedWriter.write(paramArrayOfDouble5[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_MC_ReadingLength_Ptr.in"));
        bufferedWriter.write(paramArrayOfDouble5.length + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_MC_ReadingNeg_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble6.length; b1++)
          bufferedWriter.write(paramArrayOfDouble6[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_numFIR_OptInterp_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble7.length; b1++)
          bufferedWriter.write(paramArrayOfDouble7[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_calibrationLPF.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble8.length; b1++)
          bufferedWriter.write(paramArrayOfDouble8[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_calibrationLPF_Wide.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble9.length; b1++)
          bufferedWriter.write(paramArrayOfDouble9[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_opticalLPF1_Coeff_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble10.length; b1++)
          bufferedWriter.write(paramArrayOfDouble10[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_opticalLPF2_Coeff_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble11.length; b1++)
          bufferedWriter.write(paramArrayOfDouble11[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "successfulPath_SkipMC_DelayComp.config"));
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_laserReadingNeg_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_laserReadingPos_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_whiteLightReadingNeg_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_whiteLightReadingPos_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_MC_ReadingNeg_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_MC_ReadingPos_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_numFIR_OptInterp_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_calibrationLPF.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_calibrationLPF_Wide.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_opticalLPF1_Coeff_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_opticalLPF2_Coeff_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_calibratorWavelengths_Ptr.in\n");
        bufferedWriter.write("input[double]\tDSP_Pre_Calib_paramConf_Ptr.in\n\n\n");
        bufferedWriter.write("input(double)\tact_Freq\t" + paramDouble1 + "\n");
        bufferedWriter.write("input(double)\tI_adc_gain\t\t" + paramDouble2 + "\n");
        bufferedWriter.write("input(double)\tLambda\t\t" + paramDouble3 + "\n");
        bufferedWriter.write("input(int)\tSkipMC\t\t" + paramBoolean1 + "\n");
        bufferedWriter.write("input(double)\tC2VVolt\t\t" + paramDouble4 + "\n");
        bufferedWriter.write("input(double)\tC2VCFB1\t\t" + paramDouble5 + "\n");
        bufferedWriter.write("input(double)\tC2VCFB2\t\t" + paramDouble6 + "\n");
        bufferedWriter.write("input(double)\tNPs_interp_reg\t\t" + paramDouble7 + "\n");
        bufferedWriter.write("input(int)\tn_slices\t\t" + paramInt1 + "\n");
        bufferedWriter.write("input(int)\tavg_shift\t\t" + paramInt2 + "\n");
        bufferedWriter.write("input(double)\tI_X_delay\t\t" + paramDouble8 + "\n");
        bufferedWriter.write("input(int)\ttwoBurstsEnable\t\t" + paramBoolean2 + "\n");
        bufferedWriter.write("input(int)\tcorrected_uncorrected\t\t" + paramInt3 + "\n");
        bufferedWriter.write("input(int)\twl_calib_data_length\t\t10\n\n\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_paramConf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble12.length; b1++)
          bufferedWriter.write(paramArrayOfDouble12[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_paramConfLength.in"));
        bufferedWriter.write(paramArrayOfDouble12.length + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_calibratorWavelengths_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble13.length; b1++)
          bufferedWriter.write(paramArrayOfDouble13[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      double[] arrayOfDouble1 = new double[(int)paramArrayOfDouble12[17] / 2];
      double[] arrayOfDouble2 = new double[(int)paramArrayOfDouble12[17] / 2];
      double[] arrayOfDouble3 = new double[(int)paramArrayOfDouble12[17] / 2];
      double[] arrayOfDouble4 = new double[(int)paramArrayOfDouble12[17] / 2];
      double[] arrayOfDouble5 = new double[10];
      double[] arrayOfDouble6 = { 1.0D };
      double[] arrayOfDouble7 = { 0.0D };
      int[] arrayOfInt = { 0 };
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Calib_wlCorrectionLength.in"));
        bufferedWriter.write(arrayOfDouble5.length + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = SpectrometerDSP_Calib(paramArrayOfDouble1, paramArrayOfDouble1.length, paramArrayOfDouble2, paramArrayOfDouble2.length, paramArrayOfDouble4, paramArrayOfDouble3, paramArrayOfDouble3.length, paramArrayOfDouble6, paramArrayOfDouble5, paramArrayOfDouble5.length, paramArrayOfDouble7, paramArrayOfDouble7.length, paramArrayOfDouble8, paramArrayOfDouble8.length, paramArrayOfDouble9, paramArrayOfDouble9.length, paramArrayOfDouble10, paramArrayOfDouble10.length, paramArrayOfDouble11, paramArrayOfDouble11.length, paramDouble1, paramDouble2, paramDouble3, paramBoolean1, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramInt1, paramInt2, paramDouble8, paramBoolean2, paramArrayOfDouble13, paramArrayOfDouble13.length, paramInt3, paramArrayOfDouble12.length, arrayOfDouble5.length, paramArrayOfDouble12, arrayOfDouble5, arrayOfDouble1, arrayOfDouble2, arrayOfDouble3, arrayOfDouble4, arrayOfInt, arrayOfDouble6, arrayOfDouble7);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in SpectrometerDSP_Calib function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[7][];
      arrayOfDouble[0] = new double[arrayOfInt[0]];
      arrayOfDouble[1] = new double[arrayOfInt[0]];
      arrayOfDouble[2] = new double[arrayOfInt[0]];
      arrayOfDouble[3] = new double[arrayOfInt[0]];
      arrayOfDouble[4] = new double[arrayOfDouble5.length];
      arrayOfDouble[5] = new double[arrayOfDouble6.length + arrayOfDouble7.length];
      arrayOfDouble[6] = new double[paramArrayOfDouble12.length];
      System.arraycopy(arrayOfDouble1, 0, arrayOfDouble[0], 0, arrayOfInt[0]);
      System.arraycopy(arrayOfDouble2, 0, arrayOfDouble[1], 0, arrayOfInt[0]);
      System.arraycopy(arrayOfDouble3, 0, arrayOfDouble[2], 0, arrayOfInt[0]);
      System.arraycopy(arrayOfDouble4, 0, arrayOfDouble[3], 0, arrayOfInt[0]);
      System.arraycopy(arrayOfDouble5, 0, arrayOfDouble[4], 0, arrayOfDouble5.length);
      arrayOfDouble[5][0] = arrayOfDouble6[0];
      arrayOfDouble[5][1] = arrayOfDouble7[0];
      System.arraycopy(paramArrayOfDouble12, 0, arrayOfDouble[6], 0, paramArrayOfDouble12.length);
      arrayOfDouble1 = null;
      arrayOfDouble2 = null;
      arrayOfDouble3 = null;
      arrayOfDouble4 = null;
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "successfulPath_SkipMC_DelayComp.config", true));
        bufferedWriter.write("output[double]\t\tDSP_Post_Calib_param_conf.out\n");
        bufferedWriter.write("output[double]\t" + b + "\n");
        bufferedWriter.write("output[double]\tDSP_Post_Calib_x_vect.out\n");
        bufferedWriter.write("output[double]\tDSP_Post_Calib_C_vneg_vect.out\n");
        bufferedWriter.write("output[double]\tDSP_Post_Calib_C_vpos_vect.out\n");
        bufferedWriter.write("output[double]\tDSP_Post_Calib_C_diff_vect.out\n");
        bufferedWriter.write("output(int)\tDSP_Post_Calib_calib_vector_length\t" + arrayOfDouble[1].length + "\n");
        bufferedWriter.write("output(double)\tDSP_Post_Calib_calib_A_Corr\t" + arrayOfDouble[5][0] + "\n");
        bufferedWriter.write("output(double)\tDSP_Post_Calib_calib_B_Corr\t" + arrayOfDouble[5][1] + "\n");
        bufferedWriter.write("error[rms]\t0.001\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Calib_x_vect.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[0].length; b1++)
          bufferedWriter.write(arrayOfDouble[0][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Calib_C_vneg_vect.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[1].length; b1++)
          bufferedWriter.write(arrayOfDouble[1][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Calib_C_vpos_vect.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[2].length; b1++)
          bufferedWriter.write(arrayOfDouble[2][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Calib_C_diff_vect.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[3].length; b1++)
          bufferedWriter.write(arrayOfDouble[3][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + b));
        for (byte b1 = 0; b1 < arrayOfDouble[4].length; b1++)
          bufferedWriter.write(arrayOfDouble[4][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Calib_Corr.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[5].length; b1++)
          bufferedWriter.write(arrayOfDouble[5][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Calib_param_conf.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[6].length; b1++)
          bufferedWriter.write(arrayOfDouble[6][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) throws a {
    try {
      double[] arrayOfDouble1 = new double[paramArrayOfDouble1.length];
      double[] arrayOfDouble2 = new double[paramArrayOfDouble1.length];
      double[] arrayOfDouble3 = new double[paramArrayOfDouble2.length];
      double[] arrayOfDouble4 = new double[paramArrayOfDouble2.length];
      double[] arrayOfDouble5 = new double[paramArrayOfDouble1.length / 2];
      double[] arrayOfDouble6 = new double[paramArrayOfDouble1.length / 2];
      double[] arrayOfDouble7 = new double[paramArrayOfDouble2.length / 2];
      double[] arrayOfDouble8 = new double[paramArrayOfDouble2.length / 2];
      double[] arrayOfDouble9 = new double[paramArrayOfDouble1.length];
      double[] arrayOfDouble10 = new double[paramArrayOfDouble1.length];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Cap_x_adc_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Cap_I_adc_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Cap_paramConf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          bufferedWriter.write(paramArrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Cap_I_ADC_gain.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Cap_C2VExcVoltage.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Cap_C2VCFB1.in"));
        bufferedWriter.write(paramDouble3 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_Cap_C2VCFB2.in"));
        bufferedWriter.write(paramDouble4 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = SpectrometerDSP_capAndCurrent(paramArrayOfDouble1, paramArrayOfDouble1.length, paramArrayOfDouble2, paramArrayOfDouble2.length, paramArrayOfDouble3, paramArrayOfDouble3.length, paramDouble1, paramDouble2, paramDouble3, paramDouble4, arrayOfDouble1, arrayOfDouble2, arrayOfDouble3, arrayOfDouble4, arrayOfDouble5, arrayOfDouble6, arrayOfDouble7, arrayOfDouble8, arrayOfDouble9, arrayOfDouble10);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in SpectrometerDSP_capAndCurrent function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[12][];
      arrayOfDouble[0] = arrayOfDouble2;
      arrayOfDouble[1] = paramArrayOfDouble1;
      arrayOfDouble[2] = arrayOfDouble4;
      arrayOfDouble[3] = paramArrayOfDouble2;
      arrayOfDouble[4] = arrayOfDouble6;
      arrayOfDouble[5] = arrayOfDouble5;
      arrayOfDouble[6] = arrayOfDouble8;
      arrayOfDouble[7] = arrayOfDouble7;
      arrayOfDouble[8] = arrayOfDouble10;
      arrayOfDouble[9] = arrayOfDouble9;
      arrayOfDouble[10] = arrayOfDouble1;
      arrayOfDouble[11] = arrayOfDouble3;
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_0.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[0].length; b1++)
          bufferedWriter.write(arrayOfDouble[0][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_1.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[1].length; b1++)
          bufferedWriter.write(arrayOfDouble[1][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_2.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[2].length; b1++)
          bufferedWriter.write(arrayOfDouble[2][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_3.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[3].length; b1++)
          bufferedWriter.write(arrayOfDouble[3][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_4.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[4].length; b1++)
          bufferedWriter.write(arrayOfDouble[4][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_5.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[5].length; b1++)
          bufferedWriter.write(arrayOfDouble[5][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_6.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[6].length; b1++)
          bufferedWriter.write(arrayOfDouble[6][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_7.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[7].length; b1++)
          bufferedWriter.write(arrayOfDouble[7][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_8.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[8].length; b1++)
          bufferedWriter.write(arrayOfDouble[8][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_9.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[9].length; b1++)
          bufferedWriter.write(arrayOfDouble[9][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_10.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[10].length; b1++)
          bufferedWriter.write(arrayOfDouble[10][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_Cap_11.out"));
        for (byte b1 = 0; b1 < arrayOfDouble[11].length; b1++)
          bufferedWriter.write(arrayOfDouble[11][b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public void a(double[] paramArrayOfDouble) throws a {
    try {
      if (!g) {
        try {
          BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_Initialization_paramConf_Ptr.in"));
          for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
            bufferedWriter.write(paramArrayOfDouble[b1] + "\n"); 
          bufferedWriter.close();
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
        boolean bool = abstractClosedLoop_closedLoop_initialization(paramArrayOfDouble, paramArrayOfDouble.length);
        if (bool == true) {
          spectrometerDSP_clean();
          throw new Exception("An error occurred in abstractClosedLoop_closedLoop_initialization function! Please contact your vendor for support.");
        } 
        g = true;
      } 
      return;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] b(double[] paramArrayOfDouble) throws a {
    try {
      double[] arrayOfDouble = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_MEMSResponse_CapLpf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
          bufferedWriter.write(paramArrayOfDouble[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_capAmpCalc(paramArrayOfDouble, paramArrayOfDouble.length, arrayOfDouble);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_capAmpCalc function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble1 = new double[1][1];
      arrayOfDouble1[0][0] = arrayOfDouble[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_MEMSResponse_CapAmp_Ptr.out"));
        bufferedWriter.write(arrayOfDouble[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble1;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) throws a {
    try {
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PreProcessing_CapLpf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
          bufferedWriter.write(paramArrayOfDouble[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PreProcessing_V_reference.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PreProcessing_CFB1.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PreProcessing_CFB2.in"));
        bufferedWriter.write(paramDouble3 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PreProcessing_opticalADC_gain.in"));
        bufferedWriter.write(paramDouble4 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_signalPreprocessing(paramArrayOfDouble.length, paramDouble4, paramDouble1, paramDouble2, paramDouble3, paramArrayOfDouble);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_signalPreprocessing function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[1][];
      arrayOfDouble[0] = paramArrayOfDouble;
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_PreProcessing_NormCapLpf_Ptr.out"));
        bufferedWriter.write(paramArrayOfDouble[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] c(double[] paramArrayOfDouble) throws a {
    try {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_ParametersCalc_ResFreqAndQualityFactor_stepResponse_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
          bufferedWriter.write(paramArrayOfDouble[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_memsParametersDetection(paramArrayOfDouble, paramArrayOfDouble.length, arrayOfDouble1, arrayOfDouble2);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_memsParametersDetection function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[2][1];
      arrayOfDouble[0][0] = arrayOfDouble1[0];
      arrayOfDouble[1][0] = arrayOfDouble2[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_ParametersCalc_ResFreqAndQualityFactor_fres_Ptr.out"));
        bufferedWriter.write(arrayOfDouble1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_ParametersCalc_ResFreqAndQualityFactor_qualityFactor_Ptr.out"));
        bufferedWriter.write(arrayOfDouble2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] b(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) throws a {
    try {
      double[] arrayOfDouble = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_ParametersCalc_ForwardGain_x_adc_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
          bufferedWriter.write(paramArrayOfDouble[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_ParametersCalc_ForwardGain_V_reference.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_ParametersCalc_ForwardGain_CFB1.in"));
        bufferedWriter.write(paramDouble3 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_ParametersCalc_ForwardGain_CFB2.in"));
        bufferedWriter.write(paramDouble4 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_fwdGainCalc(paramArrayOfDouble, paramArrayOfDouble.length, paramDouble1, paramDouble3, paramDouble4, paramDouble2, arrayOfDouble);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_fwdGainCalc function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble1 = new double[1][1];
      arrayOfDouble1[0][0] = arrayOfDouble[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_ParametersCalc_ForwardGain_fwdGain_Ptr.out"));
        bufferedWriter.write(arrayOfDouble[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble1;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double paramDouble5) throws a {
    try {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      double[] arrayOfDouble3 = new double[1];
      double[] arrayOfDouble4 = new double[1];
      double[] arrayOfDouble5 = new double[1];
      double[] arrayOfDouble6 = new double[1];
      double[] arrayOfDouble7 = new double[1];
      double[] arrayOfDouble8 = new double[1];
      double[] arrayOfDouble9 = new double[1];
      double[] arrayOfDouble10 = new double[1];
      double[] arrayOfDouble11 = new double[1];
      double[] arrayOfDouble12 = new double[1];
      double[] arrayOfDouble13 = new double[1];
      double[] arrayOfDouble14 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_CoefficientsCalculation_targetCap.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_CoefficientsCalculation_fres.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_CoefficientsCalculation_fwdGain.in"));
        bufferedWriter.write(paramDouble4 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_CoefficientsCalculation_freqVal_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_CoefficientsCalculation_gainVal_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_CoefficientsCalculation_V_reference.in"));
        bufferedWriter.write(paramDouble5 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_loopCoefficientsCalc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble1.length, paramDouble5, arrayOfDouble1, arrayOfDouble2, arrayOfDouble3, arrayOfDouble4, arrayOfDouble5, arrayOfDouble6, arrayOfDouble7, arrayOfDouble8, arrayOfDouble9, arrayOfDouble10, arrayOfDouble11, arrayOfDouble12, arrayOfDouble13, arrayOfDouble14);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_loopCoefficientsCalc function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[14][1];
      arrayOfDouble[0][0] = arrayOfDouble1[0];
      arrayOfDouble[1][0] = arrayOfDouble2[0];
      arrayOfDouble[2][0] = arrayOfDouble3[0];
      arrayOfDouble[3][0] = arrayOfDouble4[0];
      arrayOfDouble[4][0] = arrayOfDouble5[0];
      arrayOfDouble[5][0] = arrayOfDouble6[0];
      arrayOfDouble[6][0] = arrayOfDouble7[0];
      arrayOfDouble[7][0] = arrayOfDouble8[0];
      arrayOfDouble[8][0] = arrayOfDouble9[0];
      arrayOfDouble[9][0] = arrayOfDouble10[0];
      arrayOfDouble[10][0] = arrayOfDouble11[0];
      arrayOfDouble[11][0] = arrayOfDouble12[0];
      arrayOfDouble[12][0] = arrayOfDouble13[0];
      arrayOfDouble[13][0] = arrayOfDouble14[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_Kp_Ptr.out"));
        bufferedWriter.write(arrayOfDouble1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_Ki_Ptr.out"));
        bufferedWriter.write(arrayOfDouble2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_phaseInitRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble3[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_c2vcfb1RegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble4[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_c2vcfb2RegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble5[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_actualC2vGain_Ptr.out"));
        bufferedWriter.write(arrayOfDouble6[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_drvAmpRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble7[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_drvAmp_Ptr.out"));
        bufferedWriter.write(arrayOfDouble8[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_envDetLpfRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble9[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_envDetLpfBw_Ptr.out"));
        bufferedWriter.write(arrayOfDouble10[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_KpRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble11[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_KdigRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble12[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_Kdig_Ptr.out"));
        bufferedWriter.write(arrayOfDouble13[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_CoefficientsCalculation_KiRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble14[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double paramDouble1, double paramDouble2) throws a {
    try {
      double[] arrayOfDouble = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PhaseTrimming_PhaseConversion_inPhase.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PhaseTrimming_PhaseConversion_fres.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_phaseConversion(paramDouble1, paramDouble2, arrayOfDouble);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_phaseConversion function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble1 = new double[1][1];
      arrayOfDouble1[0][0] = arrayOfDouble[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_PhaseTrimming_PhaseConversion_phaseShiftRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble1;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double paramDouble) throws a {
    try {
      double[] arrayOfDouble = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PhaseTrimming_PhaseValidation_aacOut_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PhaseTrimming_PhaseValidation_capLpf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_phaseValidation(paramArrayOfDouble1, paramArrayOfDouble1.length, paramArrayOfDouble2, paramArrayOfDouble2.length, paramDouble, arrayOfDouble);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_phaseValidation function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble1 = new double[1][1];
      arrayOfDouble1[0][0] = arrayOfDouble[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_PhaseTrimming_PhaseValidation_validPhase_Ptr.out"));
        bufferedWriter.write(arrayOfDouble[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble1;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3) throws a {
    try {
      double[][] arrayOfDouble;
      double[] arrayOfDouble1 = new double[paramArrayOfDouble2.length];
      double[] arrayOfDouble2 = new double[paramArrayOfDouble2.length];
      int[] arrayOfInt = new int[1];
      double[] arrayOfDouble3 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PhaseTrimming_OptimumPhaseDetection_phaseReq_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PhaseTrimming_OptimumPhaseDetection_aacOut_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_PhaseTrimming_OptimumPhaseDetection_phasePattern_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          bufferedWriter.write(paramArrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_optimumPhaseDetection(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble3, paramArrayOfDouble2.length, arrayOfDouble1, arrayOfDouble2, arrayOfInt, arrayOfDouble3);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_optimumPhaseDetection function! Please contact your vendor for support.");
      } 
      if (arrayOfInt[0] == 0) {
        arrayOfDouble = new double[3][1];
        arrayOfDouble[0][0] = arrayOfDouble3[0];
        arrayOfDouble[1][0] = 0.0D;
        arrayOfDouble[2][0] = 0.0D;
      } else {
        arrayOfDouble = new double[3][arrayOfInt[0]];
        arrayOfDouble[0][0] = arrayOfDouble3[0];
        for (byte b1 = 0; b1 < arrayOfInt[0]; b1++) {
          arrayOfDouble[1][b1] = arrayOfDouble1[b1];
          arrayOfDouble[2][b1] = arrayOfDouble2[b1];
        } 
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_PhaseTrimming_OptimumPhaseDetection_validPhases_Ptr.out"));
        for (byte b1 = 0; b1 < arrayOfInt[0]; b1++)
          bufferedWriter.write(arrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_PhaseTrimming_OptimumPhaseDetection_validAACOUT_Ptr.out"));
        for (byte b1 = 0; b1 < arrayOfInt[0]; b1++)
          bufferedWriter.write(arrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_PhaseTrimming_OptimumPhaseDetection_optimumPhase_Ptr.out"));
        bufferedWriter.write(arrayOfDouble3[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2) throws a {
    try {
      double[][] arrayOfDouble;
      double[] arrayOfDouble1 = new double[1000];
      double[] arrayOfDouble2 = new double[1000];
      int[] arrayOfInt = new int[1];
      double[] arrayOfDouble3 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_FastPhaseTrimming_OptimumPhaseDetection_phaseReq_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_FastPhaseTrimming_OptimumPhaseDetection_aacOut_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_optimumPhaseDetectionFast(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble2.length, arrayOfDouble1, arrayOfDouble2, arrayOfInt, arrayOfDouble3);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_optimumPhaseDetectionFast function! Please contact your vendor for support.");
      } 
      if (arrayOfInt[0] == 0) {
        arrayOfDouble = new double[3][1];
        arrayOfDouble[0][0] = arrayOfDouble3[0];
        arrayOfDouble[1][0] = 0.0D;
        arrayOfDouble[2][0] = 0.0D;
      } else {
        arrayOfDouble = new double[3][arrayOfInt[0]];
        arrayOfDouble[0][0] = arrayOfDouble3[0];
        for (byte b1 = 0; b1 < arrayOfInt[0]; b1++) {
          arrayOfDouble[1][b1] = arrayOfDouble1[b1];
          arrayOfDouble[2][b1] = arrayOfDouble2[b1];
        } 
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_FastPhaseTrimming_OptimumPhaseDetection_validPhases_Ptr.out"));
        for (byte b1 = 0; b1 < arrayOfInt[0]; b1++)
          bufferedWriter.write(arrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_FastPhaseTrimming_OptimumPhaseDetection_validAACOUT_Ptr.out"));
        for (byte b1 = 0; b1 < arrayOfInt[0]; b1++)
          bufferedWriter.write(arrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_FastPhaseTrimming_OptimumPhaseDetection_optimumPhase_Ptr.out"));
        bufferedWriter.write(arrayOfDouble3[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) throws a {
    try {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      double[] arrayOfDouble3 = new double[1];
      double[] arrayOfDouble4 = new double[1];
      double[] arrayOfDouble5 = new double[1];
      double[] arrayOfDouble6 = new double[1];
      double[] arrayOfDouble7 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_StabilityCheck_aacOut_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_StabilityCheck_capLpf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_StabilityCheck_V_Reference.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_StabilityCheck_targetCap.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_settingsCheck(paramArrayOfDouble1, paramArrayOfDouble1.length, paramArrayOfDouble2, paramArrayOfDouble2.length, paramDouble1, paramDouble2, paramDouble3, paramDouble4, arrayOfDouble1, arrayOfDouble2, arrayOfDouble3, arrayOfDouble4, arrayOfDouble5, arrayOfDouble6, arrayOfDouble7);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_settingsCheck function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[7][1];
      arrayOfDouble[0][0] = arrayOfDouble1[0];
      arrayOfDouble[1][0] = arrayOfDouble2[0];
      arrayOfDouble[2][0] = arrayOfDouble3[0];
      arrayOfDouble[3][0] = arrayOfDouble4[0];
      arrayOfDouble[4][0] = arrayOfDouble5[0];
      arrayOfDouble[5][0] = arrayOfDouble6[0];
      arrayOfDouble[6][0] = arrayOfDouble7[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_StabilityCheck_errorFlag_Ptr.out"));
        bufferedWriter.write(arrayOfDouble1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_StabilityCheck_instabilityFlag_Ptr.out"));
        bufferedWriter.write(arrayOfDouble2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_StabilityCheck_saturationFlag_Ptr.out"));
        bufferedWriter.write(arrayOfDouble3[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_StabilityCheck_amplitudeFlag_Ptr.out"));
        bufferedWriter.write(arrayOfDouble4[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_StabilityCheck_stabilityStatus_Ptr.out"));
        bufferedWriter.write(arrayOfDouble5[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_StabilityCheck_saturationStatus_Ptr.out"));
        bufferedWriter.write(arrayOfDouble6[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_StabilityCheck_capStatus_Ptr.out"));
        bufferedWriter.write(arrayOfDouble7[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double a(long paramLong) throws a {
    try {
      double[] arrayOfDouble = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_calculateKdig_kdigRegVal.in"));
        bufferedWriter.write(paramLong + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_calculateKdigFromRegisterValue(paramLong, arrayOfDouble);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_calculateKdigFromRegisterValue function! Please contact your vendor for support.");
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_calculateKdig_Kdig_Ptr.out"));
        bufferedWriter.write(arrayOfDouble[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble[0];
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble, double paramDouble1, int paramInt, double paramDouble2) throws a {
    try {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      double[] arrayOfDouble3 = new double[1];
      double[] arrayOfDouble4 = new double[1];
      double[] arrayOfDouble5 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_GainMarginCalc_capLpf_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
          bufferedWriter.write(paramArrayOfDouble[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_GainMarginCalc_KdigIncPer.in"));
        bufferedWriter.write(paramDouble1 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_GainMarginCalc_iteration.in"));
        bufferedWriter.write(paramInt + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_CL_GainMarginCalc_tempKdig.in"));
        bufferedWriter.write(paramDouble2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = abstractClosedLoop_closedLoop_gainMarginCalc(paramArrayOfDouble, paramArrayOfDouble.length, paramDouble1, paramInt, paramDouble2, arrayOfDouble1, arrayOfDouble2, arrayOfDouble3, arrayOfDouble4, arrayOfDouble5);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_gainMarginCalc function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[5][1];
      arrayOfDouble[0][0] = arrayOfDouble1[0];
      arrayOfDouble[1][0] = arrayOfDouble2[0];
      arrayOfDouble[2][0] = arrayOfDouble3[0];
      arrayOfDouble[3][0] = arrayOfDouble4[0];
      arrayOfDouble[4][0] = arrayOfDouble5[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_GainMarginCalc_Kdig_Ptr.out"));
        bufferedWriter.write(arrayOfDouble1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_GainMarginCalc_gainMargin_Ptr.out"));
        bufferedWriter.write(arrayOfDouble2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_GainMarginCalc_KdigRegVal_Ptr.out"));
        bufferedWriter.write(arrayOfDouble3[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_GainMarginCalc_checkEnd_Ptr.out"));
        bufferedWriter.write(arrayOfDouble4[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_CL_GainMarginCalc_errorFlag_Ptr.out"));
        bufferedWriter.write(arrayOfDouble5[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, int paramInt1, int paramInt2) throws a {
    try {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_wavelengthCorr_Wavenumbers_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
          bufferedWriter.write(paramArrayOfDouble1[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_wavelengthCorr_B_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
          bufferedWriter.write(paramArrayOfDouble2[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_wavelengthCorr_refWavelengths_Ptr.in"));
        for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          bufferedWriter.write(paramArrayOfDouble3[b1] + "\n"); 
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Pre_wavelengthCorr_WavenumberCorrSelect.in"));
        bufferedWriter.write(paramInt2 + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      boolean bool = interferogram_wavelengthCorrect(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble1.length, paramArrayOfDouble3, paramArrayOfDouble3.length, paramInt1, paramInt2, arrayOfDouble1, arrayOfDouble2);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_gainMarginCalc function! Please contact your vendor for support.");
      } 
      double[][] arrayOfDouble = new double[1][2];
      arrayOfDouble[0][0] = arrayOfDouble1[0];
      arrayOfDouble[0][1] = arrayOfDouble2[0];
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_wavelengthCorr_A_Corr_Ptr.out"));
        bufferedWriter.write(arrayOfDouble1[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs" + File.separatorChar + "DSP_Post_wavelengthCorr_B_Corr_Ptr.out"));
        bufferedWriter.write(arrayOfDouble2[0] + "\n");
        bufferedWriter.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  public double[][] a(double paramDouble1, double paramDouble2, int paramInt, double[][] paramArrayOfDouble) throws a {
    try {
      double[][] arrayOfDouble = paramArrayOfDouble;
      double[] arrayOfDouble1 = new double[paramInt];
      double[] arrayOfDouble2 = new double[paramInt];
      boolean bool = interferogram_commonWavenumberGeneration(paramDouble1, paramDouble2, paramInt, paramArrayOfDouble[2], paramArrayOfDouble[3], paramArrayOfDouble[3].length, arrayOfDouble1, arrayOfDouble2);
      if (bool == true) {
        spectrometerDSP_clean();
        throw new Exception("An error occurred in abstractClosedLoop_closedLoop_gainMarginCalc function! Please contact your vendor for support.");
      } 
      arrayOfDouble[2] = arrayOfDouble1;
      arrayOfDouble[3] = arrayOfDouble2;
      return arrayOfDouble;
    } catch (Exception exception) {
      a a1 = new a();
      a1.a = exception;
      throw a1;
    } 
  }
  
  static  {
    System.loadLibrary("spectrometerDSP");
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\dspAPI\p2SpectroDSP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */