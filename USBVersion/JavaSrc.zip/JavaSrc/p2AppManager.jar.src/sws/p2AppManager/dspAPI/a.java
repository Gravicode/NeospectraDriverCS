package sws.p2AppManager.dspAPI;

public class a extends Exception {
  private static final long b = 1L;
  
  public Exception a;
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\dspAPI\a.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */