package sws.p2AppManager.a;

import java.io.BufferedReader;
import java.io.FileReader;
import sws.p2AppManager.utils.p2AppManagerUtils;
import sws.p2AppManager.utils.p2Constants;
import sws.p2AppManager.utils.p2Enumerations;

public abstract class a {
  protected final int a = 58;
  
  protected final int b = 10;
  
  protected final int c = 2;
  
  protected final int d = 2;
  
  protected int e;
  
  protected String f;
  
  protected String g;
  
  protected double[] h;
  
  protected long[] i;
  
  public String a() { return this.g; }
  
  public double[] b() { return this.h; }
  
  public void a(double[] paramArrayOfDouble) { this.h = paramArrayOfDouble; }
  
  public long[] c() { return this.i; }
  
  public void a(double paramDouble) { this.h[9] = paramDouble; }
  
  public p2Enumerations.p2AppManagerStatus d() { return a(new String[] { (String)null }); }
  
  public p2Enumerations.p2AppManagerStatus a(String... paramVarArgs) {
    try {
      b(paramVarArgs);
      this.h = p2AppManagerUtils.loadParamFile(this.f);
      if (this.h == null)
        return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
      if (this.h.length < 58) {
        double[] arrayOfDouble2 = p2AppManagerUtils.loadParamFile(this.f);
        String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "param.conf" });
        double[] arrayOfDouble1 = p2AppManagerUtils.loadParamFile(str);
        this.h = new double[58];
        byte b1;
        for (b1 = 0; b1 < arrayOfDouble2.length; b1++)
          this.h[b1] = arrayOfDouble2[b1]; 
        while (b1 < 58) {
          this.h[b1] = arrayOfDouble1[b1];
          b1++;
        } 
      } else if (this.h.length != 58) {
        return p2Enumerations.p2AppManagerStatus.CONFIG_PARAM_LENGTH_ERROR;
      } 
      return e();
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR;
    } 
  }
  
  protected long[] a(String paramString) {
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader(paramString));
      long[] arrayOfLong = new long[this.e];
      for (byte b1 = 0; b1 < this.e; b1++)
        arrayOfLong[b1] = Long.parseLong(bufferedReader.readLine(), 16); 
      bufferedReader.close();
      return arrayOfLong;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  abstract void b(String... paramVarArgs);
  
  abstract p2Enumerations.p2AppManagerStatus e();
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\a\a.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */