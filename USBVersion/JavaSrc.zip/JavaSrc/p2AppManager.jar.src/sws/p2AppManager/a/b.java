package sws.p2AppManager.a;

import java.io.File;
import sws.p2AppManager.utils.p2AppManagerUtils;
import sws.p2AppManager.utils.p2Constants;
import sws.p2AppManager.utils.p2Enumerations;

public class b extends a {
  private final String j = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "filt3.filt" });
  
  private final String k = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "filt4.filt" });
  
  private final String l = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "filt5.filt" });
  
  private String m = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "filt6.filt" });
  
  private final String n = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "filt7.filt" });
  
  private final String o = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "filt9.filt" });
  
  private final String p = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "filt10.filt" });
  
  private double[] q;
  
  private double[] r;
  
  private double[] s;
  
  private double[] t;
  
  private double[] u;
  
  private double[] v;
  
  private double[] w;
  
  public double[] f() { return this.s; }
  
  public double[] g() { return this.t; }
  
  public double[] h() { return this.u; }
  
  public double[] i() { return this.v; }
  
  public double[] j() { return this.w; }
  
  public double[] k() { return this.q; }
  
  public double[] l() { return this.r; }
  
  protected void b(String... paramVarArgs) {
    this.h = null;
    this.f = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "param.conf" });
  }
  
  protected p2Enumerations.p2AppManagerStatus e() {
    this.q = p2AppManagerUtils.loadRawDataFile(this.j);
    if (this.q == null)
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
    this.r = p2AppManagerUtils.loadRawDataFile(this.k);
    if (this.r == null)
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
    this.s = p2AppManagerUtils.loadRawDataFile(this.l);
    if (this.s == null)
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
    this.t = p2AppManagerUtils.loadRawDataFile(this.m);
    if (this.t == null)
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
    this.u = p2AppManagerUtils.loadRawDataFile(this.n);
    if (this.u == null)
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
    this.v = p2AppManagerUtils.loadRawDataFile(this.o);
    if (this.v == null)
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
    this.w = p2AppManagerUtils.loadRawDataFile(this.p);
    return (this.w == null) ? p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR : p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public void a(String paramString, int paramInt) {
    this.e = paramInt;
    String str = p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "{0}" + File.separatorChar + "t.reg";
    this.g = p2AppManagerUtils.formatString(str, new Object[] { paramString });
    this.i = a(this.g);
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\a\b.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */