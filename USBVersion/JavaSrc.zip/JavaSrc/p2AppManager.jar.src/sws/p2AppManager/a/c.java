package sws.p2AppManager.a;

import sws.p2AppManager.utils.p2AppManagerUtils;
import sws.p2AppManager.utils.p2Constants;
import sws.p2AppManager.utils.p2Enumerations;

public class c extends a {
  private String j;
  
  private String k;
  
  private String l;
  
  private String m;
  
  private double[] n;
  
  private double[] o;
  
  private double[] p;
  
  private double[] q;
  
  public String f() { return this.k; }
  
  public double[] g() { return this.n; }
  
  public double[] h() { return this.o; }
  
  public double[] i() { return this.p; }
  
  public double[] j() { return this.q; }
  
  protected void b(String... paramVarArgs) {
    this.f = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { paramVarArgs[0], paramVarArgs[1], "param.conf" });
    this.g = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { paramVarArgs[0], paramVarArgs[1], "t.reg" });
    this.j = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { paramVarArgs[0], paramVarArgs[1], "C2x.cal" });
    this.k = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { paramVarArgs[0], paramVarArgs[1], "corr.cal" });
    this.l = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { paramVarArgs[0], paramVarArgs[1], "wl_corr.cal" });
    this.m = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { paramVarArgs[0], paramVarArgs[1], "wavelength_corr.cal" });
    this.e = Integer.parseInt(paramVarArgs[2]);
  }
  
  protected p2Enumerations.p2AppManagerStatus e() {
    this.n = p2AppManagerUtils.loadRawDataFile(this.j);
    if (this.n == null)
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR; 
    this.o = p2AppManagerUtils.loadRawDataFile(this.k);
    if (this.o == null || this.o.length != 2) {
      this.o = null;
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR;
    } 
    this.p = p2AppManagerUtils.loadRawDataFile(this.l);
    if (this.p == null || this.p.length != 10) {
      this.p = null;
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR;
    } 
    this.q = p2AppManagerUtils.loadRawDataFile(this.m);
    if (this.q == null || this.q.length != 2) {
      this.q = null;
      return p2Enumerations.p2AppManagerStatus.CONFIG_FILES_LOADING_ERROR;
    } 
    this.i = a(this.g);
    return (this.i == null) ? p2Enumerations.p2AppManagerStatus.INAVLID_REG_FILE_FORMAT_ERROR : p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double a(String paramString1, String paramString2) {
    String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { paramString1, paramString2, "param.conf" });
    double[] arrayOfDouble = p2AppManagerUtils.loadParamFile(str);
    if (arrayOfDouble == null)
      return -1.0D; 
    if (arrayOfDouble.length < 58) {
      double[] arrayOfDouble2 = p2AppManagerUtils.loadParamFile(str);
      String str1 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.GLOBAL_CONFIG_FILES_PATH), new Object[] { "param.conf" });
      double[] arrayOfDouble1 = p2AppManagerUtils.loadParamFile(str1);
      arrayOfDouble = new double[58];
      byte b;
      for (b = 0; b < arrayOfDouble2.length; b++)
        arrayOfDouble[b] = arrayOfDouble2[b]; 
      while (b < 58) {
        arrayOfDouble[b] = arrayOfDouble1[b];
        b++;
      } 
    } 
    return arrayOfDouble[33];
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\a\c.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */