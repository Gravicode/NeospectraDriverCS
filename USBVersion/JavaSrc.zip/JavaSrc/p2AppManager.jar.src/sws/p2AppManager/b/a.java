package sws.p2AppManager.b;

import java.util.Observable;
import sws.p2AppManager.a.b;
import sws.p2AppManager.utils.p2Enumerations;

public abstract class a extends Observable {
  public abstract String a();
  
  public abstract p2Enumerations.p2AppManagerStatus a(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus b(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus c(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus d(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus e(b paramb, String... paramVarArgs);
  
  public abstract double b();
  
  public abstract double[][] c();
  
  public abstract p2Enumerations.p2AppManagerStatus a(b paramb, double[][] paramArrayOfDouble, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus f(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus g(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus h(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus i(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus j(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus k(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus l(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus m(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus n(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus a(String paramString, double[][] paramArrayOfDouble);
  
  public abstract p2Enumerations.p2AppManagerStatus b(String paramString, double[][] paramArrayOfDouble);
  
  public abstract double[][] d();
  
  public abstract double[][] e();
  
  public abstract double[][] f();
  
  public abstract double[][] g();
  
  public abstract double[][] h();
  
  public abstract double[][] i();
  
  public abstract p2Enumerations.p2AppManagerStatus o(b paramb, String... paramVarArgs);
  
  public abstract double[][] j();
  
  public abstract p2Enumerations.p2AppManagerStatus p(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus q(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus r(b paramb, String... paramVarArgs);
  
  public abstract double[][] k();
  
  public abstract p2Enumerations.p2AppManagerStatus s(b paramb, String... paramVarArgs);
  
  public abstract double[][] l();
  
  public abstract p2Enumerations.p2AppManagerStatus t(b paramb, String... paramVarArgs);
  
  public abstract void u(b paramb, String... paramVarArgs);
  
  public abstract void a(String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus v(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus w(b paramb, String[] paramArrayOfString);
  
  public abstract p2Enumerations.p2AppManagerStatus x(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus y(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus z(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus A(b paramb, String... paramVarArgs);
  
  public abstract double[][] m();
  
  public abstract p2Enumerations.p2AppManagerStatus B(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus a(b paramb, long[] paramArrayOfLong);
  
  public abstract long[] n();
  
  public abstract p2Enumerations.p2AppManagerStatus C(b paramb, String... paramVarArgs);
  
  public abstract double[][] o();
  
  public abstract p2Enumerations.p2AppManagerStatus D(b paramb, String... paramVarArgs);
  
  public abstract double[][] p();
  
  public abstract p2Enumerations.p2AppManagerStatus E(b paramb, String... paramVarArgs);
  
  public abstract double[][] q();
  
  public abstract p2Enumerations.p2AppManagerStatus F(b paramb, String... paramVarArgs);
  
  public abstract p2Enumerations.p2AppManagerStatus G(b paramb, String... paramVarArgs);
  
  public abstract double[][] r();
  
  public abstract p2Enumerations.p2AppManagerStatus H(b paramb, String... paramVarArgs);
  
  public abstract double[][] s();
  
  public abstract p2Enumerations.p2AppManagerStatus I(b paramb, String... paramVarArgs);
  
  public abstract double[][] t();
  
  public abstract p2Enumerations.p2AppManagerStatus J(b paramb, String... paramVarArgs);
  
  public abstract void u();
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\b\a.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */