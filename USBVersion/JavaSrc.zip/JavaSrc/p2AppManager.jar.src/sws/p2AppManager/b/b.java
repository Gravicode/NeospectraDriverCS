package sws.p2AppManager.b;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import sws.TAIFDriver.a;
import sws.TAIFDriver.a.i;
import sws.TAIFDriver.a.j;
import sws.TAIFDriver.a.k;
import sws.TAIFDriver.b.a;
import sws.TAIFDriver.c.c;
import sws.p2AppManager.a.b;
import sws.p2AppManager.a.c;
import sws.p2AppManager.c.a;
import sws.p2AppManager.c.c;
import sws.p2AppManager.dspAPI.a;
import sws.p2AppManager.dspAPI.p2SpectroDSP;
import sws.p2AppManager.utils.p2AppManagerException;
import sws.p2AppManager.utils.p2AppManagerUtils;
import sws.p2AppManager.utils.p2Constants;
import sws.p2AppManager.utils.p2DeviceNotificationResult;
import sws.p2AppManager.utils.p2Enumerations;

public class b extends a {
  private static Logger b = Logger.getLogger(b.class);
  
  private String c;
  
  private p2Enumerations.p2AppManagerState d = p2Enumerations.p2AppManagerState.Idle;
  
  private double[][] e = (double[][])null;
  
  private double[][] f = (double[][])null;
  
  private double[][] g = (double[][])null;
  
  private double[][] h = (double[][])null;
  
  private double[][] i = (double[][])null;
  
  private double[][] j = (double[][])null;
  
  private double[][] k = (double[][])null;
  
  private double[][] l = (double[][])null;
  
  private double[][] m = (double[][])null;
  
  private double[][] n = (double[][])null;
  
  private double[][] o = (double[][])null;
  
  private double[][] p = (double[][])null;
  
  private double[][] q = (double[][])null;
  
  private double[][] r = (double[][])null;
  
  private double[][] s = (double[][])null;
  
  private double[][] t = (double[][])null;
  
  private double[][] u = (double[][])null;
  
  private double[][] v = (double[][])null;
  
  private double[][] w = (double[][])null;
  
  private double[][] x = (double[][])null;
  
  private long[] y = null;
  
  private double z = 0.0D;
  
  private double A = 0.0D;
  
  private double B = 0.0D;
  
  private c C = new c();
  
  private b D;
  
  private String E = "";
  
  private String F = "";
  
  private String G = "";
  
  private boolean H = false;
  
  private boolean I = false;
  
  private String J = "";
  
  private String K = "";
  
  private boolean L = false;
  
  private double M = 1.0D;
  
  private String N = "21845";
  
  private a O = new a(Integer.parseInt(this.N), p2Constants.APPLICATION_WORKING_DIRECTORY);
  
  private double[] P;
  
  private final int Q = 31;
  
  int[][] a = { 
      { 0, 0, 1 }, { 1, 0, 2 }, { 1, 1, 4 }, { 3, 0, 6 }, { 2, 1, 8 }, { 5, 0, 10 }, { 3, 1, 12 }, { 2, 2, 16 }, { 5, 1, 20 }, { 3, 2, 24 }, 
      { 4, 2, 32 }, { 3, 3, 36 }, { 5, 2, 40 }, { 4, 3, 48 }, { 5, 3, 60 }, { 4, 4, 64 }, { 5, 4, 80 }, { 5, 5, 100 } };
  
  public void u() { this.O.a(p2Constants.APPLICATION_WORKING_DIRECTORY); }
  
  private p2Enumerations.p2AppManagerState w() { return this.d; }
  
  private void a(p2Enumerations.p2AppManagerState paramp2AppManagerState) {
    b.info("------State Change------From------" + this.d + "-----To-----" + paramp2AppManagerState);
    this.d = paramp2AppManagerState;
  }
  
  public String a() { return this.c; }
  
  public p2Enumerations.p2AppManagerStatus a(b paramb, String... paramVarArgs) {
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.BOARD_ALREADY_INITIALIZED == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus) {
      a(p2Enumerations.p2AppManagerState.Initialize);
      this.D = paramb;
      x();
    } 
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus b(b paramb, String... paramVarArgs) {
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return (p2Enumerations.p2AppManagerState.Initialize == w()) ? p2Enumerations.p2AppManagerStatus.INITIALIZATION_IN_PROGRESS : p2Enumerations.p2AppManagerStatus.NO_ERROR; 
    a(p2Enumerations.p2AppManagerState.CheckingDeviceStatus);
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    a(p2Enumerations.p2AppManagerState.Idle);
    b.info("checkBoardStatus method returned : " + p2AppManagerStatus.toString());
    if (p2Enumerations.p2AppManagerStatus.BOARD_ALREADY_INITIALIZED == p2AppManagerStatus)
      return p2Enumerations.p2AppManagerStatus.NO_ERROR; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus) {
      a(paramb, new String[0]);
    } else if (p2AppManagerStatus == p2Enumerations.p2AppManagerStatus.INITIATE_TAIFDRIVER_ERROR) {
      b.error("INITIATE_TAIFDRIVER_ERROR returned but the application manager swallowed it");
      return p2Enumerations.p2AppManagerStatus.INITIALIZATION_IN_PROGRESS;
    } 
    return p2AppManagerStatus;
  }
  
  public void u(b paramb, String... paramVarArgs) {
    this.F = paramVarArgs[0];
    if (paramVarArgs.length == 1) {
      this.H = true;
    } else {
      this.H = Boolean.parseBoolean(paramVarArgs[1]);
    } 
  }
  
  public void a(String... paramVarArgs) {
    this.J = paramVarArgs[0];
    this.K = paramVarArgs[1];
    this.L = true;
  }
  
  public p2Enumerations.p2AppManagerStatus c(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 4 && paramVarArgs.length != 2)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != this.d)
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    boolean bool2 = Boolean.parseBoolean(paramVarArgs[1]);
    try {
      if (bool2) {
        if (this.f == null)
          return p2Enumerations.p2AppManagerStatus.NO_VALID_BG_DATA_ERROR; 
        if (this.z < Double.parseDouble(paramVarArgs[0]))
          return p2Enumerations.p2AppManagerStatus.INVALID_RUN_TIME_NOT_EQUAL_BG_RUN_TIME_ERROR; 
        a1 = a(p2Enumerations.p2DeviceAction.RunSpecSample, paramVarArgs);
        this.e = (double[][])null;
      } else {
        this.z = Double.parseDouble(paramVarArgs[0]);
        a1 = a(p2Enumerations.p2DeviceAction.RunSpecBackground, paramVarArgs);
        this.f = (double[][])null;
      } 
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    this.D = paramb;
    p(a1, bool1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus d(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 3)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != this.d)
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    try {
      this.g = (double[][])null;
      a1 = a(p2Enumerations.p2DeviceAction.RunWavelengthCalibrationBG, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    this.D = paramb;
    p(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus e(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 4)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != this.d)
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    try {
      if (this.g == null)
        return p2Enumerations.p2AppManagerStatus.NO_VALID_BG_DATA_ERROR; 
      a1 = a(p2Enumerations.p2DeviceAction.RunWavelengthCalibration, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    this.D = paramb;
    p(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double b() { return this.M; }
  
  public double[][] c() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.e == null) {
      b.error("there is no Spec data may be you don't have any successful spec run ");
      return (double[][])null;
    } 
    return this.e;
  }
  
  public p2Enumerations.p2AppManagerStatus a(b paramb, double[][] paramArrayOfDouble, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 3 && paramVarArgs.length != 1)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.k = (double[][])null;
    this.x = paramArrayOfDouble;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunInterSpec, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.InterferogramRun);
    this.D = paramb;
    o(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus f(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 3 && paramVarArgs.length != 1)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.k = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunInterSpec, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.InterferogramRun);
    this.D = paramb;
    p(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus g(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 2)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    if (this.k == null)
      return p2Enumerations.p2AppManagerStatus.NO_VALID_OLD_MEASUREMENT_ERROR; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsInterSpec, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.updateFFT_SettingsInterSpecRun);
    this.D = paramb;
    b(a1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus h(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 2)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    if (this.e == null || this.f == null)
      return p2Enumerations.p2AppManagerStatus.NO_VALID_OLD_MEASUREMENT_ERROR; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsSpec, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.updateFFT_SettingsSpecRun);
    this.D = paramb;
    c(a1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus i(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 4)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.l = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunSNR, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.SNR_Run);
    this.D = paramb;
    q(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus j(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 6)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    if (this.f == null)
      return p2Enumerations.p2AppManagerStatus.NO_VALID_BG_DATA_ERROR; 
    if (this.z != Double.parseDouble(paramVarArgs[0]))
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_TIME_NOT_EQUAL_BG_RUN_TIME_ERROR; 
    this.m = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunStability, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.StabilityRun);
    this.D = paramb;
    r(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus k(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 3)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.k = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunSelfCorr, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.selfCorr_Run);
    this.D = paramb;
    p(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus l(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 1)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.h = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunGainAdjustInterSpec, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.gainAdjustInterSpecRun);
    this.D = paramb;
    s(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus m(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 1)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.i = (double[][])null;
    this.j = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunGainAdjustSpecBG, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.gainAdjustSpecBG_Run);
    this.D = paramb;
    s(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus n(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 3)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    if (this.i == null)
      return p2Enumerations.p2AppManagerStatus.NO_VALID_BG_DATA_ERROR; 
    this.j = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunGainAdjustSpecSample, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.gainAdjustSpecSampleRun);
    this.D = paramb;
    s(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus a(String paramString, double[][] paramArrayOfDouble) {
    if (null != paramString && "" != paramString && null != paramArrayOfDouble) {
      paramString = paramString.replace(" ", "");
      paramString = "_InterSpec_" + paramString;
      String[] arrayOfString = { ".option " + paramString, "CURRENT_RANGE=" + p2Constants.currentRanges[(int)paramArrayOfDouble[0][0]], "PGA1=" + Integer.toString(p2Constants.PGA1_values[(int)paramArrayOfDouble[0][1]]), "PGA2=" + Integer.toString(p2Constants.PGA2_values[(int)paramArrayOfDouble[0][2]]), ".end", "" };
      if (c(arrayOfString))
        return p2Enumerations.p2AppManagerStatus.NO_ERROR; 
      System.out.println("Failed saving in saveInterSpecGainSettings (1)!");
      return p2Enumerations.p2AppManagerStatus.FAILED_IN_ADAPTIVE_GAIN;
    } 
    System.out.println("Failed saving in saveInterSpecGainSettings (2)!");
    return p2Enumerations.p2AppManagerStatus.FAILED_IN_ADAPTIVE_GAIN;
  }
  
  public p2Enumerations.p2AppManagerStatus b(String paramString, double[][] paramArrayOfDouble) {
    if (null != paramString && "" != paramString && null != paramArrayOfDouble) {
      paramString = paramString.replace(" ", "");
      paramString = "_Spec_" + paramString;
      String[] arrayOfString = { ".option " + paramString, "BG_CURRENT_RANGE=" + p2Constants.currentRanges[(int)paramArrayOfDouble[0][0]], "BG_PGA1=" + Integer.toString(p2Constants.PGA1_values[(int)paramArrayOfDouble[0][1]]), "BG_PGA2=" + Integer.toString(p2Constants.PGA2_values[(int)paramArrayOfDouble[0][2]]), "Sample_CURRENT_RANGE=" + p2Constants.currentRanges[(int)paramArrayOfDouble[1][0]], "Sample_PGA1=" + Integer.toString(p2Constants.PGA1_values[(int)paramArrayOfDouble[1][1]]), "Sample_PGA2=" + Integer.toString(p2Constants.PGA2_values[(int)paramArrayOfDouble[1][2]]), "ERROR=" + Double.toString(paramArrayOfDouble[2][0]), ".end", "" };
      if (c(arrayOfString))
        return p2Enumerations.p2AppManagerStatus.NO_ERROR; 
      System.out.println("Failed saving in saveSpecGainSettings (1)!");
      return p2Enumerations.p2AppManagerStatus.FAILED_IN_ADAPTIVE_GAIN;
    } 
    System.out.println("Failed saving in saveSpecGainSettings (2)!");
    return p2Enumerations.p2AppManagerStatus.FAILED_IN_ADAPTIVE_GAIN;
  }
  
  public p2Enumerations.p2AppManagerStatus o(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 17)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    this.E = "";
    if (Boolean.parseBoolean(paramVarArgs[1])) {
      paramb.a("TAIFReg", this.O.f());
      try {
        this.O.a(paramb.c());
      } catch (a null) {
        b.error("Loading register file failed");
        return p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR;
      } 
    } 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunCapTimeCalibration, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    boolean bool2 = false;
    if (Boolean.parseBoolean(paramVarArgs[1])) {
      try {
        bool2 = this.O.a(Boolean.parseBoolean(paramVarArgs[1]));
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR;
      } 
    } else {
      bool2 = false;
      try {
        this.O.a(false, Boolean.parseBoolean(paramVarArgs[1]), (int)paramb.b()[48]);
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      } 
    } 
    if (!bool2)
      try {
        this.O.a(true, Boolean.parseBoolean(paramVarArgs[1]), (int)paramb.b()[48]);
        try {
          Thread.sleep((long)paramb.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      }  
    this.n = (double[][])null;
    a(p2Enumerations.p2AppManagerState.CalibrationCapVsTimeRun);
    this.D = paramb;
    a(a1, bool1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus p(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 9)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunDelayCompensation, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    boolean bool2 = false;
    if (Boolean.parseBoolean(paramVarArgs[1])) {
      try {
        bool2 = this.O.a(Boolean.parseBoolean(paramVarArgs[1]));
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR;
      } 
    } else {
      bool2 = false;
      try {
        this.O.a(false, Boolean.parseBoolean(paramVarArgs[1]), (int)paramb.b()[48]);
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      } 
    } 
    if (!bool2)
      try {
        this.O.a(true, Boolean.parseBoolean(paramVarArgs[7]), (int)paramb.b()[48]);
        try {
          Thread.sleep((long)paramb.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      }  
    a(p2Enumerations.p2AppManagerState.CalibrationDelayCompensationRun);
    this.D = paramb;
    e(a1, bool1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus q(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 11)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunCalibration, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    boolean bool2 = false;
    if (Boolean.parseBoolean(paramVarArgs[1])) {
      try {
        bool2 = this.O.a(Boolean.parseBoolean(paramVarArgs[1]));
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR;
      } 
    } else {
      bool2 = false;
      try {
        this.O.a(false, Boolean.parseBoolean(paramVarArgs[1]), (int)paramb.b()[48]);
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      } 
    } 
    if (!bool2)
      try {
        this.O.a(true, Boolean.parseBoolean(paramVarArgs[7]), (int)paramb.b()[48]);
        try {
          Thread.sleep((long)paramb.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      }  
    a(p2Enumerations.p2AppManagerState.CalibrationCoreRun);
    this.D = paramb;
    f(a1, bool1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus r(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 16 && paramVarArgs.length != 17 && paramVarArgs.length != 18)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.GenerateCalibration, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.CalibrationGeneration);
    this.D = paramb;
    a(a1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] j() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.n == null) {
      b.error("there is no Cap Time data may be you don't have any successful Cap Time runs");
      return (double[][])null;
    } 
    return this.n;
  }
  
  public double[][] k() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.o == null) {
      b.error("there is no calibration data may be you don't have any successful calibrations ");
      return (double[][])null;
    } 
    return this.o;
  }
  
  public double[][] l() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.p == null) {
      b.error("there is no Cap & Current data may be you don't have any successful cap & current runs");
      return (double[][])null;
    } 
    return this.p;
  }
  
  public double[][] d() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.x == null) {
      b.error("there is no raw data may be you don't have any successful runs ");
      return (double[][])null;
    } 
    return this.x;
  }
  
  public double[][] e() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.k == null) {
      b.error("there is no interSpec data may be you don't have any successful interspec run ");
      return (double[][])null;
    } 
    return this.k;
  }
  
  public double[][] f() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.h == null) {
      b.error("there is no valid data");
      return (double[][])null;
    } 
    return this.h;
  }
  
  public double[][] g() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.i == null || this.j == null) {
      b.error("there is no valid data");
      return (double[][])null;
    } 
    return new double[][] { this.i[0], this.j[0], this.j[1] };
  }
  
  public double[][] h() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.l == null) {
      b.error("there is no SNR data may be you don't have any successful run ");
      return (double[][])null;
    } 
    return this.l;
  }
  
  public double[][] i() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.m == null) {
      b.error("there is no Stability data may be you don't have any successful run ");
      return (double[][])null;
    } 
    return this.m;
  }
  
  public p2Enumerations.p2AppManagerStatus s(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 13)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    this.E = "";
    if (Boolean.parseBoolean(paramVarArgs[1])) {
      paramb.a("TAIFReg", this.O.f());
      try {
        this.O.a(paramb.c());
      } catch (a null) {
        b.error("Loading register file failed");
        return p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR;
      } 
    } 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunCapCurrent, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    boolean bool2 = false;
    if (Boolean.parseBoolean(paramVarArgs[1])) {
      try {
        bool2 = this.O.a(Boolean.parseBoolean(paramVarArgs[1]));
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR;
      } 
    } else {
      bool2 = false;
      try {
        this.O.a(false, Boolean.parseBoolean(paramVarArgs[1]), (int)paramb.b()[48]);
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      } 
    } 
    if (!bool2)
      try {
        this.O.a(true, Boolean.parseBoolean(paramVarArgs[1]), (int)paramb.b()[48]);
        try {
          Thread.sleep((long)paramb.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      }  
    this.p = (double[][])null;
    a(p2Enumerations.p2AppManagerState.CapCurrentRun);
    this.D = paramb;
    a(a1, bool1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus v(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 1)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.BurnSampleID, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.SampleIDBurn);
    this.D = paramb;
    g(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus w(b paramb, String[] paramArrayOfString) {
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    a a1 = new a(this, null);
    a1.a = p2Enumerations.p2AppManagerState.SampleFoldersBurn;
    a1.F = paramArrayOfString;
    a(p2Enumerations.p2AppManagerState.SampleFoldersBurn);
    this.D = paramb;
    k(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus x(b paramb, String... paramVarArgs) {
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    a a1 = new a(this, null);
    a1.a = p2Enumerations.p2AppManagerState.RestoreDefault;
    if (paramVarArgs.length != 0) {
      a1.G = paramVarArgs[0];
    } else {
      a1.G = p2Enumerations.RestoreOptionsEnum.ALL.getStringVal();
    } 
    a(p2Enumerations.p2AppManagerState.RestoreDefault);
    this.D = paramb;
    l(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus y(b paramb, String... paramVarArgs) {
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    a a1 = new a(this, null);
    a1.a = p2Enumerations.p2AppManagerState.BurnSettings;
    a(p2Enumerations.p2AppManagerState.BurnSettings);
    this.D = paramb;
    m(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus J(b paramb, String... paramVarArgs) {
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    a a1 = new a(this, null);
    a1.a = p2Enumerations.p2AppManagerState.BurnSettings;
    String[] arrayOfString = new String[paramVarArgs.length - 1];
    System.arraycopy(paramVarArgs, 0, arrayOfString, 0, paramVarArgs.length - 1);
    boolean bool2 = Boolean.parseBoolean(paramVarArgs[paramVarArgs.length - 1]);
    a(p2Enumerations.p2AppManagerState.BurnSettings);
    this.D = paramb;
    a(a1, bool1, bool2, arrayOfString);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus z(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 0)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.ReadSampleFolders, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.SampleFoldersReading);
    this.D = paramb;
    n(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus A(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 0)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.ReadTemp, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.TempReading);
    this.D = paramb;
    h(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] m() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.q == null) {
      b.error("there is no temperature data.");
      return (double[][])null;
    } 
    return this.q;
  }
  
  public p2Enumerations.p2AppManagerStatus B(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 0)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    try {
      a1 = a(p2Enumerations.p2DeviceAction.ReadASICRegisters, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.ASICRegistersReading);
    this.D = paramb;
    i(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus a(b paramb, long[] paramArrayOfLong) {
    if (paramArrayOfLong == null)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    a a1 = new a(this, null);
    a1.a = p2Enumerations.p2AppManagerState.ASICRegistersWriting;
    a1.E = paramArrayOfLong;
    a(p2Enumerations.p2AppManagerState.ASICRegistersWriting);
    this.D = paramb;
    j(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public long[] n() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return null;
    } 
    if (this.y == null) {
      b.error("there is no ASIC registers data.");
      return null;
    } 
    return this.y;
  }
  
  public p2Enumerations.p2AppManagerStatus t(b paramb, String... paramVarArgs) {
    boolean bool2;
    if (paramVarArgs.length == 0 || p2AppManagerUtils.isEmptyString(paramVarArgs[0]))
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    try {
      Boolean.parseBoolean(paramVarArgs[0]);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    a(p2Enumerations.p2AppManagerState.ActuationProfileSetting);
    this.D = paramb;
    if (paramVarArgs.length == 1) {
      bool2 = true;
    } else {
      bool2 = Boolean.parseBoolean(paramVarArgs[1]);
    } 
    a(bool1, Boolean.parseBoolean(paramVarArgs[0]), bool2);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  private void x() {
    b.info("executeIntiliazation method :: Start");
    c.a(new a<Boolean>(this) {
          protected Boolean a() {
            try {
              b.a(this.a, b.a(this.a));
              b.a(this.a, p2Enumerations.p2DeviceAction.initializeCore, (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.a, p2Enumerations.p2DeviceAction.initializeCore, (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        });
  }
  
  private void a(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              if (this.b.a == p2Enumerations.p2AppManagerState.CalibrationCapVsTimeRun) {
                double[] arrayOfDouble = b.a(this.c, this.b, b.a(this.c));
                if (arrayOfDouble == null)
                  throw new p2AppManagerException("Not a valid reading for this sample: " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.INTERPOLATION_THRESHOLD_ERROR.getNumVal()); 
                double d1 = b.c(this.c).b(i.fH.a(), k.fH.a(), j.fH.a());
                double d2 = b.c(this.c).b(i.fI.a(), k.fI.a(), j.fI.a());
                double d3 = b.c(this.c).b(i.fy.a(), k.fy.a(), j.fy.a());
                double d4 = Math.pow(2.0D, d3) * 5000.0D * this.b.p * this.b.q;
                double[][] arrayOfDouble1 = new double[3][];
                arrayOfDouble1[0] = arrayOfDouble;
                new double[3][0] = d1;
                new double[3][1] = d2;
                new double[3][2] = d4;
                arrayOfDouble1[1] = new double[3];
                arrayOfDouble1[2] = b.d(this.c);
                p2AppManagerUtils.writeFileOfArray(b.d(this.c), "Calibration" + File.separatorChar + "param.conf", "\n");
                b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble1, p2Enumerations.p2AppManagerStatus.NO_ERROR);
              } else if (this.b.a == p2Enumerations.p2AppManagerState.CapCurrentRun) {
                double[][] arrayOfDouble = b.b(this.c, this.b, b.a(this.c));
                if (arrayOfDouble == null)
                  throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
                b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
              } else if (this.b.a == p2Enumerations.p2AppManagerState.ResponseCalculation) {
                double[][] arrayOfDouble = b.c(this.c, this.b, b.a(this.c));
                if (arrayOfDouble == null)
                  throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
                b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
              } else if (this.b.a == p2Enumerations.p2AppManagerState.ParametersCalculation) {
                double[][] arrayOfDouble1 = b.d(this.c, this.b, b.a(this.c));
                if (arrayOfDouble1 == null)
                  throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
                double[][] arrayOfDouble2 = new double[arrayOfDouble1.length + 1][];
                for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++) {
                  arrayOfDouble2[b1] = new double[arrayOfDouble1[b1].length];
                  System.arraycopy(arrayOfDouble1[b1], 0, arrayOfDouble2[b1], 0, arrayOfDouble1[b1].length);
                } 
                arrayOfDouble2[arrayOfDouble1.length] = new double[1];
                arrayOfDouble2[arrayOfDouble1.length][0] = b.e(this.c);
                b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble2, p2Enumerations.p2AppManagerStatus.NO_ERROR);
              } else if (this.b.a == p2Enumerations.p2AppManagerState.WaveformPreview) {
                double[][] arrayOfDouble = b.e(this.c, this.b, b.a(this.c));
                if (arrayOfDouble == null)
                  throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
                b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
              } 
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (a a1) {
              b.v().error(a1.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void b(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              double[][] arrayOfDouble = b.f(this.c, this.b, b.a(this.c));
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void c(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              double[][] arrayOfDouble = (double[][])null;
              if (this.b.a == p2Enumerations.p2AppManagerState.PhaseTrimming) {
                arrayOfDouble = b.g(this.c, this.b, b.a(this.c));
              } else if (this.b.a == p2Enumerations.p2AppManagerState.FastPhaseTrimming) {
                arrayOfDouble = b.h(this.c, this.b, b.a(this.c));
              } 
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void d(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              double[][] arrayOfDouble = b.i(this.c, this.b, b.a(this.c));
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void e(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.a a1 = b.a(this.c, b.a(this.c), this.b);
              double[] arrayOfDouble = b.j(this.c, a1, b.a(this.c));
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              double[][] arrayOfDouble1 = new double[1][];
              arrayOfDouble1[0] = arrayOfDouble;
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble1, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void f(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.a a1 = b.a(this.c, b.a(this.c), this.b);
              b.k(this.c, a1, b.a(this.c));
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void a(a parama) { c.a(new a<Boolean>(this, parama) {
          protected Boolean a() {
            try {
              this.a.aa = b.a(this.b, this.a.ac, this.a.b);
              b.v().info("noOfSlices: " + this.a.aa);
              this.a.ab = b.a(this.b, this.a.aa);
              b.v().info("avgShiftBits: " + this.a.ab);
              double[][] arrayOfDouble = (double[][])null;
              b.a(this.b, p2AppManagerUtils.loadRawDataFile("Calibration" + File.separatorChar + "param.conf"));
              double[] arrayOfDouble1 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.LASER_FILE_PATH) + "_1" + ".txt");
              double[] arrayOfDouble2 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.LASER_FILE_PATH) + "_2" + ".txt");
              double[] arrayOfDouble3 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.WL_FILE_PATH) + "_1" + ".txt");
              double[] arrayOfDouble4 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.WL_FILE_PATH) + "_2" + ".txt");
              double[] arrayOfDouble5 = null;
              double[] arrayOfDouble6 = null;
              double[] arrayOfDouble7 = null;
              if (!this.a.A) {
                arrayOfDouble5 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.METH_FILE_PATH) + "_1" + ".txt");
                arrayOfDouble6 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.METH_FILE_PATH) + "_2" + ".txt");
                arrayOfDouble7 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.STANDARD_CALIBRATORS_FOLDER_PATH) + File.separatorChar + this.a.Y + ".txt");
              } 
              if (arrayOfDouble1 == null || arrayOfDouble2 == null)
                throw new p2AppManagerException("Failed to load laser files ", p2Enumerations.p2AppManagerStatus.LASER_FILE_NOT_EXIST_ERROR.getNumVal()); 
              if (arrayOfDouble3 == null || arrayOfDouble4 == null)
                throw new p2AppManagerException("Failed to load white light files ", p2Enumerations.p2AppManagerStatus.WHITE_FILE_NOT_EXIST_ERROR.getNumVal()); 
              if (arrayOfDouble7 == null && !this.a.A)
                throw new p2AppManagerException("Failed to load standard calibrator file ", p2Enumerations.p2AppManagerStatus.WHITE_FILE_NOT_EXIST_ERROR.getNumVal()); 
              if ((arrayOfDouble5 == null || arrayOfDouble6 == null) && !this.a.A)
                this.a.A = true; 
              if (this.a.A == true) {
                arrayOfDouble5 = new double[] { 0.0D };
                arrayOfDouble6 = new double[] { 0.0D };
                arrayOfDouble7 = new double[] { 0.0D };
              } 
              int i = (int)b.c(this.b).b(i.fH.a(), k.fH.a(), j.fH.a());
              int j = (int)b.c(this.b).b(i.fI.a(), k.fI.a(), j.fI.a());
              int k = (int)b.c(this.b).b(i.fy.a(), k.fy.a(), j.fy.a());
              double d1 = Math.pow(2.0D, k) * 5000.0D * this.a.p * this.a.q;
              double d2 = b.c(this.b).b(i.cB.a(), k.cB.a(), j.cB.a());
              if (this.a.h) {
                b.d(this.b)[47] = 0.0D;
              } else {
                b.d(this.b)[47] = 1.0D;
              } 
              if (this.a.s)
                b.d(this.b)[1] = this.a.t; 
              String str1 = this.a.ah;
              ArrayList arrayList1 = new ArrayList();
              if (str1 != null)
                if (str1.equals("1.7")) {
                  for (double d : arrayOfDouble7) {
                    if (d >= 1200.0D && d <= 1690.0D)
                      arrayList1.add(Double.valueOf(d)); 
                  } 
                } else if (str1.equals("2.1")) {
                  for (double d : arrayOfDouble7) {
                    if (d >= 1250.0D && d <= 2050.0D)
                      arrayList1.add(Double.valueOf(d)); 
                  } 
                } else if (str1.equals("2.6")) {
                  for (double d : arrayOfDouble7) {
                    if (d >= 1300.0D && d <= 2550.0D)
                      arrayList1.add(Double.valueOf(d)); 
                  } 
                }  
              if (arrayList1.size() != 0) {
                arrayOfDouble7 = new double[arrayList1.size()];
                for (byte b2 = 0; b2 < arrayList1.size(); b2++)
                  arrayOfDouble7[b2] = ((Double)arrayList1.get(b2)).doubleValue(); 
              } 
              try {
                arrayOfDouble = p2SpectroDSP.a().a(arrayOfDouble2, arrayOfDouble1, arrayOfDouble4, arrayOfDouble3, arrayOfDouble6, arrayOfDouble5, b.a(this.b).f(), b.a(this.b).g(), b.a(this.b).h(), b.a(this.b).k(), b.a(this.b).l(), this.a.b, d1, this.a.B, this.a.A, this.a.m, i, j, this.a.v, this.a.aa, this.a.ab, d2, b.d(this.b), this.a.X, arrayOfDouble7, this.a.e);
              } catch (a a1) {
                throw new p2AppManagerException("Error while make DSP data calibration generation ", p2Enumerations.p2AppManagerStatus.CALIBRATION_GENERATION_ERROR.getNumVal());
              } 
              arrayOfDouble1 = null;
              arrayOfDouble2 = null;
              arrayOfDouble3 = null;
              arrayOfDouble4 = null;
              arrayOfDouble5 = null;
              arrayOfDouble6 = null;
              arrayOfDouble7 = null;
              long l = b.f(this.b);
              if (l == -1L || l == 0L)
                throw new p2AppManagerException("Error during reading temp. ", p2Enumerations.p2AppManagerStatus.READING_TEMP_ERROR.getNumVal()); 
              String str2 = String.valueOf(l);
              String[] arrayOfString1 = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE)), new Object[] { b.b(this.b) }), new ArrayList(), false);
              if (arrayOfString1 != null)
                for (byte b2 = 0; b2 < arrayOfString1.length; b2++) {
                  double d = 0.0D;
                  try {
                    d = Double.parseDouble(arrayOfString1[b2]);
                  } catch (Exception exception) {}
                  if (Math.abs(l - d) <= 72000.0D) {
                    str2 = arrayOfString1[b2];
                    break;
                  } 
                }  
              p2AppManagerUtils.createDir(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.a.C, str2 + File.separatorChar + this.a.D }));
              b.a(this.b, p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.a.C, str2 + File.separatorChar + this.a.D }), p2Constants.getPath(p2Constants.GLOBAL_CONFIG_MEMS_PATH), this.a);
              BufferedReader bufferedReader = new BufferedReader(new FileReader(p2Constants.getPath(p2Constants.PARAM_HEADER_FIE_PATH)));
              ArrayList arrayList2 = new ArrayList();
              String str3;
              while ((str3 = bufferedReader.readLine()) != null)
                arrayList2.add(str3); 
              bufferedReader.close();
              for (byte b1 = 0; b1 < arrayList2.size(); b1++) {
                if (Double.parseDouble(((String)arrayList2.get(b1)).split(":")[1]) != arrayOfDouble[6][b1])
                  arrayList2.set(b1, ((String)arrayList2.get(b1)).split(":")[0] + " : " + arrayOfDouble[6][b1]); 
              } 
              arrayList2.set(33, ((String)arrayList2.get(33)).split(":")[0] + " : " + l);
              String[] arrayOfString2 = { "" };
              p2AppManagerUtils.writeFileOfArray((String[])arrayList2.toArray(arrayOfString2), p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { this.a.C, str2 + File.separatorChar + this.a.D, "param.conf" }), "\n");
              int[] arrayOfInt = new int[2];
              arrayOfInt[0] = 1;
              arrayOfInt[1] = 0;
              p2AppManagerUtils.writeFileOfArray(arrayOfInt, p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { this.a.C, str2 + File.separatorChar + this.a.D, "corr.cal" }), "\n");
              double[] arrayOfDouble8 = new double[arrayOfDouble[0].length + arrayOfDouble[1].length + arrayOfDouble[2].length];
              System.arraycopy(arrayOfDouble[0], 0, arrayOfDouble8, 0, arrayOfDouble[0].length);
              System.arraycopy(arrayOfDouble[1], 0, arrayOfDouble8, arrayOfDouble[0].length, arrayOfDouble[1].length);
              System.arraycopy(arrayOfDouble[2], 0, arrayOfDouble8, arrayOfDouble[0].length + arrayOfDouble[1].length, arrayOfDouble[2].length);
              p2AppManagerUtils.writeFileOfArray(arrayOfDouble8, p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { this.a.C, str2 + File.separatorChar + this.a.D, "C2x.cal" }), "\n");
              p2AppManagerUtils.writeFileOfArray(arrayOfDouble[4], p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { this.a.C, str2 + File.separatorChar + this.a.D, "wl_corr.cal" }), "\n");
              p2AppManagerUtils.writeFileOfArray(arrayOfDouble[5], p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { this.a.C, str2 + File.separatorChar + this.a.D, "wavelength_corr.cal" }), "\n");
              b.a(this.b, this.a.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.b, this.a.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.b, this.a.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.CALIBRATION_GENERATION_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void a(String paramString1, String paramString2, a parama) {
    try {
      this.O.b(i.aM.a(), 0L, k.aM.a(), j.aM.a());
      this.O.b(i.aN.a(), 0L, k.aN.a(), j.aN.a());
      this.O.b(i.cX.a(), 0L, k.cX.a(), j.cX.a());
      this.O.b(i.cI.a(), 0L, k.cI.a(), j.cI.a());
      this.O.b(i.k.a(), 1L, k.k.a(), j.k.a());
      long[] arrayOfLong = this.O.b();
      PrintWriter printWriter = new PrintWriter(paramString1 + File.separatorChar + "t.reg", "UTF-8");
      for (long l1 : arrayOfLong)
        printWriter.println(Long.toHexString(l1)); 
      printWriter.close();
      Files.copy((new File(paramString2 + File.separatorChar + "param.conf")).toPath(), (new File(paramString1 + File.separatorChar + "param.conf")).toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
    } catch (Exception exception) {
      b.error(exception.getMessage());
    } 
  }
  
  private void g(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.c(this.c).a(this.b.C.getBytes());
              b.a(this.c, this.b.C);
              p2AppManagerUtils.createDir(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE)), new Object[] { b.b(this.c) }));
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.BURNING_SAMPLE_ID_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void h(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              long l = b.c(this.c).d();
              double[][] arrayOfDouble = { { l } };
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.BURNING_SAMPLE_ID_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void i(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.a(this.c, b.c(this.c).b());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.READING_ASIC_REGISTERS_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void j(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.c(this.c).a(this.b.E);
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_ASIC_REGISTERS_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void k(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.a(this.c, this.b.F);
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void l(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              p2AppManagerUtils.removeDir(p2Constants.getPath(p2Constants.TEMP_CONFIG_SAMPLE_PATH), true);
              if (this.b.G.equals(p2Enumerations.RestoreOptionsEnum.OPTICAL_GAIN_SETTINGS.getStringVal())) {
                String[] arrayOfString = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }), new ArrayList(), false);
                for (String str : arrayOfString) {
                  String[] arrayOfString1 = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }) + File.separator + str, new ArrayList(), false);
                  for (String str1 : arrayOfString1) {
                    String str2 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }) + File.separator + str + File.separator + str1 + File.separator + "corr.cal";
                    String str3 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }) + File.separator + str + File.separator + str1 + File.separator + "wavelength_corr.cal";
                    File file1 = new File(p2Constants.getPath(p2Constants.TEMP_CONFIG_SAMPLE_PATH) + File.separator + str + File.separator + str1 + File.separator + "corr.cal");
                    File file2 = new File(p2Constants.getPath(p2Constants.TEMP_CONFIG_SAMPLE_PATH) + File.separator + str + File.separator + str1 + File.separator + "wavelength_corr.cal");
                    try {
                      FileUtils.copyFile(new File(str2), file1);
                      FileUtils.copyFile(new File(str3), file2);
                    } catch (IOException iOException) {
                      b.v().error(iOException.getMessage() + "");
                      b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
                    } 
                  } 
                } 
              } else if (this.b.G.equals(p2Enumerations.RestoreOptionsEnum.CORRECTION_SETTINGS.getStringVal())) {
                String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { b.b(this.c) });
                File file = new File(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP_FILE_PATH));
                try {
                  FileUtils.copyFile(new File(str), file);
                } catch (IOException iOException) {
                  b.v().error(iOException.getMessage());
                  b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
                } 
              } 
              b.g(this.c);
              if (this.b.G.equals(p2Enumerations.RestoreOptionsEnum.OPTICAL_GAIN_SETTINGS.getStringVal())) {
                String[] arrayOfString = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }), new ArrayList(), false);
                for (String str : arrayOfString) {
                  String[] arrayOfString1 = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }) + File.separator + str, new ArrayList(), false);
                  for (String str1 : arrayOfString1) {
                    String str2 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }) + File.separator + str + File.separator + str1 + File.separator + "corr.cal";
                    String str3 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { b.b(this.c) }) + File.separator + str + File.separator + str1 + File.separator + "wavelength_corr.cal";
                    File file1 = new File(p2Constants.getPath(p2Constants.TEMP_CONFIG_SAMPLE_PATH) + File.separator + str + File.separator + str1 + File.separator + "corr.cal");
                    File file2 = new File(p2Constants.getPath(p2Constants.TEMP_CONFIG_SAMPLE_PATH) + File.separator + str + File.separator + str1 + File.separator + "wavelength_corr.cal");
                    try {
                      Files.delete((new File(str2)).toPath());
                      Files.delete((new File(str3)).toPath());
                      FileUtils.moveFile(file1, new File(str2));
                      FileUtils.moveFile(file2, new File(str3));
                    } catch (IOException iOException) {
                      b.v().error(iOException.getMessage());
                      b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
                    } 
                  } 
                } 
              } else if (this.b.G.equals(p2Enumerations.RestoreOptionsEnum.CORRECTION_SETTINGS.getStringVal())) {
                String str1 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { b.b(this.c) });
                String str2 = p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP_FILE_PATH);
                try {
                  Files.delete((new File(str1)).toPath());
                  FileUtils.moveFile(new File(str2), new File(str1));
                } catch (IOException iOException) {
                  b.v().error(iOException.getMessage());
                  b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
                } 
              } 
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void m(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.h(this.c);
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void a(a parama, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString) { c.a(new a<Boolean>(this, paramBoolean1, parama, paramArrayOfString, paramBoolean2) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.e, b.a(this.e)); 
              String str1 = p2Constants.getPath(p2Constants.TEMP_CONFIG_SAMPLE_PATH);
              p2AppManagerUtils.removeDir(str1, true);
              String str2 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { b.b(this.e) });
              File file = new File(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP_FILE_PATH));
              try {
                FileUtils.copyFile(new File(str2), file);
              } catch (IOException iOException) {
                b.v().error(iOException.getMessage());
                b.a(this.e, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
              } 
              b.i(this.e);
              this.e.b(this.c);
              b.a(this.e, this.d);
              try {
                FileUtils.deleteQuietly(new File(str2));
                FileUtils.copyFile(file, new File(str2));
              } catch (IOException iOException) {
                b.v().error(iOException.getMessage());
                b.a(this.e, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
              } 
              p2AppManagerUtils.removeDir(str1, true);
              b.a(this.e, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.e, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.e, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void n(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              b.j(this.c);
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.READING_PROFILES_FROM_ROM_ERROR);
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void o(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              String str1 = b.b(this.c, b.k(this.c));
              if (b.l(this.c).equals(str1 + File.separatorChar + b.k(this.c))) {
                b.b(this.c, false);
              } else {
                b.c(this.c, str1 + File.separatorChar + b.k(this.c));
                b.b(this.c, true);
              } 
              b.d(this.c, str1);
              String str2 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + "two_points_corr" });
              if (p2Enumerations.p2AppManagerState.selfCorr_Run == this.b.a && !p2AppManagerUtils.exist(str2))
                throw new p2AppManagerException("Failed to find correction folder   ", p2Enumerations.p2AppManagerStatus.TWO_POINTS_CORR_CALIB_FOLDER_ERROR.getNumVal()); 
              b.c(this.c, true);
              if (b.m(this.c)) {
                File file = new File(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                if (file.exists() && !b.k(this.c).equals("two_points_corr")) {
                  String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                  double[] arrayOfDouble1 = new double[arrayOfString.length];
                  for (byte b2 = 0; b2 < arrayOfString.length; b2++)
                    arrayOfDouble1[b2] = Double.parseDouble(arrayOfString[b2]); 
                  p2AppManagerUtils.writeFileOfArray(arrayOfDouble1, p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), b.l(this.c), "corr.cal" }), new Object[0]), "\n");
                } 
                b.v().info("loading sample folder started");
                b.a(this.c, b.c(this.c), b.n(this.c), b.b(this.c), b.l(this.c));
                b.v().info("loading sample folder finished");
                b.d(this.c, true);
              } 
              if (b.o(this.c)) {
                b.v().info("writing t reg file started");
                try {
                  b.c(this.c).a(b.n(this.c).c());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to setASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
                } 
                b.v().info("writing t reg file finished");
              } 
              if (b.p(this.c)) {
                b.v().info("writing optical settings started");
                try {
                  b.b(this.c, b.q(this.c), p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { b.b(this.c) }), this.b);
                } catch (Exception exception) {
                  throw new p2AppManagerException(exception.getMessage(), p2Enumerations.p2AppManagerStatus.GAIN_OPTIONS_ERROR.getNumVal());
                } 
                int i = 0;
                try {
                  i = (int)b.c(this.c).b(i.fy.a(), k.fy.a(), j.fy.a());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to readASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_READING_ERROR.getNumVal());
                } 
                double d = Math.pow(2.0D, i) * 5000.0D * this.b.p * this.b.q;
                b.n(this.c).a(d);
                b.v().info("Current Range:" + this.b.o);
                b.v().info("PGA1: " + this.b.p);
                b.v().info("PGA2: " + this.b.q);
                b.v().info("Param.conf[I_adc_gain] = " + b.n(this.c).b()[9]);
                b.v().info("writing optical settings finished");
              } 
              b.a a1 = b.b(this.c, b.a(this.c), this.b);
              Future future = null;
              int[][] arrayOfInt = new int[b.r(this.c).length][];
              for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
                arrayOfInt[b1] = new int[b.r(this.c)[b1].length];
                for (byte b2 = 0; b2 < arrayOfInt[b1].length; b2++)
                  arrayOfInt[b1][b2] = (int)b.r(this.c)[b1][b2]; 
              } 
              if (p2Enumerations.p2AppManagerState.wavelengthCalibration_Run == this.b.a) {
                future = b.a(this.c, b.c(this.c), arrayOfInt, a1, b.n(this.c), b.s(this.c));
              } else {
                future = b.a(this.c, b.c(this.c), arrayOfInt, a1, b.n(this.c), b.t(this.c));
              } 
              double[][] arrayOfDouble = (double[][])null;
              try {
                b.v().info("begin DSP process...");
                arrayOfDouble = (double[][])future.get();
                b.v().info("end DSP process.");
              } catch (InterruptedException interruptedException) {
                b.v().error(interruptedException.getMessage());
                throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
              } catch (ExecutionException executionException) {
                b.v().error(executionException.getMessage());
                if (executionException.getCause() instanceof p2AppManagerException)
                  throw (p2AppManagerException)executionException.getCause(); 
                throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
              } 
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              if (p2Enumerations.p2AppManagerState.wavelengthCalibration_Run == this.b.a) {
                double[] arrayOfDouble1 = null;
                arrayOfDouble1 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.STANDARD_CALIBRATORS_FOLDER_PATH) + File.separatorChar + this.b.Y + ".txt");
                if (arrayOfDouble1 == null)
                  throw new p2AppManagerException("Failed to load standard calibrator file ", p2Enumerations.p2AppManagerStatus.WHITE_FILE_NOT_EXIST_ERROR.getNumVal()); 
                ArrayList arrayList = new ArrayList();
                for (b2 = 0; b2 < arrayOfDouble1.length; b2++) {
                  if (arrayOfDouble1[b2] < b.n(this.c).b()[24] * 1000.0D && arrayOfDouble1[b2] > b.n(this.c).b()[23] * 1000.0D)
                    arrayList.add(Double.valueOf(arrayOfDouble1[b2])); 
                } 
                if (arrayList.size() != 0) {
                  arrayOfDouble1 = new double[arrayList.size()];
                  for (b2 = 0; b2 < arrayList.size(); b2++)
                    arrayOfDouble1[b2] = ((Double)arrayList.get(b2)).doubleValue(); 
                } else {
                  throw new p2AppManagerException("Calibrator has no wavelengths in the detector range ", p2Enumerations.p2AppManagerStatus.WAVELENGTH_CALIBRATION_ERROR.getNumVal());
                } 
                try {
                  if ((int)b.n(this.c).b()[56] != 1) {
                    String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + b.k(this.c), "wavelength_corr.cal" }));
                    double[] arrayOfDouble2 = new double[arrayOfString.length];
                    for (byte b3 = 0; b3 < arrayOfString.length; b3++)
                      arrayOfDouble2[b3] = Double.parseDouble(arrayOfString[b3]); 
                    double[][] arrayOfDouble3 = p2SpectroDSP.a().a(arrayOfDouble[2], arrayOfDouble[3], arrayOfDouble1, 0, (int)b.n(this.c).b()[54]);
                    double[] arrayOfDouble4 = new double[arrayOfDouble3[0].length];
                    for (byte b4 = 0; b4 < arrayOfDouble3[0].length; b4++)
                      arrayOfDouble4[b4] = arrayOfDouble2[b4] * arrayOfDouble3[0][0]; 
                    arrayOfDouble4[arrayOfDouble4.length - 1] = arrayOfDouble2[arrayOfDouble2.length - 1] + arrayOfDouble3[0][1];
                    p2AppManagerUtils.writeFileOfArray(arrayOfDouble4, p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + b.k(this.c), "wavelength_corr.cal" }), "\n");
                    arrayOfDouble4 = null;
                  } 
                } catch (a b2) {
                  a a2;
                  throw new p2AppManagerException("Error while make DSP data wavelength calibration ", p2Enumerations.p2AppManagerStatus.WAVELENGTH_CALIBRATION_ERROR.getNumVal());
                } 
                arrayOfDouble1 = null;
                b.c(this.c, "");
              } 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void p(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              String str1 = b.b(this.c, b.k(this.c));
              if (b.l(this.c).equals(str1 + File.separatorChar + b.k(this.c))) {
                b.b(this.c, false);
              } else {
                b.c(this.c, str1 + File.separatorChar + b.k(this.c));
                b.b(this.c, true);
              } 
              b.d(this.c, str1);
              String str2 = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + "two_points_corr" });
              if (p2Enumerations.p2AppManagerState.selfCorr_Run == this.b.a && !p2AppManagerUtils.exist(str2))
                throw new p2AppManagerException("Failed to find correction folder   ", p2Enumerations.p2AppManagerStatus.TWO_POINTS_CORR_CALIB_FOLDER_ERROR.getNumVal()); 
              b.c(this.c, true);
              if (b.m(this.c)) {
                File file = new File(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                if (file.exists() && !b.k(this.c).equals("two_points_corr")) {
                  String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                  double[] arrayOfDouble1 = new double[arrayOfString.length];
                  for (byte b1 = 0; b1 < arrayOfString.length; b1++)
                    arrayOfDouble1[b1] = Double.parseDouble(arrayOfString[b1]); 
                  p2AppManagerUtils.writeFileOfArray(arrayOfDouble1, p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), b.l(this.c), "corr.cal" }), new Object[0]), "\n");
                } 
                b.v().info("loading sample folder started");
                b.a(this.c, b.c(this.c), b.n(this.c), b.b(this.c), b.l(this.c));
                b.v().info("loading sample folder finished");
                b.d(this.c, true);
              } 
              if (b.o(this.c)) {
                b.v().info("writing t reg file started");
                try {
                  b.c(this.c).a(b.n(this.c).c());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to setASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
                } 
                b.v().info("writing t reg file finished");
              } 
              if (b.p(this.c)) {
                b.v().info("writing optical settings started");
                try {
                  b.b(this.c, b.q(this.c), p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { b.b(this.c) }), this.b);
                } catch (Exception exception) {
                  throw new p2AppManagerException(exception.getMessage(), p2Enumerations.p2AppManagerStatus.GAIN_OPTIONS_ERROR.getNumVal());
                } 
                int i = 0;
                try {
                  i = (int)b.c(this.c).b(i.fy.a(), k.fy.a(), j.fy.a());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to readASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_READING_ERROR.getNumVal());
                } 
                double d = Math.pow(2.0D, i) * 5000.0D * this.b.p * this.b.q;
                b.n(this.c).a(d);
                b.v().info("Current Range:" + this.b.o);
                b.v().info("PGA1: " + this.b.p);
                b.v().info("PGA2: " + this.b.q);
                b.v().info("Param.conf[I_adc_gain] = " + b.n(this.c).b()[9]);
                b.v().info("writing optical settings finished");
              } 
              boolean bool1 = true;
              if (b.n(this.c).b()[47] != 0.0D)
                bool1 = false; 
              boolean bool2 = false;
              try {
                bool2 = b.c(this.c).a(bool1);
              } catch (a a2) {
                throw new p2AppManagerException("Failed to read act register ", p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR.getNumVal());
              } 
              if (!bool2)
                try {
                  b.c(this.c).a(true, bool1, (int)b.a(this.c).b()[48]);
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation started");
                  try {
                    Thread.sleep((long)b.a(this.c).b()[12]);
                  } catch (InterruptedException interruptedException) {
                    b.v().error(interruptedException.getMessage());
                  } 
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation finished");
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to start actuation ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
                }  
              b.a a1 = b.b(this.c, b.a(this.c), this.b);
              double[][] arrayOfDouble = b.l(this.c, a1, b.a(this.c));
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              if (p2Enumerations.p2AppManagerState.wavelengthCalibration_Run == this.b.a) {
                double[] arrayOfDouble1 = null;
                arrayOfDouble1 = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.STANDARD_CALIBRATORS_FOLDER_PATH) + File.separatorChar + this.b.Y + ".txt");
                if (arrayOfDouble1 == null)
                  throw new p2AppManagerException("Failed to load standard calibrator file ", p2Enumerations.p2AppManagerStatus.WHITE_FILE_NOT_EXIST_ERROR.getNumVal()); 
                ArrayList arrayList = new ArrayList();
                for (b1 = 0; b1 < arrayOfDouble1.length; b1++) {
                  if (arrayOfDouble1[b1] < b.n(this.c).b()[24] * 1000.0D && arrayOfDouble1[b1] > b.n(this.c).b()[23] * 1000.0D)
                    arrayList.add(Double.valueOf(arrayOfDouble1[b1])); 
                } 
                if (arrayList.size() != 0) {
                  arrayOfDouble1 = new double[arrayList.size()];
                  for (b1 = 0; b1 < arrayList.size(); b1++)
                    arrayOfDouble1[b1] = ((Double)arrayList.get(b1)).doubleValue(); 
                } else {
                  throw new p2AppManagerException("Calibrator has no wavelengths in the detector range ", p2Enumerations.p2AppManagerStatus.WAVELENGTH_CALIBRATION_ERROR.getNumVal());
                } 
                try {
                  if ((int)b.n(this.c).b()[56] != 1) {
                    String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + b.k(this.c), "wavelength_corr.cal" }));
                    double[] arrayOfDouble2 = new double[arrayOfString.length];
                    for (byte b2 = 0; b2 < arrayOfString.length; b2++)
                      arrayOfDouble2[b2] = Double.parseDouble(arrayOfString[b2]); 
                    double[][] arrayOfDouble3 = p2SpectroDSP.a().a(arrayOfDouble[2], arrayOfDouble[3], arrayOfDouble1, 0, (int)b.n(this.c).b()[56]);
                    double[] arrayOfDouble4 = new double[arrayOfDouble3[0].length];
                    for (byte b3 = 0; b3 < arrayOfDouble3[0].length; b3++)
                      arrayOfDouble4[b3] = arrayOfDouble2[b3] * arrayOfDouble3[0][0]; 
                    arrayOfDouble4[arrayOfDouble4.length - 1] = arrayOfDouble2[arrayOfDouble2.length - 1] + arrayOfDouble3[0][1];
                    p2AppManagerUtils.writeFileOfArray(arrayOfDouble4, p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.c), str1 + File.separatorChar + b.k(this.c), "wavelength_corr.cal" }), "\n");
                    arrayOfDouble4 = null;
                  } 
                } catch (a b1) {
                  a a2;
                  throw new p2AppManagerException("Error while make DSP data wavelength calibration ", p2Enumerations.p2AppManagerStatus.WAVELENGTH_CALIBRATION_ERROR.getNumVal());
                } 
                arrayOfDouble1 = null;
                b.c(this.c, "");
              } 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void b(a parama) { c.a(new a<Boolean>(this, parama) {
          protected Boolean a() {
            try {
              String str = b.b(this.b, b.k(this.b));
              if (b.l(this.b).equals(str + File.separatorChar + b.k(this.b))) {
                b.c(this.b, false);
              } else {
                b.c(this.b, str + File.separatorChar + b.k(this.b));
                b.c(this.b, true);
              } 
              b.d(this.b, str);
              if (b.m(this.b)) {
                File file = new File(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.b), str + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                if (file.exists() && !b.k(this.b).equals("two_points_corr")) {
                  String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.b), str + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                  double[] arrayOfDouble = new double[arrayOfString.length];
                  for (byte b2 = 0; b2 < arrayOfString.length; b2++)
                    arrayOfDouble[b2] = Double.parseDouble(arrayOfString[b2]); 
                  p2AppManagerUtils.writeFileOfArray(arrayOfDouble, p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.b), b.l(this.b), "corr.cal" }), new Object[0]), "\n");
                } 
                b.v().info("loading sample folder started");
                b.a(this.b, b.c(this.b), b.n(this.b), b.b(this.b), b.l(this.b));
                b.v().info("loading sample folder finished");
              } 
              double d1 = b.n(this.b).b()[19];
              double d2 = b.n(this.b).b()[22];
              b.n(this.b).b()[19] = this.a.af;
              b.n(this.b).b()[22] = b.n(this.b).b()[22] * this.a.ag;
              double[] arrayOfDouble1 = new double[b.u(this.b)[1].length];
              for (byte b1 = 0; b1 < b.u(this.b)[1].length; b1++)
                arrayOfDouble1[b1] = b.u(this.b)[1][b1] / 1000.0D; 
              double[][] arrayOfDouble2 = (double[][])null;
              try {
                arrayOfDouble2 = p2SpectroDSP.a().a(b.n(this.b).b(), b.u(this.b)[0], arrayOfDouble1, this.a.d, b.n(this.b).i());
              } catch (a a1) {
                throw new p2AppManagerException("Error while make DSP data update FFT settings", p2Enumerations.p2AppManagerStatus.DSP_UPDATE_FFT_SETTINGS_ERROR.getNumVal());
              } 
              if (arrayOfDouble2 == null || arrayOfDouble2[0].length == 0 || arrayOfDouble2[1].length == 0)
                throw new p2AppManagerException("Data returned from DSP is empty    ", p2Enumerations.p2AppManagerStatus.DSP_UPDATE_FFT_SETTINGS_ERROR.getNumVal()); 
              double[][] arrayOfDouble3 = new double[5][];
              arrayOfDouble3[0] = new double[b.u(this.b)[0].length];
              System.arraycopy(b.u(this.b)[0], 0, arrayOfDouble3[0], 0, b.u(this.b)[0].length);
              arrayOfDouble3[1] = new double[b.u(this.b)[1].length];
              System.arraycopy(b.u(this.b)[1], 0, arrayOfDouble3[1], 0, b.u(this.b)[1].length);
              arrayOfDouble3[4] = new double[b.u(this.b)[4].length];
              System.arraycopy(b.u(this.b)[4], 0, arrayOfDouble3[4], 0, b.u(this.b)[4].length);
              arrayOfDouble3[2] = new double[arrayOfDouble2[0].length];
              System.arraycopy(arrayOfDouble2[0], 0, arrayOfDouble3[2], 0, arrayOfDouble2[0].length);
              arrayOfDouble3[3] = new double[arrayOfDouble2[1].length];
              System.arraycopy(arrayOfDouble2[1], 0, arrayOfDouble3[3], 0, arrayOfDouble2[1].length);
              b.a(this.b, arrayOfDouble3);
              arrayOfDouble2 = (double[][])null;
              double[] arrayOfDouble4 = arrayOfDouble3[0];
              double[] arrayOfDouble5 = arrayOfDouble3[2];
              double[] arrayOfDouble6 = arrayOfDouble3[3];
              double[] arrayOfDouble7 = arrayOfDouble3[1];
              boolean bool = b.b(this.b, arrayOfDouble7);
              b.a(this.b, this.a, bool, b.n(this.b), arrayOfDouble4, arrayOfDouble7, arrayOfDouble5, arrayOfDouble6);
              b.a(this.b, b.n(this.b).i(), this.a, arrayOfDouble3, (double[][])null);
              b.n(this.b).b()[19] = d1;
              b.n(this.b).b()[22] = d2;
              b.a(this.b, this.a.a.getDeviceAtion(), arrayOfDouble3, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.b, this.a.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void c(a parama) { c.a(new a<Boolean>(this, parama) {
          protected Boolean a() {
            try {
              String str = b.b(this.b, b.k(this.b));
              if (b.l(this.b).equals(str + File.separatorChar + b.k(this.b))) {
                b.c(this.b, false);
              } else {
                b.c(this.b, str + File.separatorChar + b.k(this.b));
                b.c(this.b, true);
              } 
              b.d(this.b, str);
              if (b.m(this.b)) {
                File file = new File(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.b), str + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                if (file.exists() && !b.k(this.b).equals("two_points_corr")) {
                  String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.b), str + File.separatorChar + "two_points_corr", "corr.cal" }), new Object[0]));
                  double[] arrayOfDouble = new double[arrayOfString.length];
                  for (byte b1 = 0; b1 < arrayOfString.length; b1++)
                    arrayOfDouble[b1] = Double.parseDouble(arrayOfString[b1]); 
                  p2AppManagerUtils.writeFileOfArray(arrayOfDouble, p2AppManagerUtils.formatString(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { b.b(this.b), b.l(this.b), "corr.cal" }), new Object[0]), "\n");
                } 
                b.v().info("loading sample folder started");
                b.a(this.b, b.c(this.b), b.n(this.b), b.b(this.b), b.l(this.b));
                b.v().info("loading sample folder finished");
              } 
              double d1 = b.n(this.b).b()[19];
              double d2 = b.n(this.b).b()[22];
              b.n(this.b).b()[19] = this.a.af;
              b.n(this.b).b()[22] = b.n(this.b).b()[22] * this.a.ag;
              double[][] arrayOfDouble1 = (double[][])null;
              try {
                arrayOfDouble1 = p2SpectroDSP.a().a(b.n(this.b).b(), b.t(this.b)[0], b.t(this.b)[1], this.a.d, b.n(this.b).i());
              } catch (a a1) {
                throw new p2AppManagerException("Error while make DSP data update FFT settings", p2Enumerations.p2AppManagerStatus.DSP_UPDATE_FFT_SETTINGS_ERROR.getNumVal());
              } 
              if (arrayOfDouble1 == null || arrayOfDouble1[0].length == 0 || arrayOfDouble1[1].length == 0)
                throw new p2AppManagerException("Data returned from DSP is empty    ", p2Enumerations.p2AppManagerStatus.DSP_UPDATE_FFT_SETTINGS_ERROR.getNumVal()); 
              double[][] arrayOfDouble2 = new double[5][];
              arrayOfDouble2[0] = new double[b.t(this.b)[0].length];
              System.arraycopy(b.t(this.b)[0], 0, arrayOfDouble2[0], 0, b.t(this.b)[0].length);
              arrayOfDouble2[1] = new double[b.t(this.b)[1].length];
              System.arraycopy(b.t(this.b)[1], 0, arrayOfDouble2[1], 0, b.t(this.b)[1].length);
              arrayOfDouble2[4] = new double[b.t(this.b)[4].length];
              System.arraycopy(b.t(this.b)[4], 0, arrayOfDouble2[4], 0, b.t(this.b)[4].length);
              arrayOfDouble2[2] = new double[arrayOfDouble1[0].length];
              System.arraycopy(arrayOfDouble1[0], 0, arrayOfDouble2[2], 0, arrayOfDouble1[0].length);
              arrayOfDouble2[3] = new double[arrayOfDouble1[1].length];
              System.arraycopy(arrayOfDouble1[1], 0, arrayOfDouble2[3], 0, arrayOfDouble1[1].length);
              arrayOfDouble1 = (double[][])null;
              double[] arrayOfDouble3 = arrayOfDouble2[0];
              double[] arrayOfDouble4 = arrayOfDouble2[2];
              double[] arrayOfDouble5 = arrayOfDouble2[3];
              double[] arrayOfDouble6 = arrayOfDouble2[1];
              boolean bool = b.b(this.b, arrayOfDouble6);
              b.a(this.b, this.a, bool, b.n(this.b), arrayOfDouble3, arrayOfDouble6, arrayOfDouble4, arrayOfDouble5);
              try {
                arrayOfDouble1 = p2SpectroDSP.a().a(b.n(this.b).b(), b.v(this.b)[0], b.v(this.b)[1], this.a.d, b.n(this.b).i());
              } catch (a a1) {
                throw new p2AppManagerException("Error while make DSP data update FFT settings", p2Enumerations.p2AppManagerStatus.DSP_UPDATE_FFT_SETTINGS_ERROR.getNumVal());
              } 
              if (arrayOfDouble1 == null || arrayOfDouble1[0].length == 0 || arrayOfDouble1[1].length == 0)
                throw new p2AppManagerException("Data returned from DSP is empty    ", p2Enumerations.p2AppManagerStatus.DSP_UPDATE_FFT_SETTINGS_ERROR.getNumVal()); 
              double[][] arrayOfDouble7 = new double[5][];
              arrayOfDouble7[0] = new double[b.v(this.b)[0].length];
              System.arraycopy(b.v(this.b)[0], 0, arrayOfDouble7[0], 0, b.v(this.b)[0].length);
              arrayOfDouble7[1] = new double[b.v(this.b)[1].length];
              System.arraycopy(b.v(this.b)[1], 0, arrayOfDouble7[1], 0, b.v(this.b)[1].length);
              arrayOfDouble7[4] = new double[b.v(this.b)[4].length];
              System.arraycopy(b.v(this.b)[4], 0, arrayOfDouble7[4], 0, b.v(this.b)[4].length);
              arrayOfDouble7[2] = new double[arrayOfDouble1[0].length];
              System.arraycopy(arrayOfDouble1[0], 0, arrayOfDouble7[2], 0, arrayOfDouble1[0].length);
              arrayOfDouble7[3] = new double[arrayOfDouble1[1].length];
              System.arraycopy(arrayOfDouble1[1], 0, arrayOfDouble7[3], 0, arrayOfDouble1[1].length);
              arrayOfDouble1 = (double[][])null;
              arrayOfDouble3 = arrayOfDouble7[0];
              arrayOfDouble4 = arrayOfDouble7[2];
              arrayOfDouble5 = arrayOfDouble7[3];
              arrayOfDouble6 = arrayOfDouble7[1];
              bool = b.b(this.b, arrayOfDouble6);
              b.a(this.b, this.a, bool, b.n(this.b), arrayOfDouble3, arrayOfDouble6, arrayOfDouble4, arrayOfDouble5);
              b.a(this.b, b.n(this.b).i(), this.a, arrayOfDouble7, arrayOfDouble2);
              b.n(this.b).b()[19] = d1;
              b.n(this.b).b()[22] = d2;
              b.a(this.b, this.a.a.getDeviceAtion(), arrayOfDouble7, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.b, this.a.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void q(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              String str = b.b(this.c, b.k(this.c));
              if (b.l(this.c).equals(str + File.separatorChar + b.k(this.c))) {
                b.c(this.c, false);
              } else {
                b.c(this.c, str + File.separatorChar + b.k(this.c));
                b.c(this.c, true);
              } 
              if (b.m(this.c)) {
                b.v().info("loading sample folder started");
                b.a(this.c, b.c(this.c), b.n(this.c), b.b(this.c), b.l(this.c));
                b.v().info("loading sample folder finished");
                b.b(this.c, true);
                b.d(this.c, true);
              } 
              if (b.o(this.c)) {
                b.v().info("writing t reg file started");
                try {
                  b.c(this.c).a(b.n(this.c).c());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to setASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
                } 
                b.v().info("writing t reg file finished");
              } 
              if (b.p(this.c)) {
                b.v().info("writing optical settings started");
                try {
                  b.b(this.c, b.q(this.c), p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { b.b(this.c) }), this.b);
                } catch (Exception exception) {
                  throw new p2AppManagerException(exception.getMessage(), p2Enumerations.p2AppManagerStatus.GAIN_OPTIONS_ERROR.getNumVal());
                } 
                int i = 0;
                try {
                  i = (int)b.c(this.c).b(i.fy.a(), k.fy.a(), j.fy.a());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to readASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_READING_ERROR.getNumVal());
                } 
                double d = Math.pow(2.0D, i) * 5000.0D * this.b.p * this.b.q;
                b.n(this.c).a(d);
                b.v().info("Current Range:" + this.b.o);
                b.v().info("PGA1: " + this.b.p);
                b.v().info("PGA2: " + this.b.q);
                b.v().info("Param.conf[I_adc_gain] = " + b.n(this.c).b()[9]);
                b.v().info("writing optical settings finished");
              } 
              boolean bool1 = true;
              if (b.n(this.c).b()[47] != 0.0D)
                bool1 = false; 
              boolean bool2 = false;
              if (bool1) {
                try {
                  bool2 = b.c(this.c).a(bool1);
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to read act register ", p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR.getNumVal());
                } 
              } else {
                bool2 = false;
                try {
                  b.c(this.c).a(false, bool1, (int)b.a(this.c).b()[48]);
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to read act register ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
                } 
              } 
              if (!bool2)
                try {
                  b.c(this.c).a(true, bool1, (int)b.a(this.c).b()[48]);
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation started");
                  try {
                    Thread.sleep((long)b.a(this.c).b()[12]);
                  } catch (InterruptedException interruptedException) {
                    b.v().error(interruptedException.getMessage());
                  } 
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation finished");
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to start actuation ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
                }  
              b.a a1 = b.b(this.c, b.a(this.c), this.b);
              double[][] arrayOfDouble = b.m(this.c, a1, b.a(this.c));
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void r(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              String str = b.b(this.c, b.k(this.c));
              if (b.l(this.c).equals(str + File.separatorChar + b.k(this.c))) {
                b.c(this.c, false);
              } else {
                b.c(this.c, str + File.separatorChar + b.k(this.c));
                b.c(this.c, true);
              } 
              if (b.m(this.c)) {
                b.v().info("loading sample folder started");
                b.a(this.c, b.c(this.c), b.n(this.c), b.b(this.c), b.l(this.c));
                b.v().info("loading sample folder finished");
                b.b(this.c, true);
                b.d(this.c, true);
              } 
              if (b.o(this.c)) {
                b.v().info("writing t reg file started");
                try {
                  b.c(this.c).a(b.n(this.c).c());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to setASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
                } 
                b.v().info("writing t reg file finished");
              } 
              if (b.p(this.c)) {
                b.v().info("writing optical settings started");
                try {
                  b.b(this.c, b.q(this.c), p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { b.b(this.c) }), this.b);
                } catch (Exception exception) {
                  throw new p2AppManagerException(exception.getMessage(), p2Enumerations.p2AppManagerStatus.GAIN_OPTIONS_ERROR.getNumVal());
                } 
                int i = 0;
                try {
                  i = (int)b.c(this.c).b(i.fy.a(), k.fy.a(), j.fy.a());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to readASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_READING_ERROR.getNumVal());
                } 
                double d = Math.pow(2.0D, i) * 5000.0D * this.b.p * this.b.q;
                b.n(this.c).a(d);
                b.v().info("Current Range:" + this.b.o);
                b.v().info("PGA1: " + this.b.p);
                b.v().info("PGA2: " + this.b.q);
                b.v().info("Param.conf[I_adc_gain] = " + b.n(this.c).b()[9]);
                b.v().info("writing optical settings finished");
              } 
              boolean bool1 = true;
              if (b.n(this.c).b()[47] != 0.0D)
                bool1 = false; 
              boolean bool2 = false;
              if (bool1) {
                try {
                  bool2 = b.c(this.c).a(bool1);
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to read act register ", p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR.getNumVal());
                } 
              } else {
                bool2 = false;
                try {
                  b.c(this.c).a(false, bool1, (int)b.a(this.c).b()[48]);
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to read act register ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
                } 
              } 
              if (!bool2)
                try {
                  b.c(this.c).a(true, bool1, (int)b.a(this.c).b()[48]);
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation started");
                  try {
                    Thread.sleep((long)b.a(this.c).b()[12]);
                  } catch (InterruptedException interruptedException) {
                    b.v().error(interruptedException.getMessage());
                  } 
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation finished");
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to start actuation ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
                }  
              b.a a1 = b.b(this.c, b.a(this.c), this.b);
              double[][] arrayOfDouble = b.n(this.c, a1, b.a(this.c));
              if (arrayOfDouble == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void s(a parama, boolean paramBoolean) { c.a(new a<Boolean>(this, paramBoolean, parama) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.c, b.a(this.c)); 
              String str = b.b(this.c, b.k(this.c));
              if (b.l(this.c).equals(str + File.separatorChar + b.k(this.c))) {
                b.b(this.c, false);
              } else {
                b.c(this.c, str + File.separatorChar + b.k(this.c));
                b.b(this.c, true);
              } 
              b.v().info("loading sample folder started");
              b.a(this.c, b.c(this.c), b.n(this.c), b.b(this.c), b.l(this.c));
              b.v().info("loading sample folder finished");
              if (b.o(this.c)) {
                b.v().info("writing t reg file started");
                try {
                  b.c(this.c).a(b.n(this.c).c());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to setASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
                } 
                b.v().info("writing t reg file finished");
              } 
              boolean bool1 = true;
              if (b.n(this.c).b()[47] != 0.0D)
                bool1 = false; 
              boolean bool2 = false;
              if (bool1) {
                try {
                  bool2 = b.c(this.c).a(bool1);
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to read act register ", p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR.getNumVal());
                } 
              } else {
                bool2 = false;
                try {
                  b.c(this.c).a(false, bool1, (int)b.a(this.c).b()[48]);
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to read act register ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
                } 
              } 
              if (!bool2)
                try {
                  b.c(this.c).a(true, bool1, (int)b.a(this.c).b()[48]);
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation started");
                  try {
                    Thread.sleep((long)b.a(this.c).b()[12]);
                  } catch (InterruptedException interruptedException) {
                    b.v().error(interruptedException.getMessage());
                  } 
                  b.v().info("sleep for " + b.a(this.c).b()[12] + " after starting actuation finished");
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to start actuation ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
                }  
              double d1 = 512.0D * b.n(this.c).b()[49] / 1.35D;
              double d2 = 512.0D * b.n(this.c).b()[49];
              double d3 = 0.0D;
              double d4 = 0.0D;
              int i = 6;
              byte b1 = 0;
              boolean bool = false;
              b.a a1 = b.b(this.c, b.a(this.c), this.b);
              double d5 = Math.pow(2.0D, 4.0D) * this.b.aa / Math.pow(2.0D, this.b.ab);
              b.v().info("Gain optimization: " + (d5 * 512.0D));
              this.b.r = true;
              b.v().info("writing hpfBypass started");
              try {
                b.c(this.c).b(i.fD.a(), 1L, k.fD.a(), j.fD.a());
              } catch (a a2) {
                throw new p2AppManagerException("Failed to set HPFBYPASS=1   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
              } 
              b.v().info("writing hpfBypass finished");
              this.b.p = p2Constants.PGA1_values[b1];
              this.b.q = p2Constants.PGA2_values[bool];
              b.a(this.c, String.valueOf(this.b.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
              b.a(this.c, String.valueOf(this.b.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
              this.b.o = p2Constants.currentRanges[i];
              b.a(this.c, this.b.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
              b.v().info("DetectorAndCurrentRange: " + this.b.o);
              b.v().info("PGA1: " + this.b.p);
              b.v().info("PGA2: " + this.b.q);
              double[][] arrayOfDouble1 = b.o(this.c, a1, b.a(this.c));
              if (arrayOfDouble1 == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              d3 = arrayOfDouble1[0][0];
              for (byte b2 = 1; b2 < arrayOfDouble1[0].length; b2++) {
                d4 = (arrayOfDouble1[0][b2] < 0.0D) ? (arrayOfDouble1[0][b2] * -1.0D) : arrayOfDouble1[0][b2];
                d3 = (d3 > d4) ? d3 : d4;
              } 
              d3 /= d5;
              double d6 = d1 / d3;
              int j = (int)Math.floor(Math.log10(d6) / Math.log10(2.0D));
              if (j >= p2Constants.currentRanges.length) {
                b.v().error("No of steps in larger than current ranges! setting it to the max!");
                System.out.println("No of steps in larger than current ranges! setting it to the max!");
                j = p2Constants.currentRanges.length - 1;
              } 
              if (j < 0) {
                b.v().error("No of steps is -ve!");
                System.out.println("No of steps is -ve!");
                j = 0;
              } 
              i -= j;
              if (i < 0 || i > 6)
                i = 0; 
              this.b.o = p2Constants.currentRanges[i];
              b.a(this.c, this.b.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
              b.v().info("DetectorAndCurrentRange: " + this.b.o);
              double[][] arrayOfDouble2 = (double[][])null;
              this.b.r = false;
              b.v().info("writing hpfBypass started");
              try {
                b.c(this.c).b(i.fD.a(), 0L, k.fD.a(), j.fD.a());
              } catch (a a2) {
                throw new p2AppManagerException("Failed to set HPFBYPASS=1   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
              } 
              b.v().info("writing hpfBypass finished");
              b1 = 2;
              this.b.p = p2Constants.PGA1_values[b1];
              b.v().info("PGA1: " + this.b.p);
              b.a(this.c, String.valueOf(this.b.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
              b.v().info("DetectorAndCurrentRange: " + this.b.o);
              arrayOfDouble1 = b.o(this.c, a1, b.a(this.c));
              if (arrayOfDouble1 == null)
                throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
              d3 = arrayOfDouble1[0][0];
              for (byte b3 = 1; b3 < arrayOfDouble1[0].length; b3++) {
                d4 = (arrayOfDouble1[0][b3] < 0.0D) ? (arrayOfDouble1[0][b3] * -1.0D) : arrayOfDouble1[0][b3];
                d3 = (d3 > d4) ? d3 : d4;
              } 
              d3 /= d5;
              double d7 = d2 / d3;
              b.v().info("Max Abs: " + d3);
              b.v().info("Gain Factor: " + d7);
              byte b4;
              for (b4 = 0; b4 < this.c.a.length - 1 && (this.c.a[b4][2] > d7 * p2Constants.PGA1_values[b1] * p2Constants.PGA2_values[bool] || this.c.a[b4 + true][2] <= d7 * p2Constants.PGA1_values[b1] * p2Constants.PGA2_values[bool]); b4++);
              this.b.p = p2Constants.PGA1_values[this.c.a[b4][0]];
              this.b.q = p2Constants.PGA2_values[this.c.a[b4][1]];
              b.a(this.c, String.valueOf(this.b.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
              b.a(this.c, String.valueOf(this.b.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
              b.v().info("PGA1: " + this.b.p);
              b.v().info("PGA2: " + this.b.q);
              if (this.b.a == p2Enumerations.p2AppManagerState.gainAdjustSpecSampleRun) {
                double d8 = 1.0D;
                double[][] arrayOfDouble3 = { { i, this.c.a[b4][0], this.c.a[b4][1] } };
                b.v().info("writing optical settings started");
                this.b.o = p2Constants.currentRanges[(int)b.w(this.c)[0][0]];
                this.b.p = p2Constants.PGA1_values[(int)b.w(this.c)[0][1]];
                this.b.q = p2Constants.PGA2_values[(int)b.w(this.c)[0][2]];
                b.a(this.c, this.b.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
                b.a(this.c, String.valueOf(this.b.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
                b.a(this.c, String.valueOf(this.b.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
                int k = 0;
                try {
                  k = (int)b.c(this.c).b(i.fy.a(), k.fy.a(), j.fy.a());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to readASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_READING_ERROR.getNumVal());
                } 
                double d9 = Math.pow(2.0D, k) * 5000.0D * this.b.p * this.b.q;
                b.n(this.c).a(d9);
                b.v().info("Current Range: " + this.b.o);
                b.v().info("PGA1: " + this.b.p);
                b.v().info("PGA2: " + this.b.q);
                b.v().info("Param.conf[I_adc_gain] = " + b.n(this.c).b()[9]);
                b.v().info("writing optical settings finished");
                a1 = b.b(this.c, b.a(this.c), this.b);
                double[][] arrayOfDouble4 = b.l(this.c, a1, b.a(this.c));
                if (arrayOfDouble4 == null)
                  throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
                b.v().info("writing optical settings started");
                this.b.o = p2Constants.currentRanges[(int)arrayOfDouble3[0][0]];
                this.b.p = p2Constants.PGA1_values[(int)arrayOfDouble3[0][1]];
                this.b.q = p2Constants.PGA2_values[(int)arrayOfDouble3[0][2]];
                b.a(this.c, this.b.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
                b.a(this.c, String.valueOf(this.b.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
                b.a(this.c, String.valueOf(this.b.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
                int m = 0;
                try {
                  m = (int)b.c(this.c).b(i.fy.a(), k.fy.a(), j.fy.a());
                } catch (a a2) {
                  throw new p2AppManagerException("Failed to readASICRegisters   ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_READING_ERROR.getNumVal());
                } 
                double d10 = Math.pow(2.0D, m) * 5000.0D * this.b.p * this.b.q;
                b.n(this.c).a(d10);
                b.v().info("Current Range:" + this.b.o);
                b.v().info("PGA1: " + this.b.p);
                b.v().info("PGA2: " + this.b.q);
                b.v().info("Param.conf[I_adc_gain] = " + b.n(this.c).b()[9]);
                b.v().info("writing optical settings finished");
                a1 = b.b(this.c, b.a(this.c), this.b);
                double[][] arrayOfDouble5 = b.l(this.c, a1, b.a(this.c));
                if (arrayOfDouble5 == null)
                  throw new p2AppManagerException("No valid result back for this p2Sample : " + b.b(this.c) + " run.", p2Enumerations.p2AppManagerStatus.NO_OF_SCANS_DSP_ERROR.getNumVal()); 
                b.a(this.c, arrayOfDouble5, arrayOfDouble4);
                for (byte b5 = 0; b5 < arrayOfDouble5[3].length; b5++)
                  arrayOfDouble5[3][b5] = Math.pow(10.0D, arrayOfDouble5[3][b5] / 10.0D); 
                double[] arrayOfDouble = new double[arrayOfDouble5[2].length];
                byte b6;
                for (b6 = 0; b6 < arrayOfDouble.length; b6++)
                  arrayOfDouble[b6] = 1.0E7D / arrayOfDouble5[2][b6]; 
                b6 = 0;
                double d11 = 0.0D;
                for (byte b7 = 0; b7 < arrayOfDouble.length; b7++) {
                  if (arrayOfDouble[b7] < b.n(this.c).b()[24] * 1000.0D - 100.0D && arrayOfDouble[b7] > b.n(this.c).b()[23] * 1000.0D + 100.0D) {
                    d11 += arrayOfDouble5[3][b7];
                    b6++;
                  } 
                } 
                d8 = d11 / b6;
                arrayOfDouble2 = new double[][] { { i, this.c.a[b4][0], this.c.a[b4][1] }, { d8 } };
              } else {
                if (this.b.a == p2Enumerations.p2AppManagerState.gainAdjustSpecBG_Run) {
                  arrayOfDouble2 = new double[][] { { i, this.c.a[b4][0], this.c.a[b4][1] }, { 1.0D } };
                  b.a(this.c, p2Enumerations.p2AppManagerState.gainAdjustSpecSampleRun.getDeviceAtion(), arrayOfDouble2, p2Enumerations.p2AppManagerStatus.NO_ERROR);
                } 
                arrayOfDouble2 = new double[][] { { i, this.c.a[b4][0], this.c.a[b4][1] } };
              } 
              b.a(this.c, this.b.a.getDeviceAtion(), arrayOfDouble2, p2Enumerations.p2AppManagerStatus.NO_ERROR);
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.c, this.b.a.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void a(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) { c.a(new a<Boolean>(this, paramBoolean1, paramBoolean2, paramBoolean3) {
          protected Boolean a() {
            try {
              if (this.a)
                b.a(this.d, b.a(this.d)); 
              try {
                b.c(this.d).a(this.b, this.c, (int)b.a(this.d).b()[48]);
                if (this.b)
                  try {
                    Thread.sleep((long)b.a(this.d).b()[12]);
                  } catch (InterruptedException interruptedException) {
                    b.v().error(interruptedException.getMessage());
                  }  
                b.a(this.d, p2Enumerations.p2AppManagerState.ActuationProfileSetting.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.NO_ERROR);
              } catch (a a1) {
                b.v().error(a1.getMessage());
                throw new p2AppManagerException(a1.getMessage(), p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR.getNumVal());
              } 
            } catch (p2AppManagerException p2AppManagerException) {
              b.v().error(p2AppManagerException.getMessage());
              b.a(this.d, p2Enumerations.p2AppManagerState.ActuationProfileSetting.getDeviceAtion(), (double[][])null, p2Enumerations.p2AppManagerStatus.getAppManagerStatusByCode(p2AppManagerException.getErrorCode()));
            } 
            return Boolean.valueOf(true);
          }
        }); }
  
  private void a(b paramb) {
    try {
      this.O.a(new boolean[0]);
      try {
        this.c = this.O.e();
      } catch (Exception exception) {
        this.c = "sampleId";
      } 
      try {
        A();
      } catch (Exception exception) {
        b.error(exception.getMessage());
      } 
      paramb.a("TAIFReg", this.O.f());
      this.O.a(paramb.c());
    } catch (NumberFormatException numberFormatException) {
      throw new p2AppManagerException("Invalid productId ", p2Enumerations.p2AppManagerStatus.INVALID_BOARD_CONFIGURATION_ERROR.getNumVal());
    } catch (p2AppManagerException p2AppManagerException) {
      throw p2AppManagerException;
    } catch (Exception exception) {
      b.error(exception.getMessage());
      throw new p2AppManagerException("Failed to initiate TAIFDriver   ", p2Enumerations.p2AppManagerStatus.INITIATE_TAIFDRIVER_ERROR.getNumVal());
    } 
  }
  
  private void a(String paramString1, String paramString2) {
    ArrayList arrayList1 = new ArrayList();
    ArrayList arrayList2 = new ArrayList();
    File file = new File(paramString2);
    if (file.exists()) {
      bufferedReader = null;
      try {
        bufferedReader = new BufferedReader(new FileReader(paramString2));
        str = null;
        while ((str = bufferedReader.readLine()) != null) {
          if (str.startsWith(".option") && str.contains(paramString1)) {
            while (!(str = bufferedReader.readLine()).equals(".end")) {
              if (!str.startsWith("#")) {
                String[] arrayOfString = str.split("=");
                if (arrayOfString.length == 2) {
                  arrayList1.add(arrayOfString[0].replaceAll(" ", ""));
                  arrayList2.add(Integer.valueOf(Integer.parseInt(arrayOfString[1].replaceAll(" ", ""))));
                } 
              } 
            } 
            break;
          } 
        } 
        for (byte b1 = 0; b1 < arrayList1.size(); b1++)
          this.O.b(i.valueOf((String)arrayList1.get(b1)).a(), ((Integer)arrayList2.get(b1)).intValue(), k.valueOf((String)arrayList1.get(b1)).a(), j.valueOf((String)arrayList1.get(b1)).a()); 
      } catch (Exception exception) {
        b.error(exception.getMessage());
        return;
      } finally {
        try {
          bufferedReader.close();
        } catch (Exception exception) {
          b.error(exception.getMessage());
        } 
      } 
    } 
  }
  
  private void b(String paramString1, String paramString2, a parama) {
    paramString1 = this.K + paramString1;
    ArrayList arrayList1 = new ArrayList();
    ArrayList arrayList2 = new ArrayList();
    File file = new File(paramString2);
    if (file.exists()) {
      bufferedReader = null;
      try {
        bufferedReader = new BufferedReader(new FileReader(paramString2));
        str = null;
        while ((str = bufferedReader.readLine()) != null) {
          if (str.startsWith(".option") && str.replace(".option ", "").equals(paramString1)) {
            while (!(str = bufferedReader.readLine()).equals(".end")) {
              if (!str.startsWith("#")) {
                String[] arrayOfString = str.split("=");
                if (arrayOfString.length == 2) {
                  arrayList1.add(arrayOfString[0].replaceAll(" ", ""));
                  arrayList2.add(arrayOfString[1].replaceAll(" ", ""));
                } 
              } 
            } 
            break;
          } 
        } 
        if (arrayList1.size() == 0)
          throw new Exception("Optical gain option not found"); 
        for (byte b1 = 0; b1 < arrayList1.size(); b1++) {
          if ((p2Enumerations.p2AppManagerState.InterferogramRun == parama.a && this.K == "_InterSpec_") || (p2Enumerations.p2AppManagerState.SNR_Run == parama.a && this.K == "_InterSpec_") || (p2Enumerations.p2AppManagerState.selfCorr_Run == parama.a && this.K == "_InterSpec_")) {
            if ("CURRENT_RANGE".equals(arrayList1.get(b1))) {
              parama.o = (String)arrayList2.get(b1);
              a(parama.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
            } 
            if ("PGA1".equals(arrayList1.get(b1))) {
              parama.p = Integer.parseInt((String)arrayList2.get(b1));
              a(String.valueOf(parama.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
            } 
            if ("PGA2".equals(arrayList1.get(b1))) {
              parama.q = Integer.parseInt((String)arrayList2.get(b1));
              a(String.valueOf(parama.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
            } 
          } else if ((p2Enumerations.p2AppManagerState.selfCorr_Run == parama.a && this.K == "_Spec_") || (p2Enumerations.p2AppManagerState.SpectroscopyBackgroundRun == parama.a && this.K == "_Spec_") || (p2Enumerations.p2AppManagerState.wavelengthCalibrationBG_Run == parama.a && this.K == "_Spec_")) {
            if ("BG_CURRENT_RANGE".equals(arrayList1.get(b1))) {
              parama.o = (String)arrayList2.get(b1);
              a(parama.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
            } 
            if ("BG_PGA1".equals(arrayList1.get(b1))) {
              parama.p = Integer.parseInt((String)arrayList2.get(b1));
              a(String.valueOf(parama.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
            } 
            if ("BG_PGA2".equals(arrayList1.get(b1))) {
              parama.q = Integer.parseInt((String)arrayList2.get(b1));
              a(String.valueOf(parama.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
            } 
          } else if ((p2Enumerations.p2AppManagerState.SpectroscopySampleRun == parama.a && this.K == "_Spec_") || (p2Enumerations.p2AppManagerState.wavelengthCalibration_Run == parama.a && this.K == "_Spec_") || (p2Enumerations.p2AppManagerState.StabilityRun == parama.a && this.K == "_Spec_")) {
            if ("Sample_CURRENT_RANGE".equals(arrayList1.get(b1))) {
              parama.o = (String)arrayList2.get(b1);
              a(parama.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
            } 
            if ("Sample_PGA1".equals(arrayList1.get(b1))) {
              parama.p = Integer.parseInt((String)arrayList2.get(b1));
              a(String.valueOf(parama.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
            } 
            if ("Sample_PGA2".equals(arrayList1.get(b1))) {
              parama.q = Integer.parseInt((String)arrayList2.get(b1));
              a(String.valueOf(parama.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
            } 
            if ("ERROR".equals(arrayList1.get(b1)))
              this.M = Double.parseDouble((String)arrayList2.get(b1)); 
          } 
        } 
      } catch (Exception exception) {
        b.error(exception.getMessage());
        throw exception;
      } finally {
        try {
          bufferedReader.close();
        } catch (Exception exception) {
          b.error(exception.getMessage());
        } 
      } 
    } 
  }
  
  private a a(b paramb, a parama) {
    b.info("prepareRunConfigDataInterp function started");
    parama.b = this.C.b()[11];
    b.info("actFreq: " + parama.b);
    p2Constants.MAX_RUNTIME_MS = 1.6384E7D / parama.b;
    parama.Z = a(parama.ac);
    b.info("noOfRuns: " + parama.Z);
    parama.ac = (parama.Z == 1) ? parama.ac : (parama.ac / parama.Z);
    b.info("runTime: " + parama.ac);
    parama.aa = a(parama.ac, parama.b);
    b.info("noOfSlices: " + parama.aa);
    parama.ab = b(parama.aa);
    b.info("avgShiftBits: " + parama.ab);
    b.info("prepareRunConfigDataInterp function finished");
    return parama;
  }
  
  private a b(b paramb, a parama) {
    p2Constants.MAX_RUNTIME_MS = 1.6384E7D / parama.b;
    parama.Z = a(parama.ac);
    b.info("noOfRuns: " + parama.Z);
    parama.ac = (parama.Z == 1) ? parama.ac : (parama.ac / parama.Z);
    b.info("runTime: " + parama.ac);
    parama.aa = a(parama.ac, parama.b);
    b.info("noOfSlices: " + parama.aa);
    parama.ab = b(parama.aa);
    b.info("avgShiftBits: " + parama.ab);
    return parama;
  }
  
  private int a(double paramDouble) {
    if (paramDouble < 10.0D)
      throw new p2AppManagerException("Invalid run time value < 10M second  ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_TIME_ERROR.getNumVal()); 
    double d1 = paramDouble;
    double d2 = paramDouble;
    byte b1 = 1;
    while (d2 > p2Constants.MAX_RUNTIME_MS)
      d2 = d1 / ++b1; 
    return b1;
  }
  
  private int a(double paramDouble1, double paramDouble2) { return (int)(paramDouble1 * paramDouble2 / 1000.0D); }
  
  private int b(double paramDouble) {
    double d1 = 0.0D;
    if (paramDouble > 1024.0D)
      d1 = Math.ceil(Math.log10(paramDouble / 1024.0D) / Math.log10(2.0D)); 
    return (int)d1;
  }
  
  private void a(a parama, c paramc, String paramString1, String paramString2) {
    int i1 = parama.f();
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = paramc.a(new String[] { paramString1, paramString2, Integer.toString(i1) });
    if (p2Enumerations.p2AppManagerStatus.NO_ERROR != p2AppManagerStatus)
      throw new p2AppManagerException("Failed to load sample configuration ", p2AppManagerStatus.getNumVal()); 
  }
  
  private double[][] a(a parama, b paramb) {
    b.info("responseCalculationStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt = (int[][])null;
    double[][] arrayOfDouble1 = (double[][])null;
    double[][] arrayOfDouble2 = new double[2][];
    double d1 = parama.I;
    byte b1;
    for (b1 = 0; d1 <= parama.J; b1++)
      d1 += parama.K; 
    arrayOfDouble2[0] = new double[b1];
    arrayOfDouble2[1] = new double[b1];
    d1 = parama.I;
    for (b1 = 0; d1 <= parama.J; b1++) {
      arrayOfDouble2[0][b1] = d1;
      d1 += parama.K;
    } 
    b.info("----------------Run numbers : " + parama.Z);
    try {
      p2SpectroDSP.a().a(this.D.b());
      for (byte b2 = 0; b2 < arrayOfDouble2[0].length; b2++) {
        double d4 = arrayOfDouble2[0][b2];
        long l1 = (long)(d4 * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
        this.O.b(i.cD.a(), l1, k.cD.a(), j.cD.a());
        this.O.a(false, true, (int)this.D.b()[48]);
        try {
          Thread.sleep((long)this.D.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
        this.O.a(true, true, (int)this.D.b()[48]);
        try {
          Thread.sleep((long)this.D.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
        future1 = a(this.O, parama);
        b.info("begin streaming process...");
        arrayOfInt = (int[][])future1.get();
        b.info("end streaming process.");
        this.D = paramb;
        future2 = b(this.O, arrayOfInt, parama);
        b.info("begin DSP Response Calculation Res Freq And Quality Factor...");
        arrayOfDouble1 = (double[][])future2.get();
        arrayOfDouble2[1][b2] = arrayOfDouble1[0][0];
        b.info("end DSP Response Calculation Res Freq And Quality Factor.");
      } 
      double d2 = this.O.b(i.fH.a(), k.fH.a(), j.fH.a());
      double d3 = this.O.b(i.fI.a(), k.fI.a(), j.fI.a());
      arrayOfDouble2[1] = p2SpectroDSP.a().a(arrayOfDouble2[1], parama.m, d2, d3, parama.n)[0];
      b.info("responseCalculationStreamingProcessing finished");
      return arrayOfDouble2;
    } catch (InterruptedException interruptedException) {
      b.error("responseCalculationStreamingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("responseCalculationStreamingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] b(a parama, b paramb) {
    b.info("parametersCalculationStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt = (int[][])null;
    double[][] arrayOfDouble1 = (double[][])null;
    double[][] arrayOfDouble2 = (double[][])null;
    double[][] arrayOfDouble3 = (double[][])null;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      p2SpectroDSP.a().a(this.D.b());
      future1 = a(this.O, parama);
      b.info("begin streaming process...");
      arrayOfInt = (int[][])future1.get();
      b.info("end streaming process.");
      this.D = paramb;
      future2 = c(this.O, arrayOfInt, parama);
      b.info("begin DSP Parameters Calculation Res Freq And Quality Factor...");
      arrayOfDouble1 = (double[][])future2.get();
      b.info("end DSP Parameters Calculation Res Freq And Quality Factor.");
      try {
        this.O.a(paramb.c());
      } catch (a a1) {
        b.error("Loading register file failed");
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR.getNumVal());
      } 
      a("Push-Pull", p2Constants.getPath(p2Constants.ACTUATION_DIRECTION_OPTION_FILE_PATH));
      a("Sine", p2Constants.getPath(p2Constants.WAVEFORM_OPTION_FILE_PATH));
      double d1 = 0.0D;
      if (this.r == null) {
        double d2 = arrayOfDouble1[0][0];
        d1 = d2 - parama.H;
      } else {
        double d2 = this.r[1][0];
        byte b1 = 0;
        for (byte b2 = 1; b2 < this.r[1].length; b2++) {
          if (this.r[1][b2] > d2) {
            d2 = this.r[1][b2];
            b1 = b2;
          } 
        } 
        double d3 = this.r[0][b1];
        d1 = d3 - parama.H;
      } 
      long l1 = Math.round((parama.j * Math.pow(2.0D, k.cF.a()) - 1.0D) / 100.0D);
      this.O.b(i.cF.a(), l1, k.cF.a(), j.cF.a());
      long l2 = (long)(d1 * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
      this.O.b(i.cD.a(), l2, k.cD.a(), j.cD.a());
      a(String.valueOf(parama.l), p2Constants.getPath(p2Constants.SAMPLING_RATE_OPTION_FILE_PATH));
      a(String.valueOf(parama.m), p2Constants.getPath(p2Constants.EXCITATION_VOLTAGE_OPTION_FILE_PATH));
      a(String.valueOf(parama.n), p2Constants.getPath(p2Constants.C2V_GAIN_OPTION_FILE_PATH));
      boolean bool = false;
      try {
        bool = this.O.a(true);
      } catch (a a1) {
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR.getNumVal());
      } 
      if (!bool)
        try {
          this.O.a(true, true, (int)paramb.b()[48]);
          try {
            Thread.sleep((long)paramb.b()[12]);
          } catch (InterruptedException interruptedException) {
            b.error(interruptedException.getMessage());
          } 
        } catch (a a1) {
          throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR.getNumVal());
        }  
      future1 = a(this.O, parama);
      b.info("begin streaming process...");
      arrayOfInt = (int[][])future1.get();
      b.info("end streaming process.");
      future2 = d(this.O, arrayOfInt, parama);
      b.info("begin DSP Parameters Calculation Forward Gain...");
      arrayOfDouble2 = (double[][])future2.get();
      b.info("end DSP Parameters Calculation Forward Gain.");
      int i1 = (int)this.O.b(i.fE.a(), k.fE.a(), j.fE.a());
      int i2 = (int)this.O.b(i.fF.a(), k.fF.a(), j.fF.a());
      i1 *= 2;
      i2 *= 2;
      if (i1 == 0)
        i1 = 1; 
      if (i2 == 0)
        i2 = 1; 
      parama.p = i1;
      parama.q = i2;
      future2 = e(this.O, arrayOfInt, parama);
      b.info("begin DSP process...");
      arrayOfDouble3 = (double[][])future2.get();
      b.info("end DSP process.");
      b.info("parametersCalculationStreamingProcessing finished");
      double[][] arrayOfDouble = new double[5][];
      arrayOfDouble[0] = arrayOfDouble3[0];
      arrayOfDouble[1] = arrayOfDouble3[1];
      arrayOfDouble[2] = new double[1];
      arrayOfDouble[2][0] = arrayOfDouble1[0][0];
      arrayOfDouble[3] = new double[1];
      arrayOfDouble[3][0] = arrayOfDouble1[1][0];
      arrayOfDouble[4] = new double[1];
      arrayOfDouble[4][0] = arrayOfDouble2[0][0];
      return arrayOfDouble;
    } catch (InterruptedException interruptedException) {
      b.error("parametersCalculationStreamingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("parametersCalculationStreamingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] c(a parama, b paramb) {
    b.info("CoefficientsTrimmingProcessing entered");
    Future future = null;
    double[][] arrayOfDouble = (double[][])null;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      this.D = paramb;
      future = e(this.O, parama);
      b.info("begin DSP Coefficients Trimming...");
      arrayOfDouble = (double[][])future.get();
      b.info("end DSP Coefficients Trimming.");
      long l1 = (long)arrayOfDouble[3][0];
      this.O.b(i.fH.a(), l1, k.fH.a(), j.fH.a());
      long l2 = (long)arrayOfDouble[4][0];
      this.O.b(i.fI.a(), l2, k.fI.a(), j.fI.a());
      long l3 = (long)arrayOfDouble[6][0];
      this.O.b(i.cC.a(), l3, k.cC.a(), j.cC.a());
      long l4 = (long)arrayOfDouble[8][0];
      this.O.b(i.dl.a(), l4, k.dl.a(), j.dl.a());
      long l5 = (long)arrayOfDouble[10][0];
      this.O.b(i.dg.a(), l5, k.dg.a(), j.dg.a());
      long l6 = (long)arrayOfDouble[11][0];
      this.O.b(i.ds.a(), l6, k.ds.a(), j.ds.a());
      long l7 = (long)arrayOfDouble[13][0];
      this.O.b(i.dj.a(), l7, k.dj.a(), j.dj.a());
      long l8 = (long)arrayOfDouble[2][0];
      this.O.b(i.di.a(), l8, k.di.a(), j.di.a());
      b.info("CoefficientsTrimmingProcessing finished");
      return arrayOfDouble;
    } catch (InterruptedException interruptedException) {
      b.error("CoefficientsTrimmingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("CoefficientsTrimmingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] d(a parama, b paramb) {
    b.info("PhaseTrimmingStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    double[][] arrayOfDouble = (double[][])null;
    double d1 = parama.P;
    byte b1;
    for (b1 = 0; d1 <= parama.Q; b1++)
      d1 += parama.R; 
    double[] arrayOfDouble1 = new double[b1];
    double[] arrayOfDouble2 = new double[b1];
    double[] arrayOfDouble3 = new double[b1];
    d1 = parama.P;
    for (b1 = 0; d1 <= parama.Q; b1++) {
      arrayOfDouble1[b1] = d1;
      d1 += parama.R;
    } 
    b.info("----------------Run numbers : " + parama.Z);
    try {
      long l1 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
      double d2 = l1 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
      for (byte b2 = 0; b2 < arrayOfDouble1.length; b2++) {
        double[][] arrayOfDouble7 = p2SpectroDSP.a().a(arrayOfDouble1[b2], d2);
        double d3 = arrayOfDouble7[0][0];
        this.O.b(i.k.a(), 1L, k.k.a(), j.k.a());
        this.O.b(i.di.a(), (long)d3, k.di.a(), j.di.a());
        this.O.b(i.k.a(), 0L, k.k.a(), j.k.a());
        long l2 = this.O.b(i.dj.a(), k.dj.a(), j.dj.a());
        this.O.b(i.dj.a(), l2 * (int)paramb.b()[48], k.dj.a(), j.dj.a());
        try {
          Thread.sleep(500L);
        } catch (InterruptedException interruptedException) {}
        this.O.b(i.dj.a(), l2, k.dj.a(), j.dj.a());
        try {
          Thread.sleep(800L);
        } catch (InterruptedException interruptedException) {}
        future1 = a(this.O, parama);
        b.info("begin streaming CAPLPF process...");
        arrayOfInt1 = (int[][])future1.get();
        b.info("end streaming CAPLPF process.");
        future1 = c(this.O, parama);
        b.info("begin streaming AACOUT process...");
        arrayOfInt2 = (int[][])future1.get();
        double d4 = arrayOfInt2[0][0];
        double d5 = arrayOfInt2[0][0];
        for (byte b4 = 0; b4 < arrayOfInt2[0].length; b4++) {
          if (arrayOfInt2[0][b4] > d4)
            d4 = arrayOfInt2[0][b4]; 
          if (arrayOfInt2[0][b4] < d5)
            d5 = arrayOfInt2[0][b4]; 
        } 
        b.info("end streaming AACOUT process.");
        this.D = paramb;
        future2 = a(this.O, arrayOfInt1, arrayOfInt2, parama);
        b.info("begin DSP Phase trimming...");
        arrayOfDouble = (double[][])future2.get();
        arrayOfDouble2[b2] = arrayOfDouble[0][0];
        arrayOfDouble3[b2] = d4 - d5;
        b.info("end DSP Phase trimming.");
      } 
      double[][] arrayOfDouble4 = p2SpectroDSP.a().a(arrayOfDouble1, arrayOfDouble3, arrayOfDouble2);
      double[][] arrayOfDouble5 = p2SpectroDSP.a().a(arrayOfDouble4[0][0], d2);
      this.O.b(i.di.a(), (long)arrayOfDouble5[0][0], k.di.a(), j.di.a());
      b.info("PhaseTrimmingStreamingProcessing finished");
      for (byte b3 = 0; b3 < arrayOfDouble4[2].length; b3++)
        arrayOfDouble4[2][b3] = arrayOfDouble4[2][b3] / this.D.b()[44]; 
      double[][] arrayOfDouble6 = new double[3][];
      arrayOfDouble6[0] = arrayOfDouble4[1];
      arrayOfDouble6[1] = arrayOfDouble4[2];
      arrayOfDouble6[2] = arrayOfDouble4[0];
      return arrayOfDouble6;
    } catch (InterruptedException interruptedException) {
      b.error("PhaseTrimmingStreamingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("PhaseTrimmingStreamingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] e(a parama, b paramb) {
    b.info("FastPhaseTrimmingStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    double[][] arrayOfDouble = (double[][])null;
    byte b1 = 3;
    double[] arrayOfDouble1 = new double[b1];
    double[] arrayOfDouble2 = new double[b1];
    double[] arrayOfDouble3 = new double[b1];
    arrayOfDouble1[0] = parama.S;
    arrayOfDouble1[1] = parama.T;
    arrayOfDouble1[2] = parama.U;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      long l1 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
      double d1 = l1 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
      for (byte b2 = 0; b2 < arrayOfDouble1.length; b2++) {
        System.out.println("New phase value = " + arrayOfDouble1[b2]);
        double[][] arrayOfDouble7 = p2SpectroDSP.a().a(arrayOfDouble1[b2], d1);
        double d2 = arrayOfDouble7[0][0];
        this.O.b(i.k.a(), 1L, k.k.a(), j.k.a());
        this.O.b(i.di.a(), (long)d2, k.di.a(), j.di.a());
        this.O.b(i.k.a(), 0L, k.k.a(), j.k.a());
        long l2 = this.O.b(i.dj.a(), k.dj.a(), j.dj.a());
        this.O.b(i.dj.a(), l2 * (int)paramb.b()[48], k.dj.a(), j.dj.a());
        try {
          Thread.sleep(500L);
        } catch (InterruptedException interruptedException) {}
        this.O.b(i.dj.a(), l2, k.dj.a(), j.dj.a());
        try {
          Thread.sleep(800L);
        } catch (InterruptedException interruptedException) {}
        future1 = a(this.O, parama);
        b.info("begin streaming CAPLPF process...");
        arrayOfInt1 = (int[][])future1.get();
        b.info("end streaming CAPLPF process.");
        future1 = c(this.O, parama);
        b.info("begin streaming AACOUT process...");
        arrayOfInt2 = (int[][])future1.get();
        double d3 = arrayOfInt2[0][0];
        double d4 = arrayOfInt2[0][0];
        for (byte b4 = 0; b4 < arrayOfInt2[0].length; b4++) {
          if (arrayOfInt2[0][b4] > d3)
            d3 = arrayOfInt2[0][b4]; 
          if (arrayOfInt2[0][b4] < d4)
            d4 = arrayOfInt2[0][b4]; 
        } 
        b.info("end streaming AACOUT process.");
        this.D = paramb;
        future2 = a(this.O, arrayOfInt1, arrayOfInt2, parama);
        b.info("begin DSP Phase trimming...");
        arrayOfDouble = (double[][])future2.get();
        arrayOfDouble2[b2] = arrayOfDouble[0][0];
        arrayOfDouble3[b2] = d3 - d4;
        if (arrayOfDouble2[b2] != 1.0D) {
          System.out.println("Phase isn't stable for value = " + arrayOfDouble1[b2]);
          if (!b2 || b2 == 1) {
            arrayOfDouble1[b2] = arrayOfDouble1[b2] + parama.R;
          } else {
            arrayOfDouble1[b2] = arrayOfDouble1[b2] - parama.R;
          } 
          b2--;
        } else {
          System.out.println("Phase is stable for value = " + arrayOfDouble1[b2]);
        } 
        b.info("end DSP Phase trimming.");
      } 
      double[][] arrayOfDouble4 = p2SpectroDSP.a().a(arrayOfDouble1, arrayOfDouble3);
      double[][] arrayOfDouble5 = p2SpectroDSP.a().a(arrayOfDouble4[0][0], d1);
      this.O.b(i.di.a(), (long)arrayOfDouble5[0][0], k.di.a(), j.di.a());
      b.info("FastPhaseTrimmingStreamingProcessing finished");
      for (byte b3 = 0; b3 < arrayOfDouble4[2].length; b3++)
        arrayOfDouble4[2][b3] = arrayOfDouble4[2][b3] / this.D.b()[44]; 
      double[][] arrayOfDouble6 = new double[3][];
      arrayOfDouble6[0] = arrayOfDouble4[1];
      arrayOfDouble6[1] = arrayOfDouble4[2];
      arrayOfDouble6[2] = arrayOfDouble4[0];
      return arrayOfDouble6;
    } catch (InterruptedException interruptedException) {
      b.error("FastPhaseTrimmingStreamingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("FastPhaseTrimmingStreamingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] f(a parama, b paramb) {
    b.info("StabilityCheckStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    double[][] arrayOfDouble1 = (double[][])null;
    double[][] arrayOfDouble2 = (double[][])null;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      p2SpectroDSP.a().a(this.D.b());
      future1 = a(this.O, parama);
      b.info("begin streaming CAPLPF process...");
      arrayOfInt1 = (int[][])future1.get();
      b.info("end streaming CAPLPF process.");
      future1 = c(this.O, parama);
      b.info("begin streaming AACOUT process...");
      arrayOfInt2 = (int[][])future1.get();
      b.info("end streaming AACOUT process.");
      this.D = paramb;
      future2 = b(this.O, arrayOfInt1, arrayOfInt2, parama);
      b.info("begin DSP Stability Check...");
      arrayOfDouble1 = (double[][])future2.get();
      b.info("end DSP Stability Check.");
      int i1 = 0;
      int i2 = 0;
      byte b1 = 1;
      long l1 = this.O.b(i.ds.a(), k.ds.a(), j.ds.a());
      double d1 = p2SpectroDSP.a().a(l1);
      while (!i1 && !i2) {
        future1 = a(this.O, parama);
        b.info("begin streaming CAPLPF process...");
        arrayOfInt1 = (int[][])future1.get();
        b.info("end streaming CAPLPF process.");
        future2 = a(this.O, arrayOfInt1, b1, d1, parama);
        b.info("begin DSP Stability Check...");
        arrayOfDouble2 = (double[][])future2.get();
        b.info("end DSP Stability Check.");
        d1 = arrayOfDouble2[0][0];
        l1 = (long)arrayOfDouble2[2][0];
        i1 = (int)arrayOfDouble2[3][0];
        i2 = (int)arrayOfDouble2[4][0];
        this.O.b(i.ds.a(), l1, k.ds.a(), j.ds.a());
        b1++;
      } 
      double[][] arrayOfDouble = new double[arrayOfDouble1.length + arrayOfDouble2.length][1];
      int i3;
      for (i3 = 0; i3 < arrayOfDouble1.length; i3++)
        arrayOfDouble[i3][0] = arrayOfDouble1[i3][0]; 
      i3 = arrayOfDouble1.length;
      for (byte b2 = 0; b2 < arrayOfDouble2.length; b2++) {
        arrayOfDouble[i3][0] = arrayOfDouble2[b2][0];
        i3++;
      } 
      b.info("StabilityCheckStreamingProcessing finished");
      return arrayOfDouble;
    } catch (InterruptedException interruptedException) {
      b.error("StabilityCheckStreamingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("StabilityCheckStreamingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] g(a parama, b paramb) {
    b.info("capCurrentStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt = (int[][])null;
    double[][] arrayOfDouble = (double[][])null;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      p2SpectroDSP.a().a(this.D.b());
      if (parama.W == 0) {
        future1 = a(this.O, parama);
      } else if (parama.W == 1) {
        future1 = c(this.O, parama);
      } else if (parama.W == 2) {
        future1 = b(this.O, parama);
      } 
      b.info("begin streaming process...");
      arrayOfInt = (int[][])future1.get();
      b.info("end streaming process.");
      this.D = paramb;
      if (parama.W == 0) {
        future2 = e(this.O, arrayOfInt, parama);
        b.info("begin DSP process...");
        arrayOfDouble = (double[][])future2.get();
        b.info("end DSP process.");
        b.info("capCurrentStreamingProcessing finished");
      } else if (parama.W == 1) {
        double[][] arrayOfDouble1 = new double[2][arrayOfInt[0].length];
        for (byte b1 = 0; b1 < arrayOfInt[0].length; b1++) {
          arrayOfDouble1[0][b1] = b1 * parama.ac / arrayOfInt[0].length;
          arrayOfDouble1[1][b1] = arrayOfInt[0][b1] / this.D.b()[44];
        } 
        arrayOfDouble = arrayOfDouble1;
      } else {
        double[][] arrayOfDouble1 = new double[2][arrayOfInt[0].length];
        for (byte b1 = 0; b1 < arrayOfInt[0].length; b1++) {
          arrayOfDouble1[0][b1] = b1 * parama.ac / arrayOfInt[0].length;
          arrayOfDouble1[1][b1] = arrayOfInt[0][b1] / Math.pow(2.0D, 20.0D);
        } 
        arrayOfDouble = arrayOfDouble1;
      } 
      return arrayOfDouble;
    } catch (InterruptedException interruptedException) {
      b.error("capCurrentStreamingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("capCurrentStreamingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] h(a parama, b paramb) {
    b.info("capCurrentStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt = (int[][])null;
    double[][] arrayOfDouble = (double[][])null;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      future1 = a(this.O, parama);
      b.info("begin streaming process...");
      arrayOfInt = (int[][])future1.get();
      b.info("end streaming process.");
      this.D = paramb;
      future2 = e(this.O, arrayOfInt, parama);
      b.info("begin DSP process...");
      arrayOfDouble = (double[][])future2.get();
      b.info("end DSP process.");
      b.info("capCurrentStreamingProcessing finished");
      return arrayOfDouble;
    } catch (InterruptedException interruptedException) {
      b.error("capCurrentStreamingProcessing throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (Exception exception) {
      b.error("capCurrentStreamingProcessing throw exception : " + exception.getMessage());
      if (exception.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)exception.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[] i(a parama, b paramb) {
    b.info("capTimeCalibrationStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt = (int[][])null;
    null = null;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      future1 = a(this.O, parama);
      b.info("begin streaming process...");
      arrayOfInt = (int[][])future1.get();
      b.info("end streaming process.");
      this.D = paramb;
      future2 = f(this.O, arrayOfInt, parama);
      b.info("begin DSP process...");
      null = (double[])future2.get();
      b.info("end DSP process.");
      b.info("Extracting settings: INT1_TH_1 = " + (long)null[0]);
      System.out.println("Extracting settings: INT1_TH_1 = " + (long)null[0]);
      this.O.b(i.be.a(), (long)null[0], k.be.a(), j.be.a());
      b.info("Extracting settings: INT1_TH_2 = " + (long)null[1]);
      System.out.println("Extracting settings: INT1_TH_2 = " + (long)null[1]);
      this.O.b(i.bf.a(), (long)null[1], k.bf.a(), j.bf.a());
      b.info("Extracting settings: INT1_TH_3 = " + (long)null[2]);
      System.out.println("Extracting settings: INT1_TH_3 = " + (long)null[2]);
      this.O.b(i.bg.a(), (long)null[2], k.bg.a(), j.bg.a());
      b.info("Extracting settings: INT1_TH_4 = " + (long)null[3]);
      System.out.println("Extracting settings: INT1_TH_4 = " + (long)null[3]);
      this.O.b(i.bh.a(), (long)null[3], k.bh.a(), j.bh.a());
      b.info("Extracting settings: INT1_X_INITIAL = " + (long)null[4]);
      System.out.println("Extracting settings: INT1_X_INITIAL = " + (long)null[4]);
      this.O.b(i.bb.a(), (long)null[4], k.bb.a(), j.bb.a());
      b.info("Extracting settings: INT1_X_STEP = " + (long)null[5]);
      System.out.println("Extracting settings: INT1_X_STEP = " + (long)null[5]);
      this.O.b(i.bd.a(), (long)null[5], k.bd.a(), j.bd.a());
      b.info("Extracting settings: INT1_RAM_SAMPLES = " + parama.v);
      System.out.println("Extracting settings: INT1_RAM_SAMPLES = " + parama.v);
      this.O.b(i.aW.a(), parama.v, k.aW.a(), j.aW.a());
      b.info("Extracting settings: INT1_X_DIRECTION = 0");
      System.out.println("Extracting settings: INT1_X_DIRECTION = 0");
      this.O.b(i.aO.a(), 0L, k.aO.a(), j.aO.a());
      b.info("Extracting settings: INT2_TH_1 = " + (long)null[0]);
      System.out.println("Extracting settings: INT2_TH_1 = " + (long)null[0]);
      this.O.b(i.gB.a(), (long)null[0], k.gB.a(), j.gB.a());
      b.info("Extracting settings: INT2_TH_2 = " + (long)null[1]);
      System.out.println("Extracting settings: INT2_TH_2 = " + (long)null[1]);
      this.O.b(i.gC.a(), (long)null[1], k.gC.a(), j.gC.a());
      b.info("Extracting settings: INT2_TH_3 = " + (long)null[2]);
      System.out.println("Extracting settings: INT2_TH_3 = " + (long)null[2]);
      this.O.b(i.gD.a(), (long)null[2], k.gD.a(), j.gD.a());
      b.info("Extracting settings: INT2_TH_4 = " + (long)null[3]);
      System.out.println("Extracting settings: INT2_TH_4 = " + (long)null[3]);
      this.O.b(i.gE.a(), (long)null[3], k.gE.a(), j.gE.a());
      b.info("Extracting settings: INT2_X_INITIAL = " + (long)null[6]);
      System.out.println("Extracting settings: INT2_X_INITIAL = " + (long)null[6]);
      this.O.b(i.gy.a(), (long)null[6], k.gy.a(), j.gy.a());
      b.info("Extracting settings: INT2_X_STEP = " + (long)null[5]);
      System.out.println("Extracting settings: INT2_X_STEP = " + (long)null[5]);
      this.O.b(i.gA.a(), (long)null[5], k.gA.a(), j.gA.a());
      b.info("Extracting settings: INT2_RAM_SAMPLES = " + parama.v);
      System.out.println("Extracting settings: INT2_RAM_SAMPLES = " + parama.v);
      this.O.b(i.gt.a(), parama.v, k.gt.a(), j.gt.a());
      b.info("Extracting settings: INT2_X_DIRECTION = 1");
      System.out.println("Extracting settings: INT2_X_DIRECTION = 1");
      this.O.b(i.gl.a(), 1L, k.gl.a(), j.gl.a());
      b.info("Extracting settings: DMUX10_EN = 0");
      System.out.println("Extracting settings: DMUX10_EN = 0");
      this.O.b(i.dB.a(), 0L, k.dB.a(), j.dB.a());
      b.info("Extracting settings: DMUX_EN = 0");
      System.out.println("Extracting settings: DMUX_EN = 0");
      this.O.b(i.dA.a(), 0L, k.dA.a(), j.dA.a());
      return null;
    } catch (InterruptedException interruptedException) {
      b.error("capTimeCalibrationStreamingProcessing throw exception : " + interruptedException.getMessage());
      if (parama.Z == 1)
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal()); 
    } catch (ExecutionException executionException) {
      b.error("capTimeCalibrationStreamingProcessing throw exception : " + executionException.getMessage());
      if (parama.Z == 1) {
        if (executionException.getCause() instanceof p2AppManagerException)
          throw (p2AppManagerException)executionException.getCause(); 
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
      } 
    } catch (a a1) {
      b.error("capTimeCalibrationStreamingProcessing throw taif exception : " + a1.getMessage());
    } 
    b.info("capTimeCalibrationStreamingProcessing finished");
    arrayOfInt = (int[][])null;
    return null;
  }
  
  private double[] j(a parama, b paramb) {
    b.info("delayCompensationCalibrationStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt = (int[][])null;
    int[] arrayOfInt1 = null;
    int[] arrayOfInt2 = null;
    null = null;
    int i1 = 512;
    int i2 = 1;
    byte b1 = 0;
    boolean bool = true;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      byte b2 = 0;
      while (bool && b2 < 10) {
        future1 = null;
        future2 = null;
        arrayOfInt = (int[][])null;
        arrayOfInt1 = null;
        arrayOfInt2 = null;
        null = null;
        b1 = 0;
        b2++;
        while (b1 < parama.Z) {
          this.O.b(i.cB.a(), i1, k.cB.a(), j.cB.a());
          this.O.b(i.n.a(), 1L, k.n.a(), j.n.a());
          this.O.b(i.n.a(), 0L, k.n.a(), j.n.a());
          b.info("----------------Run : " + ++b1 + " started---------------");
          future1 = d(this.O, parama);
          b.info("begin streaming process...");
          arrayOfInt = (int[][])future1.get();
          b.info("end streaming process.");
          if (b1 == 1) {
            arrayOfInt2 = new int[arrayOfInt[0].length];
            System.arraycopy(arrayOfInt[0], 0, arrayOfInt2, 0, arrayOfInt2.length);
            arrayOfInt1 = new int[arrayOfInt[1].length];
            System.arraycopy(arrayOfInt[1], 0, arrayOfInt1, 0, arrayOfInt1.length);
          } else {
            byte b4;
            for (b4 = 0; b4 < arrayOfInt[0].length; b4++)
              arrayOfInt2[b4] = arrayOfInt2[b4] + arrayOfInt[0][b4]; 
            for (b4 = 0; b4 < arrayOfInt[1].length; b4++)
              arrayOfInt1[b4] = arrayOfInt1[b4] + arrayOfInt[1][b4]; 
          } 
          b.info("----------------Run : " + b1 + " ended----------------");
        } 
        byte b3;
        for (b3 = 0; b3 < arrayOfInt2.length; b3++)
          arrayOfInt2[b3] = arrayOfInt2[b3] / parama.Z; 
        for (b3 = 0; b3 < arrayOfInt1.length; b3++)
          arrayOfInt1[b3] = arrayOfInt1[b3] / parama.Z; 
        this.D = paramb;
        future2 = a(this.O, arrayOfInt1, arrayOfInt2, parama, i1, i2, b2);
        b.info("begin DSP process...");
        null = (double[])future2.get();
        i1 = (int)null[0];
        i2 = (int)null[1];
        if (null[2] == 1.0D) {
          bool = false;
        } else {
          bool = true;
        } 
        b.info("Delay compensation extraction: delay = " + i1);
        b.info("Delay compensation extraction: zpd sign = " + i2);
        b.info("Delay compensation extraction: continue iterating = " + bool);
        System.out.println("Delay compensation extraction: delay = " + i1);
        System.out.println("Delay compensation extraction: zpd sign = " + i2);
        System.out.println("Delay compensation extraction: continue iterating = " + bool);
        b.info("end DSP process.");
      } 
      if (bool && b2 == 10)
        throw new p2AppManagerException("Failed to get valid delay compensation value  ", p2Enumerations.p2AppManagerStatus.DELAY_COMP_MAX_COUNT_ERROR.getNumVal()); 
      return null;
    } catch (InterruptedException interruptedException) {
      b.error("Run no : " + b1 + "throw exception : " + interruptedException.getMessage());
      if (parama.Z == 1)
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal()); 
    } catch (Exception exception) {
      b.error("Run : " + b1 + " throw exception : " + exception.getMessage());
      if (parama.Z == 1) {
        if (exception.getCause() instanceof p2AppManagerException)
          throw (p2AppManagerException)exception.getCause(); 
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
      } 
    } 
    b.info("delayCompensationCalibrationStreamingProcessing finished");
    arrayOfInt1 = null;
    arrayOfInt = (int[][])null;
    return null;
  }
  
  private void k(a parama, b paramb) {
    b.info("CalibrationStreamingProcessing entered");
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    int[] arrayOfInt = null;
    byte b1 = 0;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      while (b1 < parama.Z) {
        b.info("----------------Run : " + ++b1 + " started---------------");
        future1 = d(this.O, parama);
        b.info("begin streaming process...");
        arrayOfInt1 = (int[][])future1.get();
        b.info("end streaming process.");
        if (b1 == 1) {
          arrayOfInt2 = new int[2][];
          arrayOfInt2[0] = new int[arrayOfInt1[0].length];
          arrayOfInt2[1] = new int[arrayOfInt1[1].length];
          System.arraycopy(arrayOfInt1[0], 0, arrayOfInt2[0], 0, arrayOfInt2[0].length);
          System.arraycopy(arrayOfInt1[1], 0, arrayOfInt2[1], 0, arrayOfInt2[1].length);
        } else {
          byte b3;
          for (b3 = 0; b3 < arrayOfInt1[0].length; b3++)
            arrayOfInt2[0][b3] = arrayOfInt2[0][b3] + arrayOfInt1[0][b3]; 
          for (b3 = 0; b3 < arrayOfInt1[1].length; b3++)
            arrayOfInt2[1][b3] = arrayOfInt2[1][b3] + arrayOfInt1[1][b3]; 
        } 
        b.info("----------------Run : " + b1 + " ended----------------");
      } 
      byte b2;
      for (b2 = 0; b2 < arrayOfInt2[0].length; b2++)
        arrayOfInt2[0][b2] = arrayOfInt2[0][b2] / parama.Z; 
      for (b2 = 0; b2 < arrayOfInt2[1].length; b2++)
        arrayOfInt2[1][b2] = arrayOfInt2[1][b2] / parama.Z; 
      this.D = paramb;
      future2 = a(this.O, arrayOfInt2, parama);
      b.info("begin saving process...");
      arrayOfInt = (int[])future2.get();
      b.info("end saving process.");
      if (arrayOfInt[0] != 0) {
        b.error("Error occurred during saving readings");
        throw new p2AppManagerException("Failed to save readings  ", p2Enumerations.p2AppManagerStatus.DATA_FILES_SAVING_ERROR.getNumVal());
      } 
    } catch (InterruptedException interruptedException) {
      b.error("Run no : " + b1 + "throw exception : " + interruptedException.getMessage());
      if (parama.Z == 1)
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal()); 
    } catch (ExecutionException executionException) {
      b.error("Run : " + b1 + " throw exception : " + executionException.getMessage());
      if (parama.Z == 1) {
        if (executionException.getCause() instanceof p2AppManagerException)
          throw (p2AppManagerException)executionException.getCause(); 
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
      } 
    } 
    b.info("CalibrationStreamingProcessing finished");
    arrayOfInt2 = (int[][])null;
    arrayOfInt1 = (int[][])null;
    arrayOfInt = null;
  }
  
  private double[][] l(a parama, b paramb) {
    Future future1 = null;
    Future future2 = null;
    Future future3 = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    double[][] arrayOfDouble1 = (double[][])null;
    double[][] arrayOfDouble2 = (double[][])null;
    double[][] arrayOfDouble3 = new double[parama.ad][];
    double[][] arrayOfDouble4 = new double[parama.ad][];
    byte b1 = 0;
    b.info("----------------Number of Measurements: " + parama.ad);
    for (b2 = 0; b2 < parama.ad; b2++) {
      b.info("----------------Run numbers : " + parama.Z);
      try {
        b1 = 0;
        while (b1 < parama.Z) {
          b.info("----------------Run : " + ++b1 + " started---------------");
          future1 = d(this.O, parama);
          b.info("begin streaming process...");
          arrayOfInt1 = (int[][])future1.get();
          b.info("end streaming process.");
          if (b1 == 1) {
            arrayOfInt2 = new int[2][];
            arrayOfInt2[0] = new int[arrayOfInt1[0].length];
            arrayOfInt2[1] = new int[arrayOfInt1[1].length];
            System.arraycopy(arrayOfInt1[0], 0, arrayOfInt2[0], 0, arrayOfInt2[0].length);
            System.arraycopy(arrayOfInt1[1], 0, arrayOfInt2[1], 0, arrayOfInt2[1].length);
          } else {
            byte b4;
            for (b4 = 0; b4 < arrayOfInt1[0].length; b4++)
              arrayOfInt2[0][b4] = arrayOfInt2[0][b4] + arrayOfInt1[0][b4]; 
            for (b4 = 0; b4 < arrayOfInt1[1].length; b4++)
              arrayOfInt2[1][b4] = arrayOfInt2[1][b4] + arrayOfInt1[1][b4]; 
          } 
          b.info("----------------Run : " + b1 + " ended----------------");
        } 
        byte b3;
        for (b3 = 0; b3 < arrayOfInt2[0].length; b3++)
          arrayOfInt2[0][b3] = arrayOfInt2[0][b3] / parama.Z; 
        for (b3 = 0; b3 < arrayOfInt2[1].length; b3++)
          arrayOfInt2[1][b3] = arrayOfInt2[1][b3] / parama.Z; 
        this.D = paramb;
        future2 = a(this.O, arrayOfInt2, parama, this.C, this.f);
        b.info("begin DSP process...");
        arrayOfDouble1 = (double[][])future2.get();
        b.info("end DSP process.");
        arrayOfDouble3[b2] = new double[arrayOfDouble1[2].length];
        arrayOfDouble4[b2] = new double[arrayOfDouble1[3].length];
        System.arraycopy(arrayOfDouble1[2], 0, arrayOfDouble3[b2], 0, arrayOfDouble1[2].length);
        System.arraycopy(arrayOfDouble1[3], 0, arrayOfDouble4[b2], 0, arrayOfDouble1[3].length);
      } catch (InterruptedException interruptedException) {
        b.error("Run no : " + b1 + "throw exception : " + interruptedException.getMessage());
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
      } catch (ExecutionException executionException) {
        b.error("Run : " + b1 + " throw exception : " + executionException.getMessage());
        if (executionException.getCause() instanceof p2AppManagerException)
          throw (p2AppManagerException)executionException.getCause(); 
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
      } 
    } 
    try {
      future3 = a(parama, this.C, arrayOfDouble3[0], arrayOfDouble4);
      b.info("begin SNR DSP process...");
      arrayOfDouble2 = (double[][])future3.get();
      b.info("end SNR fDSP process.");
    } catch (InterruptedException b2) {
      InterruptedException interruptedException;
      b.error("SNR DSP function throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (ExecutionException b2) {
      ExecutionException executionException;
      b.error("SNR DSP function throw exception : " + executionException.getMessage());
      if (executionException.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)executionException.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
    return arrayOfDouble2;
  }
  
  private double[][] m(a parama, b paramb) {
    Future future1 = null;
    Future future2 = null;
    Future future3 = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    double[][] arrayOfDouble1 = (double[][])null;
    double[][] arrayOfDouble2 = (double[][])null;
    double[][] arrayOfDouble3 = new double[parama.ad][];
    double[][] arrayOfDouble4 = new double[parama.ad][];
    double[][] arrayOfDouble5 = new double[parama.ad][];
    byte b1 = 0;
    b.info("----------------Number of Measurements: " + parama.ad);
    b.info("----------------Time Delay between Two Runs: " + parama.ae + " ms");
    for (b2 = 0; b2 < parama.ad; b2++) {
      b.info("----------------Run numbers : " + parama.Z);
      try {
        b1 = 0;
        while (b1 < parama.Z) {
          b.info("----------------Run : " + ++b1 + " started---------------");
          future1 = d(this.O, parama);
          b.info("begin streaming process...");
          arrayOfInt1 = (int[][])future1.get();
          b.info("end streaming process.");
          if (b1 == 1) {
            arrayOfInt2 = new int[2][];
            arrayOfInt2[0] = new int[arrayOfInt1[0].length];
            arrayOfInt2[1] = new int[arrayOfInt1[1].length];
            System.arraycopy(arrayOfInt1[0], 0, arrayOfInt2[0], 0, arrayOfInt2[0].length);
            System.arraycopy(arrayOfInt1[1], 0, arrayOfInt2[1], 0, arrayOfInt2[1].length);
          } else {
            byte b4;
            for (b4 = 0; b4 < arrayOfInt1[0].length; b4++)
              arrayOfInt2[0][b4] = arrayOfInt2[0][b4] + arrayOfInt1[0][b4]; 
            for (b4 = 0; b4 < arrayOfInt1[1].length; b4++)
              arrayOfInt2[1][b4] = arrayOfInt2[1][b4] + arrayOfInt1[1][b4]; 
          } 
          b.info("----------------Run : " + b1 + " ended----------------");
        } 
        byte b3;
        for (b3 = 0; b3 < arrayOfInt2[0].length; b3++)
          arrayOfInt2[0][b3] = arrayOfInt2[0][b3] / parama.Z; 
        for (b3 = 0; b3 < arrayOfInt2[1].length; b3++)
          arrayOfInt2[1][b3] = arrayOfInt2[1][b3] / parama.Z; 
        this.D = paramb;
        future2 = a(this.O, arrayOfInt2, parama, this.C, this.f);
        b.info("begin DSP process...");
        arrayOfDouble1 = (double[][])future2.get();
        b.info("end DSP process.");
        arrayOfDouble3[b2] = new double[arrayOfDouble1[2].length];
        arrayOfDouble4[b2] = new double[arrayOfDouble1[3].length];
        arrayOfDouble5[b2] = new double[arrayOfDouble1[5].length];
        System.arraycopy(arrayOfDouble1[2], 0, arrayOfDouble3[b2], 0, arrayOfDouble1[2].length);
        System.arraycopy(arrayOfDouble1[3], 0, arrayOfDouble4[b2], 0, arrayOfDouble1[3].length);
        System.arraycopy(arrayOfDouble1[5], 0, arrayOfDouble5[b2], 0, arrayOfDouble1[5].length);
      } catch (InterruptedException interruptedException) {
        b.error("Run no : " + b1 + "throw exception : " + interruptedException.getMessage());
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
      } catch (ExecutionException executionException) {
        b.error("Run : " + b1 + " throw exception : " + executionException.getMessage());
        if (executionException.getCause() instanceof p2AppManagerException)
          throw (p2AppManagerException)executionException.getCause(); 
        throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
      } 
      try {
        Thread.sleep(parama.ae);
      } catch (InterruptedException interruptedException) {
        b.error(interruptedException.getMessage());
      } 
    } 
    try {
      double[] arrayOfDouble = null;
      arrayOfDouble = p2AppManagerUtils.loadRawDataFile(p2Constants.getPath(p2Constants.STANDARD_CALIBRATORS_FOLDER_PATH) + File.separatorChar + parama.Y + ".txt");
      if (arrayOfDouble == null)
        throw new p2AppManagerException("Failed to load standard calibrator file ", p2Enumerations.p2AppManagerStatus.WHITE_FILE_NOT_EXIST_ERROR.getNumVal()); 
      future3 = a(parama, this.C, arrayOfDouble3[0], arrayOfDouble4, arrayOfDouble);
      b.info("begin Stability DSP process...");
      arrayOfDouble2 = (double[][])future3.get();
      b.info("end Stability DSP process.");
      for (int i1 = 0; i1 < arrayOfDouble5.length; i1++)
        System.arraycopy(arrayOfDouble5[i1], 0, arrayOfDouble2[1], i1 * arrayOfDouble5[i1].length, arrayOfDouble5[i1].length); 
      arrayOfDouble = null;
    } catch (InterruptedException b2) {
      InterruptedException interruptedException;
      b.error("Stability DSP function throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (ExecutionException b2) {
      ExecutionException executionException;
      b.error("Stability DSP function throw exception : " + executionException.getMessage());
      if (executionException.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)executionException.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
    return arrayOfDouble2;
  }
  
  private double[][] n(a parama, b paramb) {
    Future future1 = null;
    Future future2 = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    double[][] arrayOfDouble = (double[][])null;
    byte b1 = 0;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      while (b1 < parama.Z) {
        b.info("----------------Run : " + ++b1 + " started---------------");
        future1 = d(this.O, parama);
        b.info("begin streaming process...");
        arrayOfInt1 = (int[][])future1.get();
        b.info("end streaming process.");
        if (b1 == 1) {
          arrayOfInt2 = new int[2][];
          arrayOfInt2[0] = new int[arrayOfInt1[0].length];
          arrayOfInt2[1] = new int[arrayOfInt1[1].length];
          System.arraycopy(arrayOfInt1[0], 0, arrayOfInt2[0], 0, arrayOfInt2[0].length);
          System.arraycopy(arrayOfInt1[1], 0, arrayOfInt2[1], 0, arrayOfInt2[1].length);
        } else {
          byte b3;
          for (b3 = 0; b3 < arrayOfInt1[0].length; b3++)
            arrayOfInt2[0][b3] = arrayOfInt2[0][b3] + arrayOfInt1[0][b3]; 
          for (b3 = 0; b3 < arrayOfInt1[1].length; b3++)
            arrayOfInt2[1][b3] = arrayOfInt2[1][b3] + arrayOfInt1[1][b3]; 
        } 
        b.info("----------------Run : " + b1 + " ended----------------");
      } 
      byte b2;
      for (b2 = 0; b2 < arrayOfInt2[0].length; b2++)
        arrayOfInt2[0][b2] = arrayOfInt2[0][b2] / parama.Z; 
      for (b2 = 0; b2 < arrayOfInt2[1].length; b2++)
        arrayOfInt2[1][b2] = arrayOfInt2[1][b2] / parama.Z; 
      this.x = new double[arrayOfInt2.length][];
      for (b2 = 0; b2 < this.x.length; b2++) {
        this.x[b2] = new double[arrayOfInt2[b2].length];
        for (byte b3 = 0; b3 < this.x[b2].length; b3++)
          this.x[b2][b3] = arrayOfInt2[b2][b3]; 
      } 
      this.D = paramb;
      if (p2Enumerations.p2AppManagerState.wavelengthCalibration_Run == parama.a) {
        future2 = a(this.O, arrayOfInt2, parama, this.C, this.g);
      } else {
        future2 = a(this.O, arrayOfInt2, parama, this.C, this.f);
      } 
      b.info("begin DSP process...");
      arrayOfDouble = (double[][])future2.get();
      b.info("end DSP process.");
      return arrayOfDouble;
    } catch (InterruptedException interruptedException) {
      b.error("Run no : " + b1 + "throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (ExecutionException executionException) {
      b.error("Run : " + b1 + " throw exception : " + executionException.getMessage());
      if (executionException.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)executionException.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private double[][] o(a parama, b paramb) {
    Future future = null;
    int[][] arrayOfInt1 = (int[][])null;
    int[][] arrayOfInt2 = (int[][])null;
    double[][] arrayOfDouble = (double[][])null;
    byte b1 = 0;
    b.info("----------------Run numbers : " + parama.Z);
    try {
      while (b1 < parama.Z) {
        b.info("----------------Run : " + ++b1 + " started---------------");
        future = d(this.O, parama);
        b.info("begin streaming process...");
        arrayOfInt1 = (int[][])future.get();
        b.info("end streaming process.");
        arrayOfDouble = new double[2][];
        arrayOfDouble[0] = new double[arrayOfInt1[0].length];
        arrayOfDouble[1] = new double[arrayOfInt1[1].length];
        if (b1 == 1) {
          arrayOfInt2 = new int[2][];
          arrayOfInt2[0] = new int[arrayOfInt1[0].length];
          arrayOfInt2[1] = new int[arrayOfInt1[1].length];
          System.arraycopy(arrayOfInt1[0], 0, arrayOfInt2[0], 0, arrayOfInt2[0].length);
          System.arraycopy(arrayOfInt1[1], 0, arrayOfInt2[1], 0, arrayOfInt2[1].length);
        } else {
          byte b3;
          for (b3 = 0; b3 < arrayOfInt1[0].length; b3++)
            arrayOfInt2[0][b3] = arrayOfInt2[0][b3] + arrayOfInt1[0][b3]; 
          for (b3 = 0; b3 < arrayOfInt1[1].length; b3++)
            arrayOfInt2[1][b3] = arrayOfInt2[1][b3] + arrayOfInt1[1][b3]; 
        } 
        b.info("----------------Run : " + b1 + " ended----------------");
      } 
      byte b2;
      for (b2 = 0; b2 < arrayOfInt2[0].length; b2++)
        arrayOfDouble[0][b2] = arrayOfInt2[0][b2] / parama.Z; 
      for (b2 = 0; b2 < arrayOfInt2[1].length; b2++)
        arrayOfDouble[1][b2] = arrayOfInt2[1][b2] / parama.Z; 
      return arrayOfDouble;
    } catch (InterruptedException interruptedException) {
      b.error("Run no : " + b1 + "throw exception : " + interruptedException.getMessage());
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } catch (ExecutionException executionException) {
      b.error("Run : " + b1 + " throw exception : " + executionException.getMessage());
      if (executionException.getCause() instanceof p2AppManagerException)
        throw (p2AppManagerException)executionException.getCause(); 
      throw new p2AppManagerException("Failed to get thread data  ", p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR.getNumVal());
    } 
  }
  
  private Future<int[][]> a(a parama, a parama1) { return c.a(new a<int[][]>(this, parama, parama1) {
          protected int[][] a() {
            try {
              return this.a.d(15, this.b.g, (int)this.b.ac);
            } catch (a a1) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_TAIF_ERROR.getNumVal());
            } catch (Exception exception) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_ERROR.getNumVal());
            } 
          }
        }); }
  
  private Future<int[][]> b(a parama, a parama1) { return c.a(new a<int[][]>(this, parama, parama1) {
          protected int[][] a() {
            try {
              return this.a.d(23, this.b.g, (int)this.b.ac);
            } catch (a a1) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_TAIF_ERROR.getNumVal());
            } catch (Exception exception) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_ERROR.getNumVal());
            } 
          }
        }); }
  
  private Future<int[][]> c(a parama, a parama1) { return c.a(new a<int[][]>(this, parama, parama1) {
          protected int[][] a() {
            try {
              return this.a.d(27, this.b.g, (int)this.b.ac);
            } catch (a a1) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_TAIF_ERROR.getNumVal());
            } catch (Exception exception) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_ERROR.getNumVal());
            } 
          }
        }); }
  
  private Future<int[]> a(a parama, int[][] paramArrayOfInt, a parama1) { return c.a(new a<int[]>(this, parama1, paramArrayOfInt) {
          protected int[] a() {
            arrayOfInt = new int[] { 0 };
            bufferedWriter1 = null;
            bufferedWriter2 = null;
            if (!p2AppManagerUtils.createDir(p2Constants.getPath(p2Constants.CALIBRATION_FOLDER_PATH)))
              throw new p2AppManagerException("Calibration Folder Generation Error", p2Enumerations.p2AppManagerStatus.CALIBRATION_FOLDER_GEN_ERROR.getNumVal()); 
            try {
              if (this.a.x) {
                bufferedWriter1 = new BufferedWriter(new FileWriter(p2Constants.getPath(p2Constants.LASER_FILE_PATH) + "_1" + ".txt"));
                bufferedWriter2 = new BufferedWriter(new FileWriter(p2Constants.getPath(p2Constants.LASER_FILE_PATH) + "_2" + ".txt"));
              } else if (this.a.y) {
                bufferedWriter1 = new BufferedWriter(new FileWriter(p2Constants.getPath(p2Constants.WL_FILE_PATH) + "_1" + ".txt"));
                bufferedWriter2 = new BufferedWriter(new FileWriter(p2Constants.getPath(p2Constants.WL_FILE_PATH) + "_2" + ".txt"));
              } else if (this.a.z) {
                bufferedWriter1 = new BufferedWriter(new FileWriter(p2Constants.getPath(p2Constants.METH_FILE_PATH) + "_1" + ".txt"));
                bufferedWriter2 = new BufferedWriter(new FileWriter(p2Constants.getPath(p2Constants.METH_FILE_PATH) + "_2" + ".txt"));
              } 
              b1 = 0;
              while (b1 < this.b[0].length) {
                bufferedWriter1.write(Integer.toString(this.b[0][b1++]));
                bufferedWriter1.write("\n");
              } 
              b1 = 0;
              while (b1 < this.b[1].length) {
                bufferedWriter2.write(Integer.toString(this.b[1][b1++]));
                bufferedWriter2.write("\n");
              } 
              bufferedWriter1.close();
              bufferedWriter2.close();
            } catch (IOException iOException) {
              arrayOfInt[0] = -1;
            } finally {
              try {
                bufferedWriter1.close();
                bufferedWriter2.close();
              } catch (Exception exception) {
                arrayOfInt[0] = -1;
              } 
            } 
            return arrayOfInt;
          }
        }); }
  
  private Future<int[][]> d(a parama, a parama1) { return c.a(new a<int[][]>(this, parama, parama1) {
          protected int[][] a() {
            try {
              int[][] arrayOfInt1 = this.a.c(this.b.aa, this.b.ab, (int)this.b.ac);
              long l = this.a.b(i.aW.a(), k.aW.a(), j.aW.a());
              int[] arrayOfInt2 = new int[(int)l];
              System.arraycopy(arrayOfInt1[0], 0, arrayOfInt2, 0, (int)l);
              l = this.a.b(i.gt.a(), k.gt.a(), j.gt.a());
              int[] arrayOfInt3 = new int[(int)l];
              System.arraycopy(arrayOfInt1[1], 0, arrayOfInt3, 0, (int)l);
              int[][] arrayOfInt4 = new int[2][];
              arrayOfInt4[0] = arrayOfInt2;
              arrayOfInt4[1] = arrayOfInt3;
              return arrayOfInt4;
            } catch (a a1) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_TAIF_ERROR.getNumVal());
            } catch (Exception exception) {
              throw new p2AppManagerException("Failed to stream the data   ", p2Enumerations.p2AppManagerStatus.DATA_STREAMING_ERROR.getNumVal());
            } 
          }
        }); }
  
  private Future<double[][]> a(a parama, int[][] paramArrayOfInt, a parama1, c paramc, double[][] paramArrayOfDouble) { return c.a(new a<double[][]>(this, paramArrayOfInt, paramc, parama1, paramArrayOfDouble) {
          protected double[][] a() {
            double[] arrayOfDouble1 = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
              arrayOfDouble1[b1] = this.a[0][b1]; 
            double[] arrayOfDouble2 = new double[this.a[1].length];
            for (byte b2 = 0; b2 < arrayOfDouble2.length; b2++)
              arrayOfDouble2[b2] = this.a[1][b2]; 
            double d1 = this.b.b()[19];
            double d2 = this.b.b()[22];
            this.b.b()[19] = this.c.af;
            this.b.b()[22] = this.b.b()[22] * this.c.ag;
            double[][] arrayOfDouble3 = (double[][])null;
            double[][] arrayOfDouble4 = (double[][])null;
            try {
              if (this.c.a == p2Enumerations.p2AppManagerState.StabilityRun) {
                arrayOfDouble3 = p2SpectroDSP.a().a(this.b.b(), this.c.aa, this.c.ab, this.c.d, this.c.f, this.b.g(), b.a(this.e).i(), b.a(this.e).j(), this.b.i(), this.b.h(), this.c.e, arrayOfDouble1, arrayOfDouble2);
                arrayOfDouble4 = new double[arrayOfDouble3.length + 1][];
                for (byte b4 = 0; b4 < arrayOfDouble3.length; b4++) {
                  arrayOfDouble4[b4] = new double[arrayOfDouble3[b4].length];
                  System.arraycopy(arrayOfDouble3[b4], 0, arrayOfDouble4[b4], 0, arrayOfDouble3[b4].length);
                } 
                arrayOfDouble4[arrayOfDouble3.length] = new double[arrayOfDouble3[3].length];
                System.arraycopy(arrayOfDouble3[3], 0, arrayOfDouble4[arrayOfDouble3.length], 0, arrayOfDouble3[3].length);
              } else {
                arrayOfDouble4 = p2SpectroDSP.a().a(this.b.b(), this.c.aa, this.c.ab, this.c.d, this.c.f, this.b.g(), b.a(this.e).i(), b.a(this.e).j(), this.b.i(), this.b.h(), this.c.e, arrayOfDouble1, arrayOfDouble2);
              } 
            } catch (a a1) {
              throw new p2AppManagerException("Error while make DSP data interferogram post processing   ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble4 == null || arrayOfDouble4[0].length == 0 || arrayOfDouble4[1].length == 0 || arrayOfDouble4[2].length == 0 || arrayOfDouble4[3].length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty    ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_EMPTY_DATA_ERROR.getNumVal()); 
            if (arrayOfDouble4.length < 5)
              throw new p2AppManagerException("Data backed from DSP post processign lenght not right ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_BAD_DATA_ERROR.getNumVal()); 
            double[] arrayOfDouble5 = arrayOfDouble4[0];
            double[] arrayOfDouble6 = arrayOfDouble4[2];
            double[] arrayOfDouble7 = arrayOfDouble4[4];
            double[] arrayOfDouble8 = arrayOfDouble4[3];
            double[] arrayOfDouble9 = arrayOfDouble4[1];
            String str = Arrays.toString(arrayOfDouble7);
            String[] arrayOfString = str.substring(1, str.length() - 1).split(",");
            if (!p2AppManagerUtils.writeFileOfArray(arrayOfString, this.b.f(), "\n"))
              throw new p2AppManagerException("Failed to update corr file   ", p2Enumerations.p2AppManagerStatus.UPDATE_CORR_FILE_ERROR.getNumVal()); 
            boolean bool = b.b(this.e, arrayOfDouble9);
            b.a(this.e, this.c, bool, this.b, arrayOfDouble5, arrayOfDouble9, arrayOfDouble6, arrayOfDouble8);
            if (this.b.b()[57] != 0.0D)
              try {
                arrayOfDouble4 = p2SpectroDSP.a().a(this.b.b()[23], this.b.b()[24], (int)this.b.b()[55], arrayOfDouble4);
              } catch (a a1) {
                throw new p2AppManagerException("Error while make DSP common wavenumber Generation", p2Enumerations.p2AppManagerStatus.DSP_COMMON_WAVENUMBER_GENERATION_ERROR.getNumVal());
              }  
            b.a(this.e, this.b.i(), this.c, arrayOfDouble4, this.d);
            double[][] arrayOfDouble10 = new double[arrayOfDouble4.length][];
            for (byte b3 = 0; b3 < arrayOfDouble4.length; b3++) {
              arrayOfDouble10[b3] = new double[arrayOfDouble4[b3].length];
              System.arraycopy(arrayOfDouble4[b3], 0, arrayOfDouble10[b3], 0, arrayOfDouble4[b3].length);
            } 
            this.b.b()[19] = d1;
            this.b.b()[22] = d2;
            arrayOfDouble1 = null;
            arrayOfDouble2 = null;
            System.gc();
            return arrayOfDouble10;
          }
        }); }
  
  private Future<double[][]> a(a parama, c paramc, double[] paramArrayOfDouble, double[][] paramArrayOfDouble1) { return c.a(new a<double[][]>(this, parama, paramArrayOfDouble, paramArrayOfDouble1, paramc) {
          protected double[][] a() {
            double[][] arrayOfDouble1 = (double[][])null;
            try {
              double d1 = 100.0D * Math.sqrt(this.a.ac / 2000.0D);
              arrayOfDouble1 = p2SpectroDSP.a().a(this.b, this.c, this.d.b()[23], this.d.b()[24], 500.0D, (int)Math.floor((this.b.length / 10)), d1);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling SNR Measurement DSP function -   ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble1 == null || arrayOfDouble1[0].length == 0 || arrayOfDouble1[1].length == 0 || arrayOfDouble1[2].length == 0 || arrayOfDouble1[3].length == 0 || arrayOfDouble1[4].length == 0 || arrayOfDouble1[5].length == 0 || arrayOfDouble1[6].length == 0 || arrayOfDouble1[7].length == 0 || arrayOfDouble1[8].length == 0 || arrayOfDouble1[9].length == 0 || arrayOfDouble1[10].length == 0 || arrayOfDouble1[11].length == 0 || arrayOfDouble1[12].length == 0 || arrayOfDouble1[13].length == 0 || arrayOfDouble1[14].length == 0 || arrayOfDouble1[15].length == 0 || arrayOfDouble1[16].length == 0)
              throw new p2AppManagerException("Data coming back from SNR Measurement DSP  -    ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_EMPTY_DATA_ERROR.getNumVal()); 
            if (arrayOfDouble1.length < 17)
              throw new p2AppManagerException("Data coming back from SNR Measurement DSP lenght not right -   ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_BAD_DATA_ERROR.getNumVal()); 
            double[][] arrayOfDouble2 = new double[17][];
            for (byte b1 = 0; b1 < 17; b1++) {
              arrayOfDouble2[b1] = new double[arrayOfDouble1[b1].length];
              System.arraycopy(arrayOfDouble1[b1], 0, arrayOfDouble2[b1], 0, arrayOfDouble1[b1].length);
            } 
            System.gc();
            return arrayOfDouble2;
          }
        }); }
  
  private Future<double[][]> a(a parama, c paramc, double[] paramArrayOfDouble1, double[][] paramArrayOfDouble, double[] paramArrayOfDouble2) { return c.a(new a<double[][]>(this, paramArrayOfDouble1, paramArrayOfDouble, paramArrayOfDouble2, paramc) {
          protected double[][] a() {
            double[][] arrayOfDouble1 = (double[][])null;
            try {
              arrayOfDouble1 = p2SpectroDSP.a().a(this.a, this.b, this.c, (int)this.d.b()[54]);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling Stability Measurement DSP function -   ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble1 == null || arrayOfDouble1[0].length == 0 || arrayOfDouble1[1].length == 0 || arrayOfDouble1[2].length == 0 || arrayOfDouble1[3].length == 0 || arrayOfDouble1[4].length == 0 || arrayOfDouble1[5].length == 0 || arrayOfDouble1[6].length == 0 || arrayOfDouble1[7].length == 0)
              throw new p2AppManagerException("Data coming back from Stability Measurement DSP  -    ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_EMPTY_DATA_ERROR.getNumVal()); 
            if (arrayOfDouble1.length < 8)
              throw new p2AppManagerException("Data coming back from Stability Measurement DSP lenght not right -   ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_POST_BAD_DATA_ERROR.getNumVal()); 
            double[][] arrayOfDouble2 = new double[8][];
            byte b1;
            for (b1 = 0; b1 < 8; b1++) {
              arrayOfDouble2[b1] = new double[arrayOfDouble1[b1].length];
              System.arraycopy(arrayOfDouble1[b1], 0, arrayOfDouble2[b1], 0, arrayOfDouble1[b1].length);
            } 
            for (b1 = 0; b1 < arrayOfDouble2[1].length; b1++)
              arrayOfDouble2[1][b1] = arrayOfDouble2[1][b1] * 100.0D; 
            System.gc();
            return arrayOfDouble2;
          }
        }); }
  
  private Future<double[][]> b(a parama, int[][] paramArrayOfInt, a parama1) { return c.a(new a<double[][]>(this, paramArrayOfInt) {
          protected double[][] a() {
            double[] arrayOfDouble = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble.length; b1++)
              arrayOfDouble[b1] = this.a[0][b1]; 
            double[][] arrayOfDouble1 = (double[][])null;
            try {
              arrayOfDouble1 = p2SpectroDSP.a().b(arrayOfDouble);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling p2SpectroDSP_MEMSResponse ", p2Enumerations.p2AppManagerStatus.DSP_MEMS_RESPONSE_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble1 == null || arrayOfDouble1.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty    ", p2Enumerations.p2AppManagerStatus.DSP_MEMS_RESPONSE_POST_PROCESSING_ERROR.getNumVal()); 
            return arrayOfDouble1;
          }
        }); }
  
  private Future<double[][]> c(a parama, int[][] paramArrayOfInt, a parama1) { return c.a(new a<double[][]>(this, paramArrayOfInt) {
          protected double[][] a() {
            double[] arrayOfDouble = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble.length; b1++)
              arrayOfDouble[b1] = this.a[0][b1]; 
            double[][] arrayOfDouble1 = (double[][])null;
            try {
              arrayOfDouble1 = p2SpectroDSP.a().c(arrayOfDouble);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling p2SpectroDSP_ParametersCalculation_ResFreqAndQualityFactor ", p2Enumerations.p2AppManagerStatus.DSP_PARAMETERS_CALC_RES_FREQ_QUALITY_FACTOR_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble1 == null || arrayOfDouble1.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty ", p2Enumerations.p2AppManagerStatus.DSP_PARAMETERS_CALC_RES_FREQ_QUALITY_FACTOR_POST_PROCESSING_ERROR.getNumVal()); 
            return arrayOfDouble1;
          }
        }); }
  
  private Future<double[][]> d(a parama, int[][] paramArrayOfInt, a parama1) { return c.a(new a<double[][]>(this, paramArrayOfInt, parama, parama1) {
          protected double[][] a() {
            double[] arrayOfDouble = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble.length; b1++)
              arrayOfDouble[b1] = this.a[0][b1]; 
            double[][] arrayOfDouble1 = (double[][])null;
            try {
              double d1 = this.b.b(i.fH.a(), k.fH.a(), j.fH.a());
              double d2 = this.b.b(i.fI.a(), k.fI.a(), j.fI.a());
              arrayOfDouble1 = p2SpectroDSP.a().b(arrayOfDouble, this.c.m, this.c.j, d1, d2);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling p2SpectroDSP_ParametersCalculation_ForwardGain ", p2Enumerations.p2AppManagerStatus.DSP_PARAMETERS_CALC_FORWARD_GAIN_POST_PROCESSING_ERROR.getNumVal());
            } catch (a a1) {
              throw new p2AppManagerException("Error while reading ASIC registers   ", p2Enumerations.p2AppManagerStatus.DSP_CAP_CURRENT_POST_BAD_DATA_ERROR.getNumVal());
            } 
            if (arrayOfDouble1 == null || arrayOfDouble1.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty ", p2Enumerations.p2AppManagerStatus.DSP_PARAMETERS_CALC_FORWARD_GAIN_POST_PROCESSING_ERROR.getNumVal()); 
            return arrayOfDouble1;
          }
        }); }
  
  private Future<double[][]> e(a parama, a parama1) { return c.a(new a<double[][]>(this, parama1) {
          protected double[][] a() {
            String[] arrayOfString1 = new String[2];
            bufferedReader = null;
            try {
              bufferedReader = new BufferedReader(new FileReader(p2Constants.getPath(p2Constants.CLOSED_LOOP_GAIN_VS_FREQ_FILE_PATH)));
              arrayOfString1[0] = bufferedReader.readLine();
              arrayOfString1[1] = bufferedReader.readLine();
            } catch (Exception exception) {
              b.v().error(exception.getMessage());
            } finally {
              try {
                bufferedReader.close();
              } catch (Exception exception) {
                b.v().error(exception.getMessage());
              } 
            } 
            String[] arrayOfString2 = arrayOfString1[0].split(" ");
            double[] arrayOfDouble1 = new double[arrayOfString2.length];
            for (byte b1 = 0; b1 < arrayOfString2.length; b1++)
              arrayOfDouble1[b1] = Double.parseDouble(arrayOfString2[b1]); 
            arrayOfString2 = arrayOfString1[1].split(" ");
            double[] arrayOfDouble2 = new double[arrayOfString2.length];
            for (byte b2 = 0; b2 < arrayOfString2.length; b2++)
              arrayOfDouble2[b2] = Double.parseDouble(arrayOfString2[b2]); 
            double[][] arrayOfDouble = (double[][])null;
            try {
              arrayOfDouble = p2SpectroDSP.a().a(this.a.L, this.a.M, this.a.N, this.a.O, arrayOfDouble1, arrayOfDouble2, this.a.m);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling p2SpectroDSP_ParametersCalculation_ForwardGain ", p2Enumerations.p2AppManagerStatus.DSP_COEFFICIENTS_CALC_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble == null || arrayOfDouble.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty ", p2Enumerations.p2AppManagerStatus.DSP_COEFFICIENTS_CALC_POST_PROCESSING_ERROR.getNumVal()); 
            return arrayOfDouble;
          }
        }); }
  
  private Future<double[][]> a(a parama, int[][] paramArrayOfInt1, int[][] paramArrayOfInt2, a parama1) { return c.a(new a<double[][]>(this, paramArrayOfInt1, paramArrayOfInt2, parama1) {
          protected double[][] a() {
            double[] arrayOfDouble1 = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
              arrayOfDouble1[b1] = this.a[0][b1]; 
            double[] arrayOfDouble2 = new double[this.b[0].length];
            for (byte b2 = 0; b2 < arrayOfDouble2.length; b2++)
              arrayOfDouble2[b2] = this.b[0][b2]; 
            double[][] arrayOfDouble = (double[][])null;
            try {
              arrayOfDouble = p2SpectroDSP.a().a(arrayOfDouble2, arrayOfDouble1, this.c.L);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling p2SpectroDSP_PhaseTrimming_PhaseValidation ", p2Enumerations.p2AppManagerStatus.DSP_PHASE_VALIDATION_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble == null || arrayOfDouble.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty ", p2Enumerations.p2AppManagerStatus.DSP_PHASE_VALIDATION_POST_PROCESSING_ERROR.getNumVal()); 
            return arrayOfDouble;
          }
        }); }
  
  private Future<double[][]> b(a parama, int[][] paramArrayOfInt1, int[][] paramArrayOfInt2, a parama1) { return c.a(new a<double[][]>(this, paramArrayOfInt1, paramArrayOfInt2, parama, parama1) {
          protected double[][] a() {
            double d2;
            double[] arrayOfDouble1 = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
              arrayOfDouble1[b1] = this.a[0][b1]; 
            double[] arrayOfDouble2 = new double[this.b[0].length];
            double d1;
            for (d1 = false; d1 < arrayOfDouble2.length; d1++)
              arrayOfDouble2[d1] = this.b[0][d1]; 
            try {
              d1 = this.c.b(i.fH.a(), k.fH.a(), j.fH.a());
              d2 = this.c.b(i.fI.a(), k.fI.a(), j.fI.a());
            } catch (a a1) {
              throw new p2AppManagerException("Error while reading ASIC registers before p2SpectroDSP_StabilityCheck ", p2Enumerations.p2AppManagerStatus.DSP_STABILITY_CHECK_POST_PROCESSING_ERROR.getNumVal());
            } 
            double[][] arrayOfDouble = (double[][])null;
            try {
              arrayOfDouble = p2SpectroDSP.a().a(arrayOfDouble2, arrayOfDouble1, this.d.m, this.d.L, d1, d2);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling p2SpectroDSP_StabilityCheck ", p2Enumerations.p2AppManagerStatus.DSP_STABILITY_CHECK_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble == null || arrayOfDouble.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty ", p2Enumerations.p2AppManagerStatus.DSP_STABILITY_CHECK_POST_PROCESSING_ERROR.getNumVal()); 
            return arrayOfDouble;
          }
        }); }
  
  private Future<double[][]> a(a parama, int[][] paramArrayOfInt, int paramInt, double paramDouble, a parama1) { return c.a(new a<double[][]>(this, paramArrayOfInt, parama1, paramInt, paramDouble) {
          protected double[][] a() {
            double[] arrayOfDouble = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble.length; b1++)
              arrayOfDouble[b1] = this.a[0][b1]; 
            double[][] arrayOfDouble1 = (double[][])null;
            try {
              arrayOfDouble1 = p2SpectroDSP.a().a(arrayOfDouble, this.b.V, this.c, this.d);
            } catch (a a1) {
              throw new p2AppManagerException("Error while calling p2SpectroDSP_GainMarginCalc ", p2Enumerations.p2AppManagerStatus.DSP_GAIN_MARGIN_CALC_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble1 == null || arrayOfDouble1.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty ", p2Enumerations.p2AppManagerStatus.DSP_GAIN_MARGIN_CALC_POST_PROCESSING_ERROR.getNumVal()); 
            return arrayOfDouble1;
          }
        }); }
  
  private Future<double[][]> e(a parama, int[][] paramArrayOfInt, a parama1) { return c.a(new a<double[][]>(this, paramArrayOfInt, parama, parama1) {
          protected double[][] a() {
            double[] arrayOfDouble1 = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
              arrayOfDouble1[b1] = this.a[0][b1]; 
            double[] arrayOfDouble2 = new double[this.a[2].length];
            for (byte b2 = 0; b2 < arrayOfDouble2.length; b2++)
              arrayOfDouble2[b2] = this.a[2][b2]; 
            double[][] arrayOfDouble = (double[][])null;
            try {
              double d1 = this.b.b(i.fH.a(), k.fH.a(), j.fH.a());
              double d2 = this.b.b(i.fI.a(), k.fI.a(), j.fI.a());
              int i = (int)this.b.b(i.fy.a(), k.fy.a(), j.fy.a());
              double d3 = Math.pow(2.0D, i) * 5000.0D * this.c.p * this.c.q;
              arrayOfDouble = p2SpectroDSP.a().a(arrayOfDouble1, arrayOfDouble2, b.a(this.d).b(), d3, this.c.m, d1, d2);
            } catch (a a1) {
              throw new p2AppManagerException("Error while make DSP data cap & current processing   ", p2Enumerations.p2AppManagerStatus.DSP_CAP_CURRENT_POST_PROCESSING_ERROR.getNumVal());
            } catch (a a1) {
              throw new p2AppManagerException("Error while reading ASIC registers   ", p2Enumerations.p2AppManagerStatus.DSP_CAP_CURRENT_POST_BAD_DATA_ERROR.getNumVal());
            } 
            if (arrayOfDouble == null || arrayOfDouble.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty    ", p2Enumerations.p2AppManagerStatus.DSP_CAP_CURRENT_POST_EMPTY_DATA_ERROR.getNumVal()); 
            if (arrayOfDouble.length < 12)
              throw new p2AppManagerException("Data backed from DSP post processign lenght not right ", p2Enumerations.p2AppManagerStatus.DSP_CAP_CURRENT_POST_BAD_DATA_ERROR.getNumVal()); 
            return arrayOfDouble;
          }
        }); }
  
  private Future<double[]> f(a parama, int[][] paramArrayOfInt, a parama1) { return c.a(new a<double[]>(this, paramArrayOfInt, parama1) {
          protected double[] a() {
            double[] arrayOfDouble1 = new double[this.a[0].length];
            for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
              arrayOfDouble1[b1] = this.a[0][b1]; 
            double[] arrayOfDouble2 = null;
            try {
              b.a(this.c, b.a(this.c).b());
              arrayOfDouble2 = p2SpectroDSP.a().a(arrayOfDouble1, b.d(this.c), this.b.v, this.b.t, this.b.u);
            } catch (a a1) {
              throw new p2AppManagerException("Error while make DSP data cap vs time processing   ", p2Enumerations.p2AppManagerStatus.DSP_CALIB_CAP_TIME_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble2 == null || arrayOfDouble2.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty    ", p2Enumerations.p2AppManagerStatus.DSP_CALIB_CAP_TIME_POST_EMPTY_DATA_ERROR.getNumVal()); 
            if (arrayOfDouble2.length < 7)
              throw new p2AppManagerException("Data backed from DSP post processign lenght not right ", p2Enumerations.p2AppManagerStatus.DSP_CALIB_CAP_TIME_POST_BAD_DATA_ERROR.getNumVal()); 
            return arrayOfDouble2;
          }
        }); }
  
  private Future<double[]> a(a parama, int[] paramArrayOfInt1, int[] paramArrayOfInt2, a parama1, int paramInt1, int paramInt2, int paramInt3) { return c.a(new a<double[]>(this, paramArrayOfInt1, paramArrayOfInt2, paramInt1, paramInt2, paramInt3) {
          protected double[] a() {
            double[] arrayOfDouble1 = new double[this.a.length];
            for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++)
              arrayOfDouble1[b1] = this.a[b1]; 
            double[] arrayOfDouble2 = new double[this.b.length];
            for (byte b2 = 0; b2 < arrayOfDouble2.length; b2++)
              arrayOfDouble2[b2] = this.b[b2]; 
            double[] arrayOfDouble3 = null;
            try {
              arrayOfDouble3 = p2SpectroDSP.a().a(arrayOfDouble1, arrayOfDouble2, b.a(this.f).k(), b.a(this.f).l(), this.c, this.d, true, this.e);
            } catch (a a1) {
              throw new p2AppManagerException("Error while make DSP data delay compensation processing   ", p2Enumerations.p2AppManagerStatus.DSP_CALIB_DELAY_COMP_POST_PROCESSING_ERROR.getNumVal());
            } 
            if (arrayOfDouble3 == null || arrayOfDouble3.length == 0)
              throw new p2AppManagerException("Data backed from DSP post processign is empty    ", p2Enumerations.p2AppManagerStatus.DSP_CALIB_DELAY_COMP_POST_EMPTY_DATA_ERROR.getNumVal()); 
            if (arrayOfDouble3.length < 3)
              throw new p2AppManagerException("Data backed from DSP post processign lenght not right ", p2Enumerations.p2AppManagerStatus.DSP_CALIB_DELAY_COMP_POST_BAD_DATA_ERROR.getNumVal()); 
            return arrayOfDouble3;
          }
        }); }
  
  private void a(a parama, boolean paramBoolean, c paramc, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4) {
    if (parama.c == 1) {
      a(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble3, paramArrayOfDouble4, parama, paramBoolean, paramc);
      return;
    } 
    if (paramBoolean)
      for (byte b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
        paramArrayOfDouble3[b1] = paramc.j()[0] * paramArrayOfDouble3[b1] + paramc.j()[1];  
  }
  
  private boolean a(double[] paramArrayOfDouble) { return true; }
  
  private void a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3, double[] paramArrayOfDouble4, a parama, boolean paramBoolean, c paramc) {
    try {
      double[] arrayOfDouble = new double[paramArrayOfDouble1.length];
      System.arraycopy(paramArrayOfDouble1, 0, arrayOfDouble, 0, paramArrayOfDouble1.length);
      double[][] arrayOfDouble1 = p2SpectroDSP.a().a(paramc.b(), parama.c, parama.d, parama.f, paramArrayOfDouble2, arrayOfDouble, paramArrayOfDouble3, paramc.i());
      byte b1;
      for (b1 = 0; b1 < paramArrayOfDouble1.length; b1++)
        paramArrayOfDouble1[b1] = arrayOfDouble1[2][b1]; 
      for (b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
        paramArrayOfDouble2[b1] = arrayOfDouble1[3][b1]; 
      if (paramBoolean) {
        for (b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          paramArrayOfDouble3[b1] = 1.0D / (paramc.j()[0] / arrayOfDouble1[0][b1] + paramc.j()[1]); 
      } else {
        for (b1 = 0; b1 < paramArrayOfDouble3.length; b1++)
          paramArrayOfDouble3[b1] = arrayOfDouble1[0][b1]; 
      } 
      for (b1 = 0; b1 < paramArrayOfDouble4.length; b1++)
        paramArrayOfDouble4[b1] = arrayOfDouble1[1][b1]; 
    } catch (a a1) {
      throw new p2AppManagerException("Error while FFT post processing    ", p2Enumerations.p2AppManagerStatus.DSP_INTERFEROGRAM_FFT_POST_PROCESSINF_ERROR.getNumVal());
    } 
  }
  
  private void a(double[] paramArrayOfDouble, a parama, double[][] paramArrayOfDouble1, double[][] paramArrayOfDouble2) {
    if (parama.a == p2Enumerations.p2AppManagerState.InterferogramRun) {
      a(paramArrayOfDouble, paramArrayOfDouble1[0]);
      byte b1;
      for (b1 = 0; b1 < paramArrayOfDouble1[1].length; b1++)
        paramArrayOfDouble1[1][b1] = paramArrayOfDouble1[1][b1] * 1000.0D; 
      for (b1 = 0; b1 < paramArrayOfDouble1[3].length; b1++)
        paramArrayOfDouble1[3][b1] = Math.pow(10.0D, (paramArrayOfDouble1[3][b1] + 30.0D) / 10.0D); 
    } else if (parama.a == p2Enumerations.p2AppManagerState.SpectroscopySampleRun) {
      double[][] arrayOfDouble = a(paramArrayOfDouble1);
      a(paramArrayOfDouble, arrayOfDouble[0]);
      this.k = arrayOfDouble;
      b(paramArrayOfDouble1[3]);
      a(paramArrayOfDouble1, paramArrayOfDouble2);
    } else if (parama.a == p2Enumerations.p2AppManagerState.wavelengthCalibrationBG_Run) {
      b(paramArrayOfDouble1[3]);
    } else if (parama.a == p2Enumerations.p2AppManagerState.wavelengthCalibration_Run) {
      b(paramArrayOfDouble1[3]);
      a(paramArrayOfDouble1, paramArrayOfDouble2);
      byte b1;
      for (b1 = 0; b1 < paramArrayOfDouble1[1].length; b1++)
        paramArrayOfDouble1[1][b1] = paramArrayOfDouble1[1][b1] * 1000.0D; 
      for (b1 = 0; b1 < paramArrayOfDouble1[3].length; b1++)
        paramArrayOfDouble1[3][b1] = Math.pow(10.0D, paramArrayOfDouble1[3][b1] / 10.0D); 
    } else if (parama.a == p2Enumerations.p2AppManagerState.StabilityRun) {
      int i1;
      double[] arrayOfDouble1 = paramArrayOfDouble1[3];
      double[] arrayOfDouble2 = paramArrayOfDouble1[5];
      double[] arrayOfDouble3 = paramArrayOfDouble2[3];
      if (arrayOfDouble1.length < arrayOfDouble3.length) {
        i1 = arrayOfDouble1.length;
      } else {
        i1 = arrayOfDouble3.length;
      } 
      byte b1;
      for (b1 = 0; b1 < i1; b1++)
        arrayOfDouble1[b1] = arrayOfDouble1[b1] / arrayOfDouble3[b1]; 
      b(paramArrayOfDouble1[5]);
      if (arrayOfDouble2.length < arrayOfDouble3.length) {
        i1 = arrayOfDouble2.length;
      } else {
        i1 = arrayOfDouble3.length;
      } 
      for (b1 = 0; b1 < i1; b1++)
        arrayOfDouble2[b1] = arrayOfDouble2[b1] - arrayOfDouble3[b1]; 
    } else if (parama.a == p2Enumerations.p2AppManagerState.SpectroscopyBackgroundRun) {
      b(paramArrayOfDouble1[3]);
      b(paramArrayOfDouble1);
    } else if (parama.a == p2Enumerations.p2AppManagerState.updateFFT_SettingsInterSpecRun) {
      for (byte b1 = 0; b1 < paramArrayOfDouble1[3].length; b1++)
        paramArrayOfDouble1[3][b1] = Math.pow(10.0D, (paramArrayOfDouble1[3][b1] + 30.0D) / 10.0D); 
    } else if (parama.a == p2Enumerations.p2AppManagerState.updateFFT_SettingsSpecRun) {
      b(paramArrayOfDouble2[3]);
      b(paramArrayOfDouble1[3]);
      a(paramArrayOfDouble1, paramArrayOfDouble2);
    } 
  }
  
  private double[][] a(double[][] paramArrayOfDouble) {
    double[][] arrayOfDouble = new double[paramArrayOfDouble.length][];
    for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++) {
      arrayOfDouble[b1] = new double[paramArrayOfDouble[b1].length];
      System.arraycopy(paramArrayOfDouble[b1], 0, arrayOfDouble[b1], 0, paramArrayOfDouble[b1].length);
    } 
    return arrayOfDouble;
  }
  
  private void a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2) {
    double d1 = paramArrayOfDouble1[0];
    for (byte b1 = 0; b1 < paramArrayOfDouble2.length; b1++)
      paramArrayOfDouble2[b1] = paramArrayOfDouble2[b1] - d1; 
  }
  
  private void b(double[] paramArrayOfDouble) {
    for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
      paramArrayOfDouble[b1] = paramArrayOfDouble[b1] - 30.0D; 
  }
  
  private void a(double[][] paramArrayOfDouble1, double[][] paramArrayOfDouble2) {
    int i1;
    double[] arrayOfDouble1 = paramArrayOfDouble1[3];
    double[] arrayOfDouble2 = paramArrayOfDouble2[3];
    if (arrayOfDouble1.length < arrayOfDouble2.length) {
      i1 = arrayOfDouble1.length;
    } else {
      i1 = arrayOfDouble2.length;
    } 
    for (byte b1 = 0; b1 < i1; b1++)
      arrayOfDouble1[b1] = arrayOfDouble1[b1] - arrayOfDouble2[b1]; 
  }
  
  private boolean b(double[]... paramVarArgs) {
    if (!p2AppManagerUtils.createDir(p2Constants.WHITE_LIGHT_FILES_DIR))
      throw new p2AppManagerException("Error while creating white light folder    ", p2Enumerations.p2AppManagerStatus.WHITE_LIGHT_PROCESSING_ERROR.getNumVal()); 
    String str = Arrays.toString(p2AppManagerUtils.concatenateMultipleArraysIntoOne(paramVarArgs));
    String[] arrayOfString = str.substring(1, str.length() - 1).split(",");
    if (!p2AppManagerUtils.writeFileOfArray(arrayOfString, p2Constants.WHITE_LIGHT_FILES_DIR + File.separatorChar + "WhiteLight.xml", null))
      throw new p2AppManagerException("Error while write white light file    ", p2Enumerations.p2AppManagerStatus.WHITE_LIGHT_PROCESSING_ERROR.getNumVal()); 
    return true;
  }
  
  private p2Enumerations.p2AppManagerStatus y() {
    try {
      int i1 = this.O.a();
      if (i1 == 14) {
        this.F = "";
        this.E = "";
        return p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR;
      } 
      if (i1 == 74) {
        this.F = "";
        this.E = "";
        return p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR;
      } 
      return p2Enumerations.p2AppManagerStatus.BOARD_ALREADY_INITIALIZED;
    } catch (a a1) {
      return p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR;
    } 
  }
  
  private a a(p2Enumerations.p2DeviceAction paramp2DeviceAction, String... paramVarArgs) throws Exception, a {
    long l6;
    long l5;
    long l4;
    long l3;
    long l2;
    long l1;
    a a1;
    switch (null.a[paramp2DeviceAction.ordinal()]) {
      case 1:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        if (paramVarArgs.length == 3 && (p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2])))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.f = 0;
        if (paramVarArgs.length == 3) {
          a1.af = Integer.parseInt(paramVarArgs[1]);
          a1.ag = Integer.parseInt(paramVarArgs[2]);
        } else {
          a1.af = 0;
          a1.ag = 1;
        } 
        a1.a = p2Enumerations.p2AppManagerState.InterferogramRun;
        return a1;
      case 2:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.af = Integer.parseInt(paramVarArgs[0]);
        a1.ag = Integer.parseInt(paramVarArgs[1]);
        a1.a = p2Enumerations.p2AppManagerState.updateFFT_SettingsInterSpecRun;
        return a1;
      case 3:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.af = Integer.parseInt(paramVarArgs[0]);
        a1.ag = Integer.parseInt(paramVarArgs[1]);
        a1.a = p2Enumerations.p2AppManagerState.updateFFT_SettingsSpecRun;
        return a1;
      case 4:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        if (paramVarArgs.length == 4 && (p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3])))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.BG_SPEC_WL_CORR;
        a1.f = 0;
        if (paramVarArgs.length == 4) {
          a1.af = Integer.parseInt(paramVarArgs[2]);
          a1.ag = Integer.parseInt(paramVarArgs[3]);
        } else {
          a1.af = 0;
          a1.ag = 1;
        } 
        a1.a = p2Enumerations.p2AppManagerState.SpectroscopyBackgroundRun;
        a(p2Enumerations.p2AppManagerState.SpectroscopyBackgroundRun);
        return a1;
      case 5:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        if (paramVarArgs.length == 4 && (p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3])))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.SPEC_WL_CORR;
        a1.f = 0;
        if (paramVarArgs.length == 4) {
          a1.af = Integer.parseInt(paramVarArgs[2]);
          a1.ag = Integer.parseInt(paramVarArgs[3]);
        } else {
          a1.af = 0;
          a1.ag = 1;
        } 
        a1.a = p2Enumerations.p2AppManagerState.SpectroscopySampleRun;
        a(p2Enumerations.p2AppManagerState.SpectroscopySampleRun);
        return a1;
      case 6:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.BG_SPEC_WL_CORR;
        a1.f = 0;
        a1.af = Integer.parseInt(paramVarArgs[1]);
        a1.ag = Integer.parseInt(paramVarArgs[2]);
        a1.a = p2Enumerations.p2AppManagerState.wavelengthCalibrationBG_Run;
        a(p2Enumerations.p2AppManagerState.wavelengthCalibrationBG_Run);
        return a1;
      case 7:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.Y = paramVarArgs[1];
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.SPEC_WL_CORR;
        a1.f = 0;
        a1.af = Integer.parseInt(paramVarArgs[2]);
        a1.ag = Integer.parseInt(paramVarArgs[3]);
        a1.a = p2Enumerations.p2AppManagerState.wavelengthCalibration_Run;
        a(p2Enumerations.p2AppManagerState.wavelengthCalibration_Run);
        return a1;
      case 8:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.f = 0;
        a1.a = p2Enumerations.p2AppManagerState.gainAdjustInterSpecRun;
        return a1;
      case 9:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.f = 0;
        a1.a = p2Enumerations.p2AppManagerState.gainAdjustSpecBG_Run;
        return a1;
      case 10:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.f = 0;
        a1.af = Integer.parseInt(paramVarArgs[1]);
        a1.ag = Integer.parseInt(paramVarArgs[2]);
        a1.a = p2Enumerations.p2AppManagerState.gainAdjustSpecSampleRun;
        return a1;
      case 11:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.ad = Integer.parseInt(paramVarArgs[1]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.f = 0;
        a1.af = Integer.parseInt(paramVarArgs[2]);
        a1.ag = Integer.parseInt(paramVarArgs[3]);
        a1.a = p2Enumerations.p2AppManagerState.SNR_Run;
        return a1;
      case 12:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.ad = Integer.parseInt(paramVarArgs[1]);
        a1.Y = paramVarArgs[2];
        a1.ae = Integer.parseInt(paramVarArgs[3]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.f = 0;
        a1.af = Integer.parseInt(paramVarArgs[4]);
        a1.ag = Integer.parseInt(paramVarArgs[5]);
        a1.a = p2Enumerations.p2AppManagerState.StabilityRun;
        return a1;
      case 13:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.c = 0;
        a1.d = 0;
        a1.e = p2Constants.INTER_SPEC_WL_CORR;
        a1.f = 1;
        a1.af = Integer.parseInt(paramVarArgs[1]);
        a1.ag = Integer.parseInt(paramVarArgs[2]);
        a1.a = p2Enumerations.p2AppManagerState.selfCorr_Run;
        return a1;
      case 14:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[9]) || p2AppManagerUtils.isEmptyString(paramVarArgs[10]) || p2AppManagerUtils.isEmptyString(paramVarArgs[11]) || p2AppManagerUtils.isEmptyString(paramVarArgs[12]) || p2AppManagerUtils.isEmptyString(paramVarArgs[13]) || p2AppManagerUtils.isEmptyString(paramVarArgs[14]) || p2AppManagerUtils.isEmptyString(paramVarArgs[15]) || p2AppManagerUtils.isEmptyString(paramVarArgs[16]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.h = Boolean.parseBoolean(paramVarArgs[1]);
        a1.i = paramVarArgs[2];
        a1.j = Double.parseDouble(paramVarArgs[3]);
        if (a1.h) {
          a1.b = Double.parseDouble(paramVarArgs[4]);
          a1.m = Double.parseDouble(paramVarArgs[7]);
          a1.k = paramVarArgs[5];
          a1.l = Integer.parseInt(paramVarArgs[6]);
          a1.n = Double.parseDouble(paramVarArgs[8]);
        } else {
          long l7 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
          a1.b = l7 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
          a1.m = Double.parseDouble(paramVarArgs[7]);
        } 
        a1.t = Double.parseDouble(paramVarArgs[9]);
        a1.u = Integer.parseInt(paramVarArgs[10]);
        a1.v = Integer.parseInt(paramVarArgs[11]);
        a1.w = paramVarArgs[12];
        a1.p = Integer.parseInt(paramVarArgs[13]);
        a1.q = Integer.parseInt(paramVarArgs[14]);
        a1.o = paramVarArgs[15];
        a1.r = Boolean.parseBoolean(paramVarArgs[16]);
        a1.g = (int)a1.ac * c.z;
        a1.a = p2Enumerations.p2AppManagerState.CalibrationCapVsTimeRun;
        a(a1.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
        if (a1.h) {
          a(a1.k, p2Constants.getPath(p2Constants.ACTUATION_DIRECTION_OPTION_FILE_PATH));
          a(a1.i, p2Constants.getPath(p2Constants.WAVEFORM_OPTION_FILE_PATH));
          long l7 = Math.round((a1.j * Math.pow(2.0D, k.cF.a()) - 1.0D) / 100.0D);
          this.O.b(i.cF.a(), l7, k.cF.a(), j.cF.a());
          if (a1.i.contains("Square"))
            a1.b *= 2.0D; 
          long l8 = (long)(a1.b * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
          this.O.b(i.cD.a(), l8, k.cD.a(), j.cD.a());
          a(String.valueOf(a1.l), p2Constants.getPath(p2Constants.SAMPLING_RATE_OPTION_FILE_PATH));
          a(String.valueOf(a1.m), p2Constants.getPath(p2Constants.EXCITATION_VOLTAGE_OPTION_FILE_PATH));
          a(String.valueOf(a1.n), p2Constants.getPath(p2Constants.C2V_GAIN_OPTION_FILE_PATH));
        } 
        a(String.valueOf(a1.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
        a(String.valueOf(a1.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
        if (a1.r) {
          this.O.b(i.fD.a(), 1L, k.fD.a(), j.fD.a());
        } else {
          this.O.b(i.fD.a(), 0L, k.fD.a(), j.fD.a());
        } 
        a(p2Enumerations.p2AppManagerState.CalibrationCapVsTimeRun);
        return a1;
      case 15:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[8]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.o = paramVarArgs[1];
        a1.p = Integer.parseInt(paramVarArgs[2]);
        a1.q = Integer.parseInt(paramVarArgs[3]);
        a1.r = Boolean.parseBoolean(paramVarArgs[4]);
        a1.h = Boolean.parseBoolean(paramVarArgs[7]);
        a1.v = Integer.parseInt(paramVarArgs[8]);
        if (a1.h) {
          a1.b = Double.parseDouble(paramVarArgs[5]);
          a1.i = paramVarArgs[6];
        } else {
          long l7 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
          a1.b = l7 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
        } 
        a1.a = p2Enumerations.p2AppManagerState.CalibrationDelayCompensationRun;
        a(a1.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
        if (a1.h) {
          if (a1.i.contains("Square"))
            a1.b *= 2.0D; 
          long l7 = (long)(a1.b * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
          this.O.b(i.cD.a(), l7, k.cD.a(), j.cD.a());
        } 
        a(String.valueOf(a1.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
        a(String.valueOf(a1.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
        if (a1.r) {
          this.O.b(i.fD.a(), 1L, k.fD.a(), j.fD.a());
        } else {
          this.O.b(i.fD.a(), 0L, k.fD.a(), j.fD.a());
        } 
        this.O.b(i.aW.a(), a1.v, k.aW.a(), j.aW.a());
        this.O.b(i.gt.a(), a1.v, k.gt.a(), j.gt.a());
        a(p2Enumerations.p2AppManagerState.CalibrationDelayCompensationRun);
        return a1;
      case 16:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[8]) || p2AppManagerUtils.isEmptyString(paramVarArgs[9]) || p2AppManagerUtils.isEmptyString(paramVarArgs[10]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.h = Boolean.parseBoolean(paramVarArgs[7]);
        if (a1.h) {
          a1.b = Double.parseDouble(paramVarArgs[1]);
          a1.i = paramVarArgs[5];
        } else {
          long l7 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
          a1.b = l7 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
        } 
        a1.y = Boolean.parseBoolean(paramVarArgs[2]);
        a1.x = Boolean.parseBoolean(paramVarArgs[3]);
        a1.z = Boolean.parseBoolean(paramVarArgs[4]);
        a1.o = paramVarArgs[6];
        a1.p = Integer.parseInt(paramVarArgs[8]);
        a1.q = Integer.parseInt(paramVarArgs[9]);
        a1.v = Integer.parseInt(paramVarArgs[10]);
        a1.a = p2Enumerations.p2AppManagerState.CalibrationCoreRun;
        if (a1.h) {
          if (a1.i.contains("Square"))
            a1.b *= 2.0D; 
          long l7 = (long)(a1.b * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
          this.O.b(i.cD.a(), l7, k.cD.a(), j.cD.a());
        } 
        a(a1.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
        a(String.valueOf(a1.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
        a(String.valueOf(a1.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
        this.O.b(i.aW.a(), a1.v, k.aW.a(), j.aW.a());
        this.O.b(i.gt.a(), a1.v, k.gt.a(), j.gt.a());
        a(p2Enumerations.p2AppManagerState.CalibrationDelayCompensationRun);
        return a1;
      case 17:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[8]) || p2AppManagerUtils.isEmptyString(paramVarArgs[9]) || p2AppManagerUtils.isEmptyString(paramVarArgs[10]) || p2AppManagerUtils.isEmptyString(paramVarArgs[11]) || p2AppManagerUtils.isEmptyString(paramVarArgs[12]) || p2AppManagerUtils.isEmptyString(paramVarArgs[13]) || p2AppManagerUtils.isEmptyString(paramVarArgs[14]) || p2AppManagerUtils.isEmptyString(paramVarArgs[15]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.h = Boolean.parseBoolean(paramVarArgs[13]);
        if (a1.h) {
          a1.b = Double.parseDouble(paramVarArgs[1]);
          a1.m = Double.parseDouble(paramVarArgs[4]);
          a1.n = Double.parseDouble(paramVarArgs[11]);
          a1.i = paramVarArgs[12];
        } else {
          long l7 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
          a1.b = l7 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
          a1.m = Double.parseDouble(paramVarArgs[4]);
        } 
        a1.A = Boolean.parseBoolean(paramVarArgs[2]);
        a1.B = Double.parseDouble(paramVarArgs[3]);
        a1.v = Integer.parseInt(paramVarArgs[5]);
        a1.C = paramVarArgs[6];
        a1.D = paramVarArgs[7];
        if (paramVarArgs.length == 17) {
          if (p2AppManagerUtils.isEmptyString(paramVarArgs[16]))
            throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
          a1.t = Double.parseDouble(paramVarArgs[16]);
          a1.s = true;
        } else {
          a1.s = false;
        } 
        if (paramVarArgs.length == 18) {
          if (p2AppManagerUtils.isEmptyString(paramVarArgs[17]))
            throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
          a1.ah = paramVarArgs[17];
        } else {
          a1.ah = null;
        } 
        a1.p = Integer.parseInt(paramVarArgs[8]);
        a1.q = Integer.parseInt(paramVarArgs[9]);
        a1.o = paramVarArgs[10];
        a1.X = Boolean.parseBoolean(paramVarArgs[14]);
        a1.Y = paramVarArgs[15];
        a1.e = p2Constants.CALIB_WL_CORR;
        a1.a = p2Enumerations.p2AppManagerState.CalibrationGeneration;
        if (a1.h) {
          if (a1.i.contains("Square"))
            a1.b *= 2.0D; 
          long l7 = (long)(a1.b * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
          this.O.b(i.cD.a(), l7, k.cD.a(), j.cD.a());
          a(String.valueOf(a1.m), p2Constants.getPath(p2Constants.EXCITATION_VOLTAGE_OPTION_FILE_PATH));
          a(String.valueOf(a1.n), p2Constants.getPath(p2Constants.C2V_GAIN_OPTION_FILE_PATH));
        } 
        a(a1.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
        a(String.valueOf(a1.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
        a(String.valueOf(a1.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
        this.O.b(i.aW.a(), a1.v, k.aW.a(), j.aW.a());
        this.O.b(i.gt.a(), a1.v, k.gt.a(), j.gt.a());
        a(p2Enumerations.p2AppManagerState.CalibrationDelayCompensationRun);
        return a1;
      case 18:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[9]) || p2AppManagerUtils.isEmptyString(paramVarArgs[10]) || p2AppManagerUtils.isEmptyString(paramVarArgs[11]) || p2AppManagerUtils.isEmptyString(paramVarArgs[12]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.h = Boolean.parseBoolean(paramVarArgs[1]);
        a1.i = paramVarArgs[2];
        a1.j = Double.parseDouble(paramVarArgs[3]);
        if (a1.h) {
          a1.b = Double.parseDouble(paramVarArgs[4]);
          a1.m = Double.parseDouble(paramVarArgs[11]);
          a1.k = paramVarArgs[5];
          a1.l = Integer.parseInt(paramVarArgs[10]);
          a1.n = Double.parseDouble(paramVarArgs[12]);
        } else {
          long l7 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
          a1.b = l7 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
          a1.m = Double.parseDouble(paramVarArgs[11]);
        } 
        a1.o = paramVarArgs[6];
        a1.p = Integer.parseInt(paramVarArgs[7]);
        a1.q = Integer.parseInt(paramVarArgs[8]);
        a1.r = Boolean.parseBoolean(paramVarArgs[9]);
        a1.g = (int)a1.ac * c.z;
        a1.a = p2Enumerations.p2AppManagerState.CapCurrentRun;
        if (a1.h) {
          a(a1.k, p2Constants.getPath(p2Constants.ACTUATION_DIRECTION_OPTION_FILE_PATH));
          a(a1.i, p2Constants.getPath(p2Constants.WAVEFORM_OPTION_FILE_PATH));
          long l7 = Math.round((a1.j * Math.pow(2.0D, k.cF.a()) - 1.0D) / 100.0D);
          this.O.b(i.cF.a(), l7, k.cF.a(), j.cF.a());
          if (a1.i.contains("Square"))
            a1.b *= 2.0D; 
          long l8 = (long)(a1.b * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
          this.O.b(i.cD.a(), l8, k.cD.a(), j.cD.a());
          a(String.valueOf(a1.l), p2Constants.getPath(p2Constants.SAMPLING_RATE_OPTION_FILE_PATH));
          a(String.valueOf(a1.m), p2Constants.getPath(p2Constants.EXCITATION_VOLTAGE_OPTION_FILE_PATH));
          a(String.valueOf(a1.n), p2Constants.getPath(p2Constants.C2V_GAIN_OPTION_FILE_PATH));
        } 
        a(a1.o, p2Constants.getPath(p2Constants.DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH));
        a(String.valueOf(a1.p), p2Constants.getPath(p2Constants.PGA1_OPTION_FILE_PATH));
        a(String.valueOf(a1.q), p2Constants.getPath(p2Constants.PGA2_OPTION_FILE_PATH));
        if (a1.r) {
          this.O.b(i.fD.a(), 1L, k.fD.a(), j.fD.a());
        } else {
          this.O.b(i.fD.a(), 0L, k.fD.a(), j.fD.a());
        } 
        a(p2Enumerations.p2AppManagerState.CapCurrentRun);
        return a1;
      case 19:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.C = paramVarArgs[0];
        a1.a = p2Enumerations.p2AppManagerState.SampleIDBurn;
        return a1;
      case 20:
        a1 = new a(this, null);
        a1.a = p2Enumerations.p2AppManagerState.TempReading;
        return a1;
      case 21:
        a1 = new a(this, null);
        a1.a = p2Enumerations.p2AppManagerState.ASICRegistersReading;
        return a1;
      case 22:
        a1 = new a(this, null);
        a1.a = p2Enumerations.p2AppManagerState.SampleFoldersReading;
        return a1;
      case 23:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[8]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        a1.j = Double.parseDouble(paramVarArgs[1]);
        a1.l = Integer.parseInt(paramVarArgs[2]);
        a1.m = Double.parseDouble(paramVarArgs[3]);
        a1.n = Double.parseDouble(paramVarArgs[4]);
        a1.H = Double.parseDouble(paramVarArgs[5]);
        a1.I = Double.parseDouble(paramVarArgs[6]);
        a1.J = Double.parseDouble(paramVarArgs[7]);
        a1.K = Double.parseDouble(paramVarArgs[8]);
        a("Push-Pull", p2Constants.getPath(p2Constants.ACTUATION_DIRECTION_OPTION_FILE_PATH));
        a("Sine", p2Constants.getPath(p2Constants.WAVEFORM_OPTION_FILE_PATH));
        a1.g = (int)a1.ac * c.z;
        a1.a = p2Enumerations.p2AppManagerState.ResponseCalculation;
        l1 = Math.round((a1.j * Math.pow(2.0D, k.cF.a()) - 1.0D) / 100.0D);
        this.O.b(i.cF.a(), l1, k.cF.a(), j.cF.a());
        a1.b = a1.I;
        l2 = (long)(a1.b * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
        this.O.b(i.cD.a(), l2, k.cD.a(), j.cD.a());
        a(String.valueOf(a1.l), p2Constants.getPath(p2Constants.SAMPLING_RATE_OPTION_FILE_PATH));
        a(String.valueOf(a1.m), p2Constants.getPath(p2Constants.EXCITATION_VOLTAGE_OPTION_FILE_PATH));
        a(String.valueOf(a1.n), p2Constants.getPath(p2Constants.C2V_GAIN_OPTION_FILE_PATH));
        a(p2Enumerations.p2AppManagerState.ResponseCalculation);
        return a1;
      case 24:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[8]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[0]);
        this.A = a1.ac;
        a1.j = Double.parseDouble(paramVarArgs[1]);
        a1.l = Integer.parseInt(paramVarArgs[2]);
        a1.m = Double.parseDouble(paramVarArgs[3]);
        this.B = a1.m;
        a1.n = Double.parseDouble(paramVarArgs[4]);
        a1.H = Double.parseDouble(paramVarArgs[5]);
        a1.I = Double.parseDouble(paramVarArgs[6]);
        a1.J = Double.parseDouble(paramVarArgs[7]);
        a1.K = Double.parseDouble(paramVarArgs[8]);
        a1.g = (int)a1.ac * c.z;
        a1.a = p2Enumerations.p2AppManagerState.ParametersCalculation;
        a("Push-Pull", p2Constants.getPath(p2Constants.ACTUATION_DIRECTION_OPTION_FILE_PATH));
        a("Sine", p2Constants.getPath(p2Constants.WAVEFORM_OPTION_FILE_PATH));
        this.O.b(i.cH.a(), 3L, k.cH.a(), j.cH.a());
        this.O.b(i.cJ.a(), 1L, k.cJ.a(), j.cJ.a());
        this.O.b(i.cY.a(), 0L, k.cY.a(), j.cY.a());
        l3 = Math.round((a1.j * Math.pow(2.0D, k.cF.a()) - 1.0D) / 100.0D);
        this.O.b(i.cF.a(), l3, k.cF.a(), j.cF.a());
        a1.b = 10.0D;
        l4 = (long)(a1.b * Math.pow(2.0D, 14.0D) / 50.0D * Math.pow(10.0D, 3.0D));
        this.O.b(i.cD.a(), l4, k.cD.a(), j.cD.a());
        a(String.valueOf(a1.l), p2Constants.getPath(p2Constants.SAMPLING_RATE_OPTION_FILE_PATH));
        a(String.valueOf(a1.m), p2Constants.getPath(p2Constants.EXCITATION_VOLTAGE_OPTION_FILE_PATH));
        a(String.valueOf(a1.n), p2Constants.getPath(p2Constants.C2V_GAIN_OPTION_FILE_PATH));
        a(p2Enumerations.p2AppManagerState.ParametersCalculation);
        return a1;
      case 25:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]) || p2AppManagerUtils.isEmptyString(paramVarArgs[8]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        System.out.println("Started coefficients trimming");
        a1 = new a(this, null);
        a1.L = Double.parseDouble(paramVarArgs[0]);
        a1.M = Double.parseDouble(paramVarArgs[1]);
        a1.N = Double.parseDouble(paramVarArgs[2]);
        a1.O = Double.parseDouble(paramVarArgs[3]);
        a1.P = Double.parseDouble(paramVarArgs[4]);
        a1.Q = Double.parseDouble(paramVarArgs[5]);
        a1.R = Double.parseDouble(paramVarArgs[6]);
        a1.ac = Double.parseDouble(paramVarArgs[7]);
        a1.m = Double.parseDouble(paramVarArgs[8]);
        this.A = a1.ac;
        this.B = a1.m;
        a1.a = p2Enumerations.p2AppManagerState.CoefficientsTrimming;
        a(p2Enumerations.p2AppManagerState.CoefficientsTrimming);
        return a1;
      case 26:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = this.A;
        System.out.println("Started phase trimming Run time of TrimPhase = " + this.A);
        a1.g = (int)a1.ac * c.z;
        a1.L = Double.parseDouble(paramVarArgs[0]);
        a1.M = Double.parseDouble(paramVarArgs[1]);
        a1.N = Double.parseDouble(paramVarArgs[2]);
        a1.O = Double.parseDouble(paramVarArgs[3]);
        a1.P = Double.parseDouble(paramVarArgs[4]);
        a1.Q = Double.parseDouble(paramVarArgs[5]);
        a1.R = Double.parseDouble(paramVarArgs[6]);
        a1.a = p2Enumerations.p2AppManagerState.PhaseTrimming;
        l5 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
        a1.b = l5 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
        a(p2Enumerations.p2AppManagerState.PhaseTrimming);
        return a1;
      case 27:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]) || p2AppManagerUtils.isEmptyString(paramVarArgs[1]) || p2AppManagerUtils.isEmptyString(paramVarArgs[2]) || p2AppManagerUtils.isEmptyString(paramVarArgs[3]) || p2AppManagerUtils.isEmptyString(paramVarArgs[4]) || p2AppManagerUtils.isEmptyString(paramVarArgs[5]) || p2AppManagerUtils.isEmptyString(paramVarArgs[6]) || p2AppManagerUtils.isEmptyString(paramVarArgs[7]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = this.A;
        System.out.println("Started fast phase trimming Run time of TrimPhaseFast = " + this.A);
        a1.g = (int)a1.ac * c.z;
        a1.L = Double.parseDouble(paramVarArgs[0]);
        a1.M = Double.parseDouble(paramVarArgs[1]);
        a1.N = Double.parseDouble(paramVarArgs[2]);
        a1.O = Double.parseDouble(paramVarArgs[3]);
        a1.S = Double.parseDouble(paramVarArgs[4]);
        a1.T = Double.parseDouble(paramVarArgs[5]);
        a1.U = Double.parseDouble(paramVarArgs[6]);
        a1.R = Double.parseDouble(paramVarArgs[7]);
        a1.a = p2Enumerations.p2AppManagerState.FastPhaseTrimming;
        l6 = this.O.b(i.cD.a(), k.cD.a(), j.cD.a());
        a1.b = l6 * 50.0D * Math.pow(10.0D, 3.0D) / Math.pow(2.0D, 14.0D);
        a(p2Enumerations.p2AppManagerState.FastPhaseTrimming);
        return a1;
      case 28:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        System.out.println("Started stability checking");
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[1]);
        a1.g = (int)a1.ac * c.z;
        a1.L = Double.parseDouble(paramVarArgs[2]);
        a1.V = Double.parseDouble(paramVarArgs[0]);
        a1.m = Double.parseDouble(paramVarArgs[3]);
        a1.a = p2Enumerations.p2AppManagerState.StabilityCheck;
        a(p2Enumerations.p2AppManagerState.StabilityCheck);
        return a1;
      case 29:
        if (p2AppManagerUtils.isEmptyString(paramVarArgs[0]))
          throw new p2AppManagerException("Invalid Parameters. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR.getNumVal()); 
        a1 = new a(this, null);
        a1.ac = Double.parseDouble(paramVarArgs[1]);
        a1.g = (int)a1.ac * c.z;
        a1.W = Integer.parseInt(paramVarArgs[0]);
        a1.m = Double.parseDouble(paramVarArgs[2]);
        a1.a = p2Enumerations.p2AppManagerState.WaveformPreview;
        a(p2Enumerations.p2AppManagerState.WaveformPreview);
        return a1;
    } 
    return null;
  }
  
  private void a(p2Enumerations.p2DeviceAction paramp2DeviceAction, double[][] paramArrayOfDouble, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    a(paramp2DeviceAction, paramArrayOfDouble);
    a(p2Enumerations.p2AppManagerState.Idle);
    p2DeviceNotificationResult p2DeviceNotificationResult = a(paramp2DeviceAction, paramp2AppManagerStatus);
    setChanged();
    notifyObservers(p2DeviceNotificationResult);
  }
  
  private void a(p2Enumerations.p2DeviceAction paramp2DeviceAction, double[][] paramArrayOfDouble) {
    switch (null.a[paramp2DeviceAction.ordinal()]) {
      case 30:
        this.r = (double[][])null;
        break;
      case 1:
        this.k = paramArrayOfDouble;
        break;
      case 2:
        this.k = paramArrayOfDouble;
        break;
      case 3:
        this.e = paramArrayOfDouble;
        break;
      case 4:
        this.f = paramArrayOfDouble;
        break;
      case 5:
        this.e = paramArrayOfDouble;
        break;
      case 6:
        this.g = paramArrayOfDouble;
        break;
      case 8:
        this.h = paramArrayOfDouble;
        break;
      case 9:
        this.i = paramArrayOfDouble;
        break;
      case 10:
        this.j = paramArrayOfDouble;
        break;
      case 11:
        this.l = paramArrayOfDouble;
        break;
      case 12:
        this.m = paramArrayOfDouble;
        break;
      case 14:
        this.n = paramArrayOfDouble;
        break;
      case 17:
        this.o = paramArrayOfDouble;
        break;
      case 18:
        this.p = paramArrayOfDouble;
        break;
      case 20:
        this.q = paramArrayOfDouble;
        break;
      case 23:
        this.r = paramArrayOfDouble;
        break;
      case 24:
        this.s = paramArrayOfDouble;
        break;
      case 25:
        this.t = paramArrayOfDouble;
        break;
      case 26:
      case 27:
        this.u = paramArrayOfDouble;
        break;
      case 28:
        this.v = paramArrayOfDouble;
        break;
      case 29:
        this.w = paramArrayOfDouble;
        break;
      case 13:
        this.k = paramArrayOfDouble;
        if (paramArrayOfDouble != null)
          a(paramArrayOfDouble[4], new String[] { this.c, this.G }); 
        break;
    } 
  }
  
  public static void a(double[] paramArrayOfDouble, String... paramVarArgs) {
    String[] arrayOfString = null;
    String str1 = paramVarArgs[0];
    String str2 = paramVarArgs[1];
    try {
      if (!str1.equals("")) {
        String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { str1 + File.separatorChar + str2 + File.separatorChar });
        File file = new File(str);
        File[] arrayOfFile = file.listFiles(new FileFilter() {
              public boolean accept(File param1File) { return (param1File.isDirectory() && !param1File.getName().equals(".svn")); }
            });
        arrayOfString = new String[arrayOfFile.length];
        for (byte b1 = 0; b1 < arrayOfFile.length; b1++)
          arrayOfString[b1] = arrayOfFile[b1].getName(); 
      } 
      if (arrayOfString != null)
        for (String str : arrayOfString) {
          p2AppManagerUtils.writeFileOfArray(paramArrayOfDouble, p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { str1, str2 + File.separatorChar + str, "corr.cal" }), "\n");
        }  
    } catch (Exception exception) {
      b.error(exception.getMessage());
    } 
  }
  
  private p2DeviceNotificationResult a(p2Enumerations.p2DeviceAction paramp2DeviceAction, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    p2DeviceNotificationResult p2DeviceNotificationResult = new p2DeviceNotificationResult();
    p2DeviceNotificationResult.setAction(paramp2DeviceAction);
    p2DeviceNotificationResult.setDeviceId(this.c);
    p2DeviceNotificationResult.setStatus(paramp2AppManagerStatus);
    return p2DeviceNotificationResult;
  }
  
  private String a(String paramString) {
    b.info("selectProfileBasedOnTemp function started");
    String[] arrayOfString = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), new ArrayList(), false);
    if (arrayOfString == null || arrayOfString.length == 0)
      throw new p2AppManagerException("No configuration foldres for this sample : " + this.c, p2Enumerations.p2AppManagerStatus.NO_SAMPLE_CONFIG_FOLDERS_ERROR.getNumVal()); 
    TreeMap treeMap = new TreeMap();
    for (String str : arrayOfString) {
      if (!str.equals(".svn")) {
        Double double = Double.valueOf(this.C.a(this.c, str + File.separatorChar + paramString));
        if (double != null)
          treeMap.put(double, str); 
      } 
    } 
    if (treeMap.size() == 0)
      throw new p2AppManagerException("Failed to load all sample configuration floders for this sample : " + this.c, p2Enumerations.p2AppManagerStatus.NO_VALID_SAMPLE_CONFIG_FOLDERS_ERROR.getNumVal()); 
    if (treeMap.size() == 1)
      return (String)treeMap.get(treeMap.keySet().toArray()[0]); 
    Map map = a(treeMap, paramString);
    long l1 = z();
    Iterator iterator = map.keySet().iterator();
    while (iterator.hasNext()) {
      long l2 = ((Long)iterator.next()).longValue();
      if (l1 <= l2) {
        b.info("selectProfileBasedOnTemp function finished");
        return (String)treeMap.get(map.get(Long.valueOf(l2)));
      } 
    } 
    throw new p2AppManagerException("No Sample Profile matched with current temp  : " + this.c, p2Enumerations.p2AppManagerStatus.NO_SAMPLE_PROFILE_SELECTED_ERROR.getNumVal());
  }
  
  private Map<Long, Double> a(Map<Double, String> paramMap, String paramString) {
    b.info("getTempBoundaries function started");
    HashMap hashMap = new HashMap();
    paramMap.put(Double.valueOf(1.34217727E8D), "");
    Double[] arrayOfDouble = (Double[])paramMap.keySet().toArray(new Double[paramMap.size()]);
    boolean bool = (this.E != null) ? 1 : 0;
    for (byte b1 = 0; b1 < arrayOfDouble.length - 1; b1++) {
      long l1 = (long)((arrayOfDouble[b1].doubleValue() + arrayOfDouble[b1 + true].doubleValue()) / 2.0D);
      if (bool)
        if (this.E.equals((String)paramMap.get(arrayOfDouble[b1]) + File.separatorChar + paramString)) {
          l1 += 20L;
        } else if (this.E.equals((String)paramMap.get(arrayOfDouble[b1 + true]) + File.separatorChar + paramString)) {
          l1 -= 20L;
        }  
      hashMap.put(Long.valueOf(l1), arrayOfDouble[b1]);
    } 
    b.info("getTempBoundaries function finished");
    return hashMap;
  }
  
  private long z() {
    b.info("getBoardTemperature function started");
    long l1 = -1L;
    try {
      l1 = this.O.d();
    } catch (Exception exception) {
      b.error(exception.getMessage());
    } 
    b.info("getBoardTemperature function finished");
    return l1;
  }
  
  private void A() {
    short s1 = a(65408, 1).getShort(0);
    if (s1 == 1 || s1 == 0) {
      a(true);
    } else if (s1 == 2) {
      a(false);
    } 
  }
  
  private void B() {
    String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c });
    p2AppManagerUtils.removeDir(str, true);
    a(true);
    F();
  }
  
  private void C() {
    String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c });
    File file = new File(str);
    if (file.exists())
      file.delete(); 
    b(false);
  }
  
  private String[] D() {
    short s1 = 0;
    ArrayList arrayList = new ArrayList();
    String[] arrayOfString = new String[1];
    if (a(s1, 1).getShort(0) == 1) {
      s1 = ++s1 + a(s1, 1).getShort(0);
      short s3 = a(++s1, 1).getShort(0);
      s1++;
      if (s3 >= 16) {
        short s4 = a(s1, 2).getShort(0);
        s1 += 2;
        s1 += s4;
      } else {
        s1 += a(s1, 1).getShort(0);
        s1++;
      } 
    } else {
      s1++;
    } 
    short s2 = a(s1, 1).getShort(0);
    s1++;
    for (byte b1 = 0; b1 < s2; b1++) {
      s1 += a(s1, 1).getShort(0);
      short s3 = a(++s1, 1).getShort(0);
      s1++;
      for (byte b2 = 0; b2 < s3; b2++) {
        short s4 = a(s1, 1).getShort(0);
        arrayList.add(new String(a(++s1, s4).array()));
        s1 += s4;
        short s5 = a(s1, 1).getShort(0);
        s1++;
        for (byte b3 = 0; b3 < s5; b3++) {
          s1 += a(s1, 1).getShort(0);
          short s6 = a(++s1, 1).getShort(0);
          s1++;
          if (s6 >= 16) {
            short s7 = a(s1, 2).getShort(0);
            s1 += 2;
            s1 += s7;
          } else {
            s1 += a(s1, 1).getShort(0);
            s1++;
          } 
        } 
      } 
    } 
    return (String[])arrayList.toArray(arrayOfString);
  }
  
  private int E() {
    short s1 = 0;
    if (a(s1, 1).getShort(0) == 1) {
      s1 = ++s1 + a(s1, 1).getShort(0);
      short s3 = a(++s1, 1).getShort(0);
      s1++;
      if (s3 >= 16) {
        short s4 = a(s1, 2).getShort(0);
        s1 += 2;
        s1 += s4;
      } else {
        s1 += a(s1, 1).getShort(0);
        s1++;
      } 
    } else {
      s1++;
    } 
    short s2 = a(s1, 1).getShort(0);
    s1++;
    for (byte b1 = 0; b1 < s2; b1++) {
      s1 += a(s1, 1).getShort(0);
      short s3 = a(++s1, 1).getShort(0);
      s1++;
      for (byte b2 = 0; b2 < s3; b2++) {
        s1 += a(s1, 1).getShort(0);
        short s4 = a(++s1, 1).getShort(0);
        s1++;
        for (byte b3 = 0; b3 < s4; b3++) {
          s1 += a(s1, 1).getShort(0);
          short s5 = a(++s1, 1).getShort(0);
          s1++;
          if (s5 >= 16) {
            short s6 = a(s1, 2).getShort(0);
            s1 += 2;
            s1 += s6;
          } else {
            s1 += a(s1, 1).getShort(0);
            s1++;
          } 
        } 
      } 
    } 
    getClass();
    if ((s1 & 0x1F) != 0) {
      getClass();
      s1 &= (0x1F ^ 0xFFFFFFFF);
      s1 += 32;
    } 
    return s1;
  }
  
  private void a(boolean paramBoolean) throws p2AppManagerException {
    try {
      boolean bool1 = false;
      boolean bool2 = false;
      short s1 = 0;
      short s2 = 0;
      byte[] arrayOfByte1 = { 0 };
      byte[] arrayOfByte2 = { 0, 0 };
      short s3 = 0;
      ArrayList arrayList1 = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      ArrayList arrayList3 = new ArrayList();
      ArrayList arrayList4 = new ArrayList();
      ArrayList arrayList5 = new ArrayList();
      if (p2AppManagerUtils.isEmptyString(this.c))
        throw new p2AppManagerException("Invalid sampleID. Error: ", p2Enumerations.p2AppManagerStatus.SAMPLE_ID_INVALID_ERROR.getNumVal()); 
      String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c });
      p2AppManagerUtils.createDir(str);
      if (!p2AppManagerUtils.exist(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c }))) {
        bool2 = false;
        arrayList1.add(new Boolean(false));
      } else {
        bool2 = true;
        arrayList1.add(new Boolean(true));
      } 
      short s4 = a(s3, 1).getShort(0);
      s3++;
      if (s4 == 1) {
        short s5 = a(s3, 1).getShort(0);
        String str1 = new String(a(++s3, s5).array());
        s3 += s5;
        if (!str1.equals("savedOpticalSettings.txt"))
          b.error("Optical gain settings file name is not common!"); 
        arrayOfByte1 = a(s3, 1).array();
        boolean bool = false;
        short s6 = a(s3, 1).getShort(0);
        s3++;
        if (s6 >= 16) {
          arrayOfByte1[0] = (byte)(arrayOfByte1[0] - 16);
          bool = true;
        } 
        arrayOfByte2 = new byte[2];
        arrayOfByte2[0] = arrayOfByte1[0];
        arrayOfByte2[1] = 0;
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte2);
        byteBuffer.order(ByteOrder.nativeOrder());
        short s7 = byteBuffer.getShort(0);
        short s8 = 0;
        if (bool) {
          s8 = a(s3, 2).getShort(0);
          s3 += 2;
        } else {
          s8 = a(s3, 1).getShort(0);
          s3++;
        } 
        if (!bool2)
          arrayOfByte1 = a(s3, s8).array(); 
        s3 += s8;
        if (!bool2)
          if (s7 == 2) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(new String(arrayOfByte1));
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c })));
            bufferedWriter.write((String)arrayList.get(0));
            bufferedWriter.close();
          } else {
            b.error("Wrong optical data data type!");
          }  
      } 
      s1 = a(s3, 1).getShort(0);
      s3++;
      for (byte b1 = 0; b1 < s1; b1++) {
        short s5 = a(s3, 1).getShort(0);
        arrayList2.add(new String(a(++s3, s5).array()));
        s3 += s5;
        arrayList3.add(new ArrayList());
        arrayList4.add(new ArrayList());
        arrayList5.add(new ArrayList());
        s2 = a(s3, 1).getShort(0);
        if (s1 * s2 > 8)
          throw new p2AppManagerException("Invalid number of profiles. Error: ", p2Enumerations.p2AppManagerStatus.SAMPLE_FOLDERS_NUMBER_ERROR.getNumVal()); 
        s3++;
        for (byte b2 = 0; b2 < s2; b2++) {
          s5 = a(s3, 1).getShort(0);
          arrayOfByte1 = a(++s3, s5).array();
          ((ArrayList)arrayList3.get(b1)).add(new String(arrayOfByte1));
          s3 += s5;
          ((ArrayList)arrayList4.get(b1)).add(new ArrayList());
          ((ArrayList)arrayList5.get(b1)).add(new ArrayList());
          str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList2.get(b1) + File.separatorChar + new String(arrayOfByte1) });
          if (!p2AppManagerUtils.exist(str)) {
            bool1 = false;
            arrayList1.add(new Boolean(false));
          } else {
            bool1 = true;
            arrayList1.add(new Boolean(true));
          } 
          short s6 = a(s3, 1).getShort(0);
          s3++;
          byte b3;
          for (b3 = 0; b3 < s6; b3++) {
            s5 = a(s3, 1).getShort(0);
            s3++;
            if (!bool1) {
              ((ArrayList)((ArrayList)arrayList4.get(b1)).get(b2)).add(new String(a(s3, s5).array()));
              ((ArrayList)((ArrayList)arrayList5.get(b1)).get(b2)).add(new ArrayList());
            } 
            s3 += s5;
            arrayOfByte1 = a(s3, 1).array();
            boolean bool = false;
            short s7 = a(s3, 1).getShort(0);
            s3++;
            if (s7 >= 16) {
              arrayOfByte1[0] = (byte)(arrayOfByte1[0] - 16);
              bool = true;
            } 
            arrayOfByte2 = new byte[2];
            arrayOfByte2[0] = arrayOfByte1[0];
            arrayOfByte2[1] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte2);
            byteBuffer.order(ByteOrder.nativeOrder());
            short s8 = byteBuffer.getShort(0);
            short s9 = 0;
            if (bool) {
              s9 = a(s3, 2).getShort(0);
              s3 += 2;
            } else {
              s9 = a(s3, 1).getShort(0);
              s3++;
            } 
            if (!bool1) {
              arrayOfByte1 = new byte[s9];
              try {
                arrayOfByte1 = this.O.b(s3, s9);
              } catch (Exception exception) {
                throw new p2AppManagerException("Invalid file contents. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_FILE_DATA_ERROR.getNumVal());
              } 
            } 
            s3 += s9;
            if (!bool1)
              if (s8 == 0) {
                byte b4;
                for (b4 = 0; b4 < s9; b4 += 8) {
                  byteBuffer = ByteBuffer.wrap(arrayOfByte1);
                  byteBuffer.order(ByteOrder.nativeOrder());
                  ((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b2)).get(b3)).add(String.valueOf(byteBuffer.getDouble(b4)));
                } 
              } else if (s8 == 1) {
                byte b4;
                for (b4 = 0; b4 < s9; b4 += 4) {
                  byteBuffer = ByteBuffer.wrap(arrayOfByte1);
                  byteBuffer.order(ByteOrder.nativeOrder());
                  ((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b2)).get(b3)).add(String.valueOf(byteBuffer.getInt(b4)));
                } 
              } else if (s8 == 2) {
                ((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b2)).get(b3)).add(new String(arrayOfByte1));
              } else if (s8 == 3) {
                byte b4;
                for (b4 = 0; b4 < s9; b4 += 4) {
                  byteBuffer = ByteBuffer.wrap(arrayOfByte1);
                  byteBuffer.order(ByteOrder.nativeOrder());
                  ((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b2)).get(b3)).add(String.valueOf(byteBuffer.getFloat(b4)));
                } 
              }  
          } 
          if (!bool1) {
            b3 = b2;
            str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList2.get(b1) + File.separatorChar + (String)((ArrayList)arrayList3.get(b1)).get(b3) });
            if (!p2AppManagerUtils.exist(str)) {
              p2AppManagerUtils.createDir(str);
            } else {
              File file = new File(str);
              file.delete();
              p2AppManagerUtils.createDir(str);
            } 
            for (byte b4 = 0; b4 < ((ArrayList)((ArrayList)arrayList4.get(b1)).get(b3)).size(); b4++) {
              BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList2.get(b1) + File.separatorChar + (String)((ArrayList)arrayList3.get(b1)).get(b3), ((ArrayList)((ArrayList)arrayList4.get(b1)).get(b3)).get(b4) })));
              if (((String)((ArrayList)((ArrayList)arrayList4.get(b1)).get(b3)).get(b4)).equals("t.reg")) {
                bufferedWriter.write((String)((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b3)).get(b4)).get(0));
              } else if (((String)((ArrayList)((ArrayList)arrayList4.get(b1)).get(b3)).get(b4)).equals("param.conf")) {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(p2Constants.getPath(p2Constants.PARAM_HEADER_FIE_PATH)));
                ArrayList arrayList = new ArrayList();
                String str1;
                while ((str1 = bufferedReader.readLine()) != null)
                  arrayList.add(str1); 
                bufferedReader.close();
                for (byte b5 = 0; b5 < ((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b3)).get(b4)).size(); b5++)
                  bufferedWriter.write(((String)arrayList.get(b5)).split(":")[0] + " : " + (String)((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b3)).get(b4)).get(b5) + "\n"); 
              } else {
                for (byte b5 = 0; b5 < ((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b3)).get(b4)).size(); b5++)
                  bufferedWriter.write((String)((ArrayList)((ArrayList)((ArrayList)arrayList5.get(b1)).get(b3)).get(b4)).get(b5) + "\n"); 
              } 
              bufferedWriter.close();
            } 
          } 
        } 
      } 
      if (!paramBoolean)
        a(arrayList1); 
    } catch (Exception exception) {
      b.error(exception.getMessage());
      throw new p2AppManagerException("Exception occurred while reading profiles from ROM. Error: ", p2Enumerations.p2AppManagerStatus.READING_PROFILES_FROM_ROM_ERROR.getNumVal());
    } 
  }
  
  private void b(boolean paramBoolean) throws p2AppManagerException {
    try {
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      boolean bool4 = false;
      byte[] arrayOfByte1 = { 0 };
      byte[] arrayOfByte2 = { 0, 0 };
      int i1 = 0;
      ArrayList arrayList1 = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      ArrayList arrayList3 = new ArrayList();
      ArrayList arrayList4 = new ArrayList();
      ArrayList arrayList5 = new ArrayList();
      if (p2AppManagerUtils.isEmptyString(this.c))
        throw new p2AppManagerException("Invalid sampleID. Error: ", p2Enumerations.p2AppManagerStatus.SAMPLE_ID_INVALID_ERROR.getNumVal()); 
      short s1 = a(i1, 1).getShort(0);
      i1++;
      if (s1 == 1) {
        short s2 = a(i1, 1).getShort(0);
        String str = new String(a(++i1, s2).array());
        i1 += s2;
        if (!str.equals("savedOpticalSettings.txt"))
          b.error("Optical gain settings file name is not common!"); 
        arrayOfByte1 = a(i1, 1).array();
        boolean bool = false;
        short s3 = a(i1, 1).getShort(0);
        i1++;
        if (s3 >= 16) {
          arrayOfByte1[0] = (byte)(arrayOfByte1[0] - 16);
          bool = true;
        } 
        arrayOfByte2 = new byte[2];
        arrayOfByte2[0] = arrayOfByte1[0];
        arrayOfByte2[1] = 0;
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte2);
        byteBuffer.order(ByteOrder.nativeOrder());
        short s4 = byteBuffer.getShort(0);
        short s5 = 0;
        if (bool) {
          s5 = a(i1, 2).getShort(0);
          i1 += 2;
        } else {
          s5 = a(i1, 1).getShort(0);
          i1++;
        } 
        if (!bool2)
          arrayOfByte1 = a(i1, s5).array(); 
        i1 += s5;
        if (!bool2)
          if (s4 == 2) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(new String(arrayOfByte1));
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c })));
            bufferedWriter.write((String)arrayList.get(0));
            bufferedWriter.close();
          } else {
            b.error("Wrong optical data data type!");
          }  
      } 
      if (!paramBoolean) {
        i1 = E();
        boolean bool = false;
        s1 = a(i1, 1).getShort(0);
        i1++;
        if (s1 == 1) {
          short s2 = a(i1, 1).getShort(0);
          String str = new String(a(++i1, s2).array());
          i1 += s2;
          if (!str.equals("savedOpticalSettings.txt"))
            b.error("Optical gain settings file name is not common!"); 
          arrayOfByte1 = a(i1, 1).array();
          boolean bool5 = false;
          short s3 = a(i1, 1).getShort(0);
          i1++;
          if (s3 >= 16) {
            arrayOfByte1[0] = (byte)(arrayOfByte1[0] - 16);
            bool5 = true;
          } 
          arrayOfByte2 = new byte[2];
          arrayOfByte2[0] = arrayOfByte1[0];
          arrayOfByte2[1] = 0;
          ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte2);
          byteBuffer.order(ByteOrder.nativeOrder());
          short s4 = byteBuffer.getShort(0);
          int i2 = 0;
          if (bool5) {
            i2 = a(i1, 2).getShort(0);
            i1 += 2;
          } else {
            i2 = a(i1, 1).getShort(0);
            i1++;
          } 
          arrayOfByte1 = a(i1, i2).array();
          i1 += i2;
          if (s4 == 2) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(new String(arrayOfByte1));
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c })));
            bufferedWriter.write((String)arrayList.get(0));
            bufferedWriter.close();
          } else {
            b.error("Wrong optical data data type!");
          } 
        } 
      } 
    } catch (Exception exception) {
      b.error(exception.getMessage());
      throw new p2AppManagerException("Exception occurred while reading profiles from ROM. Error: ", p2Enumerations.p2AppManagerStatus.READING_PROFILES_FROM_ROM_ERROR.getNumVal());
    } 
  }
  
  private void a(ArrayList<Boolean> paramArrayList) throws p2AppManagerException {
    try {
      short s1 = 0;
      short s2 = 0;
      byte[] arrayOfByte = { 0 };
      int i1 = E();
      byte b1 = 0;
      ArrayList arrayList1 = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      ArrayList arrayList3 = new ArrayList();
      ArrayList arrayList4 = new ArrayList();
      short s3 = a(i1, 1).getShort(0);
      i1++;
      if (s3 == 1) {
        short s4 = a(i1, 1).getShort(0);
        String str = new String(a(++i1, s4).array());
        i1 += s4;
        if (!str.equals("savedOpticalSettings.txt"))
          b.error("Optical gain settings file name is not common!"); 
        arrayOfByte = a(i1, 1).array();
        boolean bool = false;
        short s5 = a(i1, 1).getShort(0);
        i1++;
        if (s5 >= 16) {
          arrayOfByte[0] = (byte)(arrayOfByte[0] - 16);
          bool = true;
        } 
        byte[] arrayOfByte1 = new byte[2];
        arrayOfByte1[0] = arrayOfByte[0];
        arrayOfByte1[1] = 0;
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte1);
        byteBuffer.order(ByteOrder.nativeOrder());
        short s6 = byteBuffer.getShort(0);
        int i2 = 0;
        if (bool) {
          i2 = a(i1, 2).getShort(0);
          i1 += 2;
        } else {
          i2 = a(i1, 1).getShort(0);
          i1++;
        } 
        arrayOfByte = a(i1, i2).array();
        i1 += i2;
        if (s6 == 2) {
          ArrayList arrayList = new ArrayList();
          arrayList.add(new String(arrayOfByte));
          if (((Boolean)paramArrayList.get(b1)).equals(new Boolean(false))) {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c })));
            bufferedWriter.write((String)arrayList.get(0));
            bufferedWriter.close();
          } 
          b1++;
        } else {
          b.error("Wrong optical data data type!");
        } 
      } 
      s1 = a(i1, 1).getShort(0);
      i1++;
      for (byte b2 = 0; b2 < s1; b2++) {
        short s4 = a(i1, 1).getShort(0);
        arrayList1.add(new String(a(++i1, s4).array()));
        i1 += s4;
        arrayList2.add(new ArrayList());
        arrayList3.add(new ArrayList());
        arrayList4.add(new ArrayList());
        s2 = a(i1, 1).getShort(0);
        if (s1 * s2 > 8)
          throw new p2AppManagerException("Invalid number of profiles. Error: ", p2Enumerations.p2AppManagerStatus.SAMPLE_FOLDERS_NUMBER_ERROR.getNumVal()); 
        i1++;
        for (byte b3 = 0; b3 < s2; b3++) {
          s4 = a(i1, 1).getShort(0);
          ((ArrayList)arrayList2.get(b2)).add(new String(a(++i1, s4).array()));
          i1 += s4;
          ((ArrayList)arrayList3.get(b2)).add(new ArrayList());
          ((ArrayList)arrayList4.get(b2)).add(new ArrayList());
          short s5 = a(i1, 1).getShort(0);
          i1++;
          byte b4;
          for (b4 = 0; b4 < s5; b4++) {
            s4 = a(i1, 1).getShort(0);
            ((ArrayList)((ArrayList)arrayList3.get(b2)).get(b3)).add(new String(a(++i1, s4).array()));
            ((ArrayList)((ArrayList)arrayList4.get(b2)).get(b3)).add(new ArrayList());
            i1 += s4;
            arrayOfByte = a(i1, 1).array();
            boolean bool = false;
            short s6 = a(i1, 1).getShort(0);
            i1++;
            if (s6 >= 16) {
              arrayOfByte[0] = (byte)(arrayOfByte[0] - 16);
              bool = true;
            } 
            byte[] arrayOfByte1 = new byte[2];
            arrayOfByte1[0] = arrayOfByte[0];
            arrayOfByte1[1] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte1);
            byteBuffer.order(ByteOrder.nativeOrder());
            short s7 = byteBuffer.getShort(0);
            int i2 = 0;
            if (bool) {
              i2 = a(i1, 2).getShort(0);
              i1 += 2;
            } else {
              i2 = a(i1, 1).getShort(0);
              i1++;
            } 
            try {
              arrayOfByte = a(i1, i2).array();
            } catch (Exception exception) {
              throw new p2AppManagerException("Invalid file contents. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_FILE_DATA_ERROR.getNumVal());
            } 
            i1 += i2;
            if (s7 == 0) {
              byte b5;
              for (b5 = 0; b5 < i2; b5 += 8) {
                byteBuffer = ByteBuffer.wrap(arrayOfByte);
                byteBuffer.order(ByteOrder.nativeOrder());
                ((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b3)).get(b4)).add(String.valueOf(byteBuffer.getDouble(b5)));
              } 
            } else if (s7 == 1) {
              byte b5;
              for (b5 = 0; b5 < i2; b5 += 4) {
                byteBuffer = ByteBuffer.wrap(arrayOfByte);
                byteBuffer.order(ByteOrder.nativeOrder());
                ((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b3)).get(b4)).add(String.valueOf(byteBuffer.getInt(b5)));
              } 
            } else if (s7 == 2) {
              ((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b3)).get(b4)).add(new String(arrayOfByte));
            } else if (s7 == 3) {
              byte b5;
              for (b5 = 0; b5 < i2; b5 += 4) {
                byteBuffer = ByteBuffer.wrap(arrayOfByte);
                byteBuffer.order(ByteOrder.nativeOrder());
                ((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b3)).get(b4)).add(String.valueOf(byteBuffer.getFloat(b5)));
              } 
            } 
          } 
          if (((Boolean)paramArrayList.get(b1)).equals(new Boolean(false))) {
            b4 = b3;
            String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList1.get(b2) + File.separatorChar + (String)((ArrayList)arrayList2.get(b2)).get(b4) });
            if (!p2AppManagerUtils.exist(str)) {
              p2AppManagerUtils.createDir(str);
            } else {
              File file = new File(str);
              file.delete();
              p2AppManagerUtils.createDir(str);
            } 
            for (byte b5 = 0; b5 < ((ArrayList)((ArrayList)arrayList3.get(b2)).get(b4)).size(); b5++) {
              BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE)), new Object[] { this.c, (String)arrayList1.get(b2) + File.separatorChar + (String)((ArrayList)arrayList2.get(b2)).get(b4), ((ArrayList)((ArrayList)arrayList3.get(b2)).get(b4)).get(b5) })));
              if (((String)((ArrayList)((ArrayList)arrayList3.get(b2)).get(b4)).get(b5)).equals("t.reg")) {
                bufferedWriter.write((String)((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b4)).get(b5)).get(0));
              } else if (((String)((ArrayList)((ArrayList)arrayList3.get(b2)).get(b4)).get(b5)).equals("param.conf")) {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(p2Constants.getPath(p2Constants.PARAM_HEADER_FIE_PATH)));
                ArrayList arrayList = new ArrayList();
                String str1;
                while ((str1 = bufferedReader.readLine()) != null)
                  arrayList.add(str1); 
                bufferedReader.close();
                for (byte b6 = 0; b6 < ((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b4)).get(b5)).size(); b6++)
                  bufferedWriter.write(((String)arrayList.get(b6)).split(":")[0] + " : " + (String)((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b4)).get(b5)).get(b6) + "\n"); 
              } else {
                for (byte b6 = 0; b6 < ((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b4)).get(b5)).size(); b6++)
                  bufferedWriter.write((String)((ArrayList)((ArrayList)((ArrayList)arrayList4.get(b2)).get(b4)).get(b5)).get(b6) + "\n"); 
              } 
              bufferedWriter.close();
            } 
          } 
          b1++;
        } 
      } 
    } catch (Exception exception) {
      b.error(exception.getMessage());
      throw new p2AppManagerException("Exception occurred while reading profiles from ROM. Error: ", p2Enumerations.p2AppManagerStatus.READING_PROFILES_FROM_ROM_ERROR.getNumVal());
    } 
  }
  
  private void c(boolean paramBoolean) throws p2AppManagerException {
    if (paramBoolean) {
      G();
      return;
    } 
    ArrayList arrayList = new ArrayList();
    try {
      String[] arrayOfString1 = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), new ArrayList(), false);
      ArrayList arrayList1 = new ArrayList();
      for (String str : arrayOfString1) {
        if (!str.equals(".svn") && !str.contains(".txt"))
          arrayList1.add(str); 
      } 
      if (arrayList1.size() == 0)
        throw new p2AppManagerException("Invalid number of tempreture folders to be burnt. Error: ", p2Enumerations.p2AppManagerStatus.TEMP_FOLDERS_ERROR.getNumVal()); 
      ArrayList arrayList2 = new ArrayList();
      String[] arrayOfString2 = p2AppManagerUtils.getFolderSubFilesNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), arrayList2);
      if (arrayOfString2.length != 0) {
        arrayList.add(Byte.valueOf((byte)1));
        byte[] arrayOfByte3 = arrayOfString2[0].getBytes();
        arrayList.add(Byte.valueOf((byte)arrayOfByte3.length));
        for (byte b4 : arrayOfByte3)
          arrayList.add(Byte.valueOf(b4)); 
        String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP2_FILE_PATH), new Object[] { this.c }));
        StringBuilder stringBuilder = new StringBuilder();
        for (String str1 : arrayOfString)
          stringBuilder.append(str1 + "\n"); 
        String str = stringBuilder.toString();
        byte[] arrayOfByte4 = str.getBytes();
        boolean bool1 = false;
        if (arrayOfByte4.length <= 255) {
          arrayList.add(Byte.valueOf((byte)2));
        } else {
          arrayList.add(Byte.valueOf((byte)18));
          bool1 = true;
        } 
        byte[] arrayOfByte5 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte4.length).array();
        arrayList.add(Byte.valueOf(arrayOfByte5[0]));
        if (bool1)
          arrayList.add(Byte.valueOf(arrayOfByte5[1])); 
        for (byte b4 : arrayOfByte4)
          arrayList.add(Byte.valueOf(b4)); 
      } else {
        arrayList.add(Byte.valueOf((byte)0));
      } 
      short s1 = 0;
      short s2 = 0;
      byte[] arrayOfByte1 = { 0 };
      int i1 = E();
      boolean bool = false;
      ArrayList arrayList3 = new ArrayList();
      ArrayList arrayList4 = new ArrayList();
      ArrayList arrayList5 = new ArrayList();
      ArrayList arrayList6 = new ArrayList();
      short s3 = a(i1, 1).getShort(0);
      i1++;
      if (s3 == 1) {
        short s4 = a(i1, 1).getShort(0);
        String str = new String(a(++i1, s4).array());
        i1 += s4;
        if (!str.equals("savedOpticalSettings.txt"))
          b.error("Optical gain settings file name is not common!"); 
        arrayOfByte1 = a(i1, 1).array();
        boolean bool1 = false;
        short s5 = a(i1, 1).getShort(0);
        i1++;
        if (s5 >= 16) {
          arrayOfByte1[0] = (byte)(arrayOfByte1[0] - 16);
          bool1 = true;
        } 
        byte[] arrayOfByte = new byte[2];
        arrayOfByte[0] = arrayOfByte1[0];
        arrayOfByte[1] = 0;
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
        byteBuffer.order(ByteOrder.nativeOrder());
        short s6 = byteBuffer.getShort(0);
        int i4 = 0;
        if (bool1) {
          i4 = a(i1, 2).getShort(0);
          i1 += 2;
        } else {
          i4 = a(i1, 1).getShort(0);
          i1++;
        } 
        arrayOfByte1 = a(i1, i4).array();
        i1 += i4;
      } 
      int i2 = 0;
      int i3 = i1;
      s1 = a(i1, 1).getShort(0);
      i1++;
      i2++;
      for (byte b1 = 0; b1 < s1; b1++) {
        short s4 = a(i1, 1).getShort(0);
        i1++;
        i2++;
        arrayList3.add(new String(a(i1, s4).array()));
        i1 += s4;
        i2++;
        arrayList4.add(new ArrayList());
        arrayList5.add(new ArrayList());
        arrayList6.add(new ArrayList());
        s2 = a(i1, 1).getShort(0);
        if (s1 * s2 > 8)
          throw new p2AppManagerException("Invalid number of profiles. Error: ", p2Enumerations.p2AppManagerStatus.SAMPLE_FOLDERS_NUMBER_ERROR.getNumVal()); 
        i1++;
        i2++;
        for (byte b4 = 0; b4 < s2; b4++) {
          s4 = a(i1, 1).getShort(0);
          i1++;
          i2++;
          ((ArrayList)arrayList4.get(b1)).add(new String(a(i1, s4).array()));
          i1 += s4;
          ((ArrayList)arrayList5.get(b1)).add(new ArrayList());
          ((ArrayList)arrayList6.get(b1)).add(new ArrayList());
          short s5 = a(i1, 1).getShort(0);
          i1++;
          i2++;
          for (byte b5 = 0; b5 < s5; b5++) {
            s4 = a(i1, 1).getShort(0);
            i1++;
            i2++;
            ((ArrayList)((ArrayList)arrayList5.get(b1)).get(b4)).add(new String(a(i1, s4).array()));
            ((ArrayList)((ArrayList)arrayList6.get(b1)).get(b4)).add(new ArrayList());
            i1 += s4;
            i2 += s4;
            arrayOfByte1 = a(i1, 1).array();
            boolean bool1 = false;
            short s6 = a(i1, 1).getShort(0);
            i1++;
            i2++;
            if (s6 >= 16) {
              arrayOfByte1[0] = (byte)(arrayOfByte1[0] - 16);
              bool1 = true;
            } 
            byte[] arrayOfByte = new byte[2];
            arrayOfByte[0] = arrayOfByte1[0];
            arrayOfByte[1] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            short s7 = byteBuffer.getShort(0);
            int i4 = 0;
            if (bool1) {
              i4 = a(i1, 2).getShort(0);
              i1 += 2;
              i2 += 2;
            } else {
              i4 = a(i1, 1).getShort(0);
              i1++;
              i2++;
            } 
            try {
              arrayOfByte1 = a(i1, i4).array();
            } catch (Exception exception) {
              throw new p2AppManagerException("Invalid file contents. Error: ", p2Enumerations.p2AppManagerStatus.INVALID_FILE_DATA_ERROR.getNumVal());
            } 
            i1 += i4;
            i2 += i4;
          } 
        } 
      } 
      arrayOfByte1 = a(i3, i2).array();
      byte[] arrayOfByte2 = new byte[arrayOfByte1.length + arrayList.size()];
      byte b2;
      for (b2 = 0; b2 < arrayList.size(); b2++)
        arrayOfByte2[b2] = ((Byte)arrayList.get(b2)).byteValue(); 
      for (b3 = 0; b3 < arrayOfByte1.length; b3++)
        arrayOfByte2[b2] = arrayOfByte1[b3]; 
      i1 = E();
      if (arrayOfByte2.length + i1 < 65408)
        try {
          this.O.a(i1, arrayOfByte2.length, arrayOfByte2);
          arrayOfByte2 = new byte[1];
          arrayOfByte2[0] = 2;
          this.O.a(65408, arrayOfByte2.length, arrayOfByte2);
        } catch (Exception b3) {
          Exception exception;
          throw new p2AppManagerException("Exception occurred while writing data to ROM. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
        }  
    } catch (Exception exception) {
      b.error(exception.getMessage());
      throw new p2AppManagerException("Exception occurred while reading profiles from ROM. Error: ", p2Enumerations.p2AppManagerStatus.READING_PROFILES_FROM_ROM_ERROR.getNumVal());
    } 
  }
  
  public boolean b(String[] paramArrayOfString) {
    try {
      String str = p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c });
      ArrayList arrayList = new ArrayList();
      File file1 = new File(str);
      File file2 = new File(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP_FILE_PATH));
      if (file1.exists() && file2.exists()) {
        bufferedWriter = null;
        bufferedReader1 = null;
        bufferedReader2 = null;
        try {
          bufferedReader1 = new BufferedReader(new FileReader(str));
          bufferedReader2 = new BufferedReader(new FileReader(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP_FILE_PATH)));
          bufferedWriter = new BufferedWriter(new FileWriter(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP2_FILE_PATH)));
          str1 = null;
          String str2 = null;
          label49: while ((str2 = bufferedReader2.readLine()) != null) {
            if (a(str2, paramArrayOfString))
              while (true) {
                bufferedWriter.write(str2 + "\n");
                if (str2.startsWith(".end"))
                  continue label49; 
                if ((str2 = bufferedReader2.readLine()) == null)
                  continue label49; 
              }  
          } 
          while ((str1 = bufferedReader1.readLine()) != null) {
            if (a(str1, paramArrayOfString)) {
              do {
              
              } while ((str1 = bufferedReader1.readLine()) != null && !str1.startsWith(".end"));
              continue;
            } 
            bufferedWriter.write(str1 + "\n");
          } 
        } catch (Exception exception) {
          return false;
        } finally {
          try {
            bufferedReader1.close();
            bufferedReader2.close();
            bufferedWriter.close();
          } catch (Exception exception) {
            return false;
          } 
        } 
      } 
    } catch (Exception exception) {
      b.error(exception.getMessage());
      return false;
    } 
    return true;
  }
  
  public boolean a(String paramString, String[] paramArrayOfString) {
    for (byte b1 = 0; b1 < paramArrayOfString.length; b1++) {
      if (paramString.contains(paramArrayOfString[b1]))
        return true; 
    } 
    return false;
  }
  
  private void d(String[] paramArrayOfString) {
    try {
      if (paramArrayOfString == null) {
        byte[] arrayOfByte1 = { 0, 0 };
        try {
          this.O.a(0, 2, arrayOfByte1);
        } catch (Exception exception) {
          throw new p2AppManagerException("Writing 0 as the number of profiles failed. Error: ", p2Enumerations.p2AppManagerStatus.SAMPLE_FOLDERS_NUMBER_ERROR.getNumVal());
        } 
        byte[] arrayOfByte2 = { 0 };
        try {
          this.O.a(65408, 1, arrayOfByte2);
        } catch (Exception exception) {
          throw new p2AppManagerException("Writing 0 as the version of Conf. files failed. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
        } 
        return;
      } 
      ArrayList arrayList1 = new ArrayList();
      String[] arrayOfString1 = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), new ArrayList(), false);
      ArrayList arrayList2 = new ArrayList();
      String[] arrayOfString2 = p2AppManagerUtils.getFolderSubFilesNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), arrayList2);
      boolean bool = false;
      if (arrayOfString2.length != 0) {
        bool = true;
        arrayList1.add(Byte.valueOf((byte)1));
        byte[] arrayOfByte1 = arrayOfString2[0].getBytes();
        arrayList1.add(Byte.valueOf((byte)arrayOfByte1.length));
        for (byte b3 : arrayOfByte1)
          arrayList1.add(Byte.valueOf(b3)); 
        String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c }));
        StringBuilder stringBuilder = new StringBuilder();
        for (String str1 : arrayOfString)
          stringBuilder.append(str1 + "\n"); 
        String str = stringBuilder.toString();
        byte[] arrayOfByte2 = str.getBytes();
        boolean bool1 = false;
        if (arrayOfByte2.length <= 255) {
          arrayList1.add(Byte.valueOf((byte)2));
        } else {
          arrayList1.add(Byte.valueOf((byte)18));
          bool1 = true;
        } 
        byte[] arrayOfByte3 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte2.length).array();
        arrayList1.add(Byte.valueOf(arrayOfByte3[0]));
        if (bool1)
          arrayList1.add(Byte.valueOf(arrayOfByte3[1])); 
        for (byte b3 : arrayOfByte2)
          arrayList1.add(Byte.valueOf(b3)); 
      } 
      if (!bool)
        arrayList1.add(Byte.valueOf((byte)0)); 
      ArrayList arrayList3 = new ArrayList();
      for (String str : arrayOfString1) {
        if (!str.equals(".svn") && !str.contains(".txt"))
          arrayList3.add(str); 
      } 
      if (arrayList3.size() == 0)
        throw new p2AppManagerException("Invalid number of tempreture folders to be burnt. Error: ", p2Enumerations.p2AppManagerStatus.TEMP_FOLDERS_ERROR.getNumVal()); 
      if (arrayList3.size() * paramArrayOfString.length > 8)
        throw new p2AppManagerException("Invalid number of profiles to be burnt. Max is 8Profiles . Error: ", p2Enumerations.p2AppManagerStatus.SAMPLE_FOLDERS_NUMBER_ERROR.getNumVal()); 
      arrayList1.add(Byte.valueOf((byte)arrayList3.size()));
      for (byte b1 = 0; b1 < arrayList3.size(); b1++) {
        arrayList1.add(Byte.valueOf((byte)((String)arrayList3.get(b1)).getBytes().length));
        byte[] arrayOfByte1 = ((String)arrayList3.get(b1)).getBytes();
        for (byte b4 : arrayOfByte1)
          arrayList1.add(Byte.valueOf(b4)); 
        arrayList1.add(Byte.valueOf((byte)paramArrayOfString.length));
        for (byte b3 = 0; b3 < paramArrayOfString.length; b3++) {
          arrayList1.add(Byte.valueOf((byte)paramArrayOfString[b3].getBytes().length));
          arrayOfByte1 = paramArrayOfString[b3].getBytes();
          for (byte b5 : arrayOfByte1)
            arrayList1.add(Byte.valueOf(b5)); 
          ArrayList arrayList = new ArrayList();
          String[] arrayOfString = p2AppManagerUtils.getFolderSubFilesNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList3.get(b1) + File.separatorChar + paramArrayOfString[b3] }), arrayList);
          arrayList1.add(Byte.valueOf((byte)arrayOfString.length));
          for (byte b4 = 0; b4 < arrayOfString.length; b4++) {
            byte[] arrayOfByte2 = arrayOfString[b4].getBytes();
            arrayList1.add(Byte.valueOf((byte)arrayOfByte2.length));
            for (byte b5 : arrayOfByte2)
              arrayList1.add(Byte.valueOf(b5)); 
            if (arrayOfString[b4].equals("t.reg")) {
              String[] arrayOfString3 = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList3.get(b1) + File.separatorChar + paramArrayOfString[b3] }) + File.separatorChar + arrayOfString[b4]);
              StringBuilder stringBuilder = new StringBuilder();
              for (String str1 : arrayOfString3)
                stringBuilder.append(str1 + "\n"); 
              String str = stringBuilder.toString();
              byte[] arrayOfByte3 = str.getBytes();
              boolean bool1 = false;
              if (arrayOfByte3.length <= 255) {
                arrayList1.add(Byte.valueOf((byte)2));
              } else {
                arrayList1.add(Byte.valueOf((byte)18));
                bool1 = true;
              } 
              byte[] arrayOfByte4 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte3.length).array();
              arrayList1.add(Byte.valueOf(arrayOfByte4[0]));
              if (bool1)
                arrayList1.add(Byte.valueOf(arrayOfByte4[1])); 
              for (byte b5 : arrayOfByte3)
                arrayList1.add(Byte.valueOf(b5)); 
            } else if (arrayOfString[b4].equals("param.conf")) {
              String[] arrayOfString3 = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList3.get(b1) + File.separatorChar + paramArrayOfString[b3] }) + File.separatorChar + arrayOfString[b4]);
              double[] arrayOfDouble = new double[arrayOfString3.length];
              byte[] arrayOfByte3 = new byte[arrayOfDouble.length * 8];
              byte b5;
              for (b5 = 0; b5 < arrayOfString3.length; b5++) {
                arrayOfDouble[b5] = Double.parseDouble(arrayOfString3[b5].split(":")[1]);
                byte[] arrayOfByte5 = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(arrayOfDouble[b5]).array();
                arrayOfByte3[b5 * 8] = arrayOfByte5[0];
                arrayOfByte3[b5 * 8 + 1] = arrayOfByte5[1];
                arrayOfByte3[b5 * 8 + 2] = arrayOfByte5[2];
                arrayOfByte3[b5 * 8 + 3] = arrayOfByte5[3];
                arrayOfByte3[b5 * 8 + 4] = arrayOfByte5[4];
                arrayOfByte3[b5 * 8 + 5] = arrayOfByte5[5];
                arrayOfByte3[b5 * 8 + 6] = arrayOfByte5[6];
                arrayOfByte3[b5 * 8 + 7] = arrayOfByte5[7];
              } 
              b5 = 0;
              if (arrayOfByte3.length <= 255) {
                arrayList1.add(Byte.valueOf((byte)0));
              } else {
                arrayList1.add(Byte.valueOf((byte)16));
                b5 = 1;
              } 
              byte[] arrayOfByte4 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte3.length).array();
              arrayList1.add(Byte.valueOf(arrayOfByte4[0]));
              if (b5 != 0)
                arrayList1.add(Byte.valueOf(arrayOfByte4[1])); 
              for (byte b6 : arrayOfByte3)
                arrayList1.add(Byte.valueOf(b6)); 
            } else if (arrayOfString[b4].equals("C2x.cal")) {
              String[] arrayOfString3 = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList3.get(b1) + File.separatorChar + paramArrayOfString[b3] }) + File.separatorChar + arrayOfString[b4]);
              float[] arrayOfFloat = new float[arrayOfString3.length];
              byte[] arrayOfByte3 = new byte[arrayOfFloat.length * 4];
              byte b5;
              for (b5 = 0; b5 < arrayOfString3.length; b5++) {
                arrayOfFloat[b5] = Float.parseFloat(arrayOfString3[b5]);
                byte[] arrayOfByte5 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(arrayOfFloat[b5]).array();
                arrayOfByte3[b5 * 4] = arrayOfByte5[0];
                arrayOfByte3[b5 * 4 + 1] = arrayOfByte5[1];
                arrayOfByte3[b5 * 4 + 2] = arrayOfByte5[2];
                arrayOfByte3[b5 * 4 + 3] = arrayOfByte5[3];
              } 
              b5 = 0;
              if (arrayOfByte3.length <= 255) {
                arrayList1.add(Byte.valueOf((byte)3));
              } else {
                arrayList1.add(Byte.valueOf((byte)19));
                b5 = 1;
              } 
              byte[] arrayOfByte4 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte3.length).array();
              arrayList1.add(Byte.valueOf(arrayOfByte4[0]));
              if (b5 != 0)
                arrayList1.add(Byte.valueOf(arrayOfByte4[1])); 
              for (byte b6 : arrayOfByte3)
                arrayList1.add(Byte.valueOf(b6)); 
            } else {
              String[] arrayOfString3 = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList3.get(b1) + File.separatorChar + paramArrayOfString[b3] }) + File.separatorChar + arrayOfString[b4]);
              double[] arrayOfDouble = new double[arrayOfString3.length];
              byte[] arrayOfByte3 = new byte[arrayOfDouble.length * 8];
              byte b5;
              for (b5 = 0; b5 < arrayOfString3.length; b5++) {
                arrayOfDouble[b5] = Double.parseDouble(arrayOfString3[b5]);
                byte[] arrayOfByte5 = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(arrayOfDouble[b5]).array();
                arrayOfByte3[b5 * 8] = arrayOfByte5[0];
                arrayOfByte3[b5 * 8 + 1] = arrayOfByte5[1];
                arrayOfByte3[b5 * 8 + 2] = arrayOfByte5[2];
                arrayOfByte3[b5 * 8 + 3] = arrayOfByte5[3];
                arrayOfByte3[b5 * 8 + 4] = arrayOfByte5[4];
                arrayOfByte3[b5 * 8 + 5] = arrayOfByte5[5];
                arrayOfByte3[b5 * 8 + 6] = arrayOfByte5[6];
                arrayOfByte3[b5 * 8 + 7] = arrayOfByte5[7];
              } 
              b5 = 0;
              if (arrayOfByte3.length <= 255) {
                arrayList1.add(Byte.valueOf((byte)0));
              } else {
                arrayList1.add(Byte.valueOf((byte)16));
                b5 = 1;
              } 
              byte[] arrayOfByte4 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte3.length).array();
              arrayList1.add(Byte.valueOf(arrayOfByte4[0]));
              if (b5 != 0)
                arrayList1.add(Byte.valueOf(arrayOfByte4[1])); 
              for (byte b6 : arrayOfByte3)
                arrayList1.add(Byte.valueOf(b6)); 
            } 
          } 
        } 
      } 
      byte[] arrayOfByte = new byte[arrayList1.size()];
      for (b2 = 0; b2 < arrayList1.size(); b2++)
        arrayOfByte[b2] = ((Byte)arrayList1.get(b2)).byteValue(); 
      try {
        this.O.a(0, arrayOfByte.length, arrayOfByte);
        arrayOfByte = new byte[1];
        arrayOfByte[0] = 1;
        this.O.a(65408, arrayOfByte.length, arrayOfByte);
      } catch (Exception b2) {
        Exception exception;
        throw new p2AppManagerException("Exception occurred while writing data to ROM. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
      } 
    } catch (Exception exception) {
      throw new p2AppManagerException("Exception occurred while writing profiles to ROM. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
    } 
    F();
  }
  
  private void F() {
    int i1 = E();
    String[] arrayOfString1 = D();
    ArrayList arrayList1 = new ArrayList();
    String[] arrayOfString2 = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), new ArrayList(), false);
    ArrayList arrayList2 = new ArrayList();
    for (String str : arrayOfString2) {
      if (!str.equals(".svn") && !str.contains(".txt"))
        arrayList2.add(str); 
    } 
    if (arrayList2.size() == 0)
      throw new p2AppManagerException("Invalid number of tempreture folders to be burnt. Error: ", p2Enumerations.p2AppManagerStatus.TEMP_FOLDERS_ERROR.getNumVal()); 
    ArrayList arrayList3 = new ArrayList();
    String[] arrayOfString3 = p2AppManagerUtils.getFolderSubFilesNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), arrayList3);
    if (arrayOfString3.length != 0) {
      arrayList1.add(Byte.valueOf((byte)1));
      byte[] arrayOfByte1 = arrayOfString3[0].getBytes();
      arrayList1.add(Byte.valueOf((byte)arrayOfByte1.length));
      for (byte b3 : arrayOfByte1)
        arrayList1.add(Byte.valueOf(b3)); 
      String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c }));
      StringBuilder stringBuilder = new StringBuilder();
      for (String str1 : arrayOfString)
        stringBuilder.append(str1 + "\n"); 
      String str = stringBuilder.toString();
      byte[] arrayOfByte2 = str.getBytes();
      boolean bool = false;
      if (arrayOfByte2.length <= 255) {
        arrayList1.add(Byte.valueOf((byte)2));
      } else {
        arrayList1.add(Byte.valueOf((byte)18));
        bool = true;
      } 
      byte[] arrayOfByte3 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte2.length).array();
      arrayList1.add(Byte.valueOf(arrayOfByte3[0]));
      if (bool)
        arrayList1.add(Byte.valueOf(arrayOfByte3[1])); 
      for (byte b3 : arrayOfByte2)
        arrayList1.add(Byte.valueOf(b3)); 
    } else {
      arrayList1.add(Byte.valueOf((byte)0));
    } 
    arrayList1.add(Byte.valueOf((byte)arrayList2.size()));
    for (byte b1 = 0; b1 < arrayList2.size(); b1++) {
      arrayList1.add(Byte.valueOf((byte)((String)arrayList2.get(b1)).getBytes().length));
      byte[] arrayOfByte1 = ((String)arrayList2.get(b1)).getBytes();
      for (byte b4 : arrayOfByte1)
        arrayList1.add(Byte.valueOf(b4)); 
      arrayList1.add(Byte.valueOf((byte)arrayOfString1.length));
      for (byte b3 = 0; b3 < arrayOfString1.length; b3++) {
        arrayList1.add(Byte.valueOf((byte)arrayOfString1[b3].getBytes().length));
        arrayOfByte1 = arrayOfString1[b3].getBytes();
        for (byte b6 : arrayOfByte1)
          arrayList1.add(Byte.valueOf(b6)); 
        ArrayList arrayList = new ArrayList();
        String[] arrayOfString = p2AppManagerUtils.getFolderSubFilesNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList2.get(b1) + File.separatorChar + arrayOfString1[b3] }), arrayList);
        byte b4 = 0;
        byte b5;
        for (b5 = 0; b5 < arrayOfString.length; b5++) {
          if (arrayOfString[b5].equals("corr.cal") || arrayOfString[b5].equals("wavelength_corr.cal"))
            b4++; 
        } 
        arrayList1.add(Byte.valueOf((byte)b4));
        for (b5 = 0; b5 < arrayOfString.length; b5++) {
          if (arrayOfString[b5].equals("corr.cal") || arrayOfString[b5].equals("wavelength_corr.cal")) {
            byte[] arrayOfByte2 = arrayOfString[b5].getBytes();
            arrayList1.add(Byte.valueOf((byte)arrayOfByte2.length));
            for (byte b7 : arrayOfByte2)
              arrayList1.add(Byte.valueOf(b7)); 
            String[] arrayOfString4 = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList2.get(b1) + File.separatorChar + arrayOfString1[b3] }) + File.separatorChar + arrayOfString[b5]);
            double[] arrayOfDouble = new double[arrayOfString4.length];
            byte[] arrayOfByte3 = new byte[arrayOfDouble.length * 8];
            byte b6;
            for (b6 = 0; b6 < arrayOfString4.length; b6++) {
              arrayOfDouble[b6] = Double.parseDouble(arrayOfString4[b6]);
              byte[] arrayOfByte5 = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(arrayOfDouble[b6]).array();
              arrayOfByte3[b6 * 8] = arrayOfByte5[0];
              arrayOfByte3[b6 * 8 + 1] = arrayOfByte5[1];
              arrayOfByte3[b6 * 8 + 2] = arrayOfByte5[2];
              arrayOfByte3[b6 * 8 + 3] = arrayOfByte5[3];
              arrayOfByte3[b6 * 8 + 4] = arrayOfByte5[4];
              arrayOfByte3[b6 * 8 + 5] = arrayOfByte5[5];
              arrayOfByte3[b6 * 8 + 6] = arrayOfByte5[6];
              arrayOfByte3[b6 * 8 + 7] = arrayOfByte5[7];
            } 
            b6 = 0;
            if (arrayOfByte3.length <= 255) {
              arrayList1.add(Byte.valueOf((byte)0));
            } else {
              arrayList1.add(Byte.valueOf((byte)16));
              b6 = 1;
            } 
            byte[] arrayOfByte4 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte3.length).array();
            arrayList1.add(Byte.valueOf(arrayOfByte4[0]));
            if (b6 != 0)
              arrayList1.add(Byte.valueOf(arrayOfByte4[1])); 
            for (byte b7 : arrayOfByte3)
              arrayList1.add(Byte.valueOf(b7)); 
          } 
        } 
      } 
    } 
    byte[] arrayOfByte = new byte[arrayList1.size()];
    for (b2 = 0; b2 < arrayList1.size(); b2++)
      arrayOfByte[b2] = ((Byte)arrayList1.get(b2)).byteValue(); 
    if (arrayOfByte.length + i1 < 65408) {
      try {
        this.O.a(i1, arrayOfByte.length, arrayOfByte);
        arrayOfByte = new byte[1];
        arrayOfByte[0] = 2;
        this.O.a(65408, arrayOfByte.length, arrayOfByte);
      } catch (Exception b2) {
        Exception exception;
        throw new p2AppManagerException("Exception occurred while writing data to ROM. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
      } 
    } else {
      throw new p2AppManagerException("Exception occurred while writing data to ROM. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
    } 
  }
  
  private void G() {
    int i1 = E();
    String[] arrayOfString1 = D();
    ArrayList arrayList1 = new ArrayList();
    String[] arrayOfString2 = p2AppManagerUtils.getFolderSubFoldersNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), new ArrayList(), false);
    ArrayList arrayList2 = new ArrayList();
    for (String str : arrayOfString2) {
      if (!str.equals(".svn") && !str.contains(".txt"))
        arrayList2.add(str); 
    } 
    if (arrayList2.size() == 0)
      throw new p2AppManagerException("Invalid number of tempreture folders to be burnt. Error: ", p2Enumerations.p2AppManagerStatus.TEMP_FOLDERS_ERROR.getNumVal()); 
    ArrayList arrayList3 = new ArrayList();
    String[] arrayOfString3 = p2AppManagerUtils.getFolderSubFilesNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PATH_TEMPLATE), new Object[] { this.c }), arrayList3);
    if (arrayOfString3.length != 0) {
      arrayList1.add(Byte.valueOf((byte)1));
      byte[] arrayOfByte1 = arrayOfString3[0].getBytes();
      arrayList1.add(Byte.valueOf((byte)arrayOfByte1.length));
      for (byte b3 : arrayOfByte1)
        arrayList1.add(Byte.valueOf(b3)); 
      String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_TEMP2_FILE_PATH)), new Object[] { this.c }));
      StringBuilder stringBuilder = new StringBuilder();
      for (String str1 : arrayOfString)
        stringBuilder.append(str1 + "\n"); 
      String str = stringBuilder.toString();
      byte[] arrayOfByte2 = str.getBytes();
      boolean bool = false;
      if (arrayOfByte2.length <= 255) {
        arrayList1.add(Byte.valueOf((byte)2));
      } else {
        arrayList1.add(Byte.valueOf((byte)18));
        bool = true;
      } 
      byte[] arrayOfByte3 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte2.length).array();
      arrayList1.add(Byte.valueOf(arrayOfByte3[0]));
      if (bool)
        arrayList1.add(Byte.valueOf(arrayOfByte3[1])); 
      for (byte b3 : arrayOfByte2)
        arrayList1.add(Byte.valueOf(b3)); 
    } else {
      arrayList1.add(Byte.valueOf((byte)0));
    } 
    arrayList1.add(Byte.valueOf((byte)arrayList2.size()));
    for (byte b1 = 0; b1 < arrayList2.size(); b1++) {
      arrayList1.add(Byte.valueOf((byte)((String)arrayList2.get(b1)).getBytes().length));
      byte[] arrayOfByte1 = ((String)arrayList2.get(b1)).getBytes();
      for (byte b4 : arrayOfByte1)
        arrayList1.add(Byte.valueOf(b4)); 
      arrayList1.add(Byte.valueOf((byte)arrayOfString1.length));
      for (byte b3 = 0; b3 < arrayOfString1.length; b3++) {
        arrayList1.add(Byte.valueOf((byte)arrayOfString1[b3].getBytes().length));
        arrayOfByte1 = arrayOfString1[b3].getBytes();
        for (byte b6 : arrayOfByte1)
          arrayList1.add(Byte.valueOf(b6)); 
        ArrayList arrayList = new ArrayList();
        String[] arrayOfString = p2AppManagerUtils.getFolderSubFilesNames(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList2.get(b1) + File.separatorChar + arrayOfString1[b3] }), arrayList);
        byte b4 = 0;
        byte b5;
        for (b5 = 0; b5 < arrayOfString.length; b5++) {
          if (arrayOfString[b5].equals("corr.cal") || arrayOfString[b5].equals("wavelength_corr.cal"))
            b4++; 
        } 
        arrayList1.add(Byte.valueOf((byte)b4));
        for (b5 = 0; b5 < arrayOfString.length; b5++) {
          if (arrayOfString[b5].equals("corr.cal") || arrayOfString[b5].equals("wavelength_corr.cal")) {
            byte[] arrayOfByte2 = arrayOfString[b5].getBytes();
            arrayList1.add(Byte.valueOf((byte)arrayOfByte2.length));
            for (byte b7 : arrayOfByte2)
              arrayList1.add(Byte.valueOf(b7)); 
            String[] arrayOfString4 = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE), new Object[] { this.c, (String)arrayList2.get(b1) + File.separatorChar + arrayOfString1[b3] }) + File.separatorChar + arrayOfString[b5]);
            double[] arrayOfDouble = new double[arrayOfString4.length];
            byte[] arrayOfByte3 = new byte[arrayOfDouble.length * 8];
            byte b6;
            for (b6 = 0; b6 < arrayOfString4.length; b6++) {
              arrayOfDouble[b6] = Double.parseDouble(arrayOfString4[b6]);
              byte[] arrayOfByte5 = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(arrayOfDouble[b6]).array();
              arrayOfByte3[b6 * 8] = arrayOfByte5[0];
              arrayOfByte3[b6 * 8 + 1] = arrayOfByte5[1];
              arrayOfByte3[b6 * 8 + 2] = arrayOfByte5[2];
              arrayOfByte3[b6 * 8 + 3] = arrayOfByte5[3];
              arrayOfByte3[b6 * 8 + 4] = arrayOfByte5[4];
              arrayOfByte3[b6 * 8 + 5] = arrayOfByte5[5];
              arrayOfByte3[b6 * 8 + 6] = arrayOfByte5[6];
              arrayOfByte3[b6 * 8 + 7] = arrayOfByte5[7];
            } 
            b6 = 0;
            if (arrayOfByte3.length <= 255) {
              arrayList1.add(Byte.valueOf((byte)0));
            } else {
              arrayList1.add(Byte.valueOf((byte)16));
              b6 = 1;
            } 
            byte[] arrayOfByte4 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(arrayOfByte3.length).array();
            arrayList1.add(Byte.valueOf(arrayOfByte4[0]));
            if (b6 != 0)
              arrayList1.add(Byte.valueOf(arrayOfByte4[1])); 
            for (byte b7 : arrayOfByte3)
              arrayList1.add(Byte.valueOf(b7)); 
          } 
        } 
      } 
    } 
    byte[] arrayOfByte = new byte[arrayList1.size()];
    for (b2 = 0; b2 < arrayList1.size(); b2++)
      arrayOfByte[b2] = ((Byte)arrayList1.get(b2)).byteValue(); 
    if (arrayOfByte.length + i1 < 65408) {
      try {
        this.O.a(i1, arrayOfByte.length, arrayOfByte);
        arrayOfByte = new byte[1];
        arrayOfByte[0] = 2;
        this.O.a(65408, arrayOfByte.length, arrayOfByte);
      } catch (Exception b2) {
        Exception exception;
        throw new p2AppManagerException("Exception occurred while writing data to ROM. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
      } 
    } else {
      throw new p2AppManagerException("Exception occurred while writing data to ROM. Error: ", p2Enumerations.p2AppManagerStatus.WRITING_PROFILES_TO_ROM_ERROR.getNumVal());
    } 
  }
  
  private ByteBuffer a(int paramInt1, int paramInt2) throws p2AppManagerException {
    byte[] arrayOfByte;
    ByteBuffer byteBuffer = null;
    try {
      arrayOfByte = this.O.b(paramInt1, paramInt2);
    } catch (Exception exception) {
      throw new p2AppManagerException("Invalid number of temp folders. Error: ", p2Enumerations.p2AppManagerStatus.TEMP_FOLDERS_ERROR.getNumVal());
    } 
    if (paramInt2 == 1) {
      byte[] arrayOfByte1 = new byte[2];
      arrayOfByte1[0] = arrayOfByte[0];
      arrayOfByte1[1] = 0;
      byteBuffer = ByteBuffer.wrap(arrayOfByte1);
      byteBuffer.order(ByteOrder.nativeOrder());
    } else if (paramInt2 == 2) {
      byteBuffer = ByteBuffer.wrap(arrayOfByte);
      byteBuffer.order(ByteOrder.nativeOrder());
    } else {
      byteBuffer = ByteBuffer.wrap(arrayOfByte);
    } 
    return byteBuffer;
  }
  
  public p2Enumerations.p2AppManagerStatus C(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 9)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    this.E = "";
    paramb.a("TAIFReg", this.O.f());
    try {
      this.O.a(paramb.c());
    } catch (a null) {
      b.error("Loading register file failed");
      return p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR;
    } 
    this.r = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.CalculateResponse, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    boolean bool2 = false;
    try {
      bool2 = this.O.a(true);
    } catch (a a2) {
      return p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR;
    } 
    if (!bool2)
      try {
        this.O.a(true, true, (int)paramb.b()[48]);
        try {
          Thread.sleep((long)paramb.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      }  
    a(p2Enumerations.p2AppManagerState.ResponseCalculation);
    this.D = paramb;
    a(a1, bool1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] o() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.r == null) {
      b.error("there is no Response data may be you don't have any successful Response runs");
      return (double[][])null;
    } 
    return this.r;
  }
  
  public p2Enumerations.p2AppManagerStatus D(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 9)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool1 = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool1 = true; 
    this.E = "";
    paramb.a("TAIFReg", this.O.f());
    try {
      this.O.a(paramb.c());
    } catch (a null) {
      b.error("Loading register file failed");
      return p2Enumerations.p2AppManagerStatus.ASIC_REGISTER_WRITING_ERROR;
    } 
    this.s = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.CalculateParameters, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    boolean bool2 = false;
    try {
      bool2 = this.O.a(true);
    } catch (a a2) {
      return p2Enumerations.p2AppManagerStatus.ACTUATION_SETTING_ERROR;
    } 
    if (!bool2)
      try {
        this.O.a(true, true, (int)paramb.b()[48]);
        try {
          Thread.sleep((long)paramb.b()[12]);
        } catch (InterruptedException interruptedException) {
          b.error(interruptedException.getMessage());
        } 
      } catch (a a2) {
        return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
      }  
    a(p2Enumerations.p2AppManagerState.ParametersCalculation);
    this.D = paramb;
    a(a1, bool1);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] p() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.s == null) {
      b.error("there is no Parameters data may be you don't have any successful Parameters runs");
      return (double[][])null;
    } 
    return this.s;
  }
  
  public p2Enumerations.p2AppManagerStatus E(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 9)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.t = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.TrimCoefficients, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.CoefficientsTrimming);
    this.D = paramb;
    b(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] q() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.t == null) {
      b.error("there is no Coefficients data may be you don't have any successful Coefficients runs");
      return (double[][])null;
    } 
    return this.t;
  }
  
  public p2Enumerations.p2AppManagerStatus F(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 7)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.E = "";
    this.u = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.TrimPhase, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    try {
      this.O.a(false, false, (int)paramb.b()[48]);
    } catch (a a2) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    try {
      this.O.a(true, false, (int)paramb.b()[48]);
      try {
        Thread.sleep((long)paramb.b()[12]);
      } catch (InterruptedException interruptedException) {
        b.error(interruptedException.getMessage());
      } 
    } catch (a a2) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.PhaseTrimming);
    this.D = paramb;
    c(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public p2Enumerations.p2AppManagerStatus G(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 8)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.E = "";
    this.u = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.TrimPhaseFast, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    try {
      this.O.a(false, false, (int)paramb.b()[48]);
    } catch (a a2) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    try {
      this.O.a(true, false, (int)paramb.b()[48]);
      try {
        Thread.sleep((long)paramb.b()[12]);
      } catch (InterruptedException interruptedException) {
        b.error(interruptedException.getMessage());
      } 
    } catch (a a2) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.FastPhaseTrimming);
    this.D = paramb;
    c(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] r() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.u == null) {
      b.error("there is no Phase data may be you don't have any successful Phase runs");
      return (double[][])null;
    } 
    return this.u;
  }
  
  public p2Enumerations.p2AppManagerStatus H(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 4)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.E = "";
    try {
      this.O.a(false, false, (int)paramb.b()[48]);
    } catch (a null) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    try {
      this.O.a(true, false, (int)paramb.b()[48]);
      try {
        Thread.sleep((long)paramb.b()[12]);
      } catch (InterruptedException null) {
        b.error(a1.getMessage());
      } 
    } catch (a null) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    this.v = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.CheckStability, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.StabilityCheck);
    this.D = paramb;
    d(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] s() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.v == null) {
      b.error("there is no Stability data may be you don't have any successful Stability runs");
      return (double[][])null;
    } 
    return this.v;
  }
  
  public p2Enumerations.p2AppManagerStatus I(b paramb, String... paramVarArgs) {
    a a1;
    if (paramVarArgs.length != 3)
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR; 
    if (p2Enumerations.p2AppManagerState.Idle != w())
      return p2Enumerations.p2AppManagerStatus.DEVICE_BUSY_ERROR; 
    boolean bool = false;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = y();
    if (p2Enumerations.p2AppManagerStatus.BOARD_DISTCONNECTED_ERROR == p2AppManagerStatus || p2Enumerations.p2AppManagerStatus.UNKNOWN_ERROR == p2AppManagerStatus)
      return p2AppManagerStatus; 
    if (p2Enumerations.p2AppManagerStatus.BOARD_NOT_INITIALIZED_ERROR == p2AppManagerStatus)
      bool = true; 
    this.E = "";
    try {
      this.O.a(false, false, (int)paramb.b()[48]);
    } catch (a null) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    try {
      this.O.a(true, false, (int)paramb.b()[48]);
      try {
        Thread.sleep((long)paramb.b()[12]);
      } catch (InterruptedException null) {
        b.error(a1.getMessage());
      } 
    } catch (a null) {
      return p2Enumerations.p2AppManagerStatus.DEVICE_IS_TURNED_OFF_ERROR;
    } 
    this.w = (double[][])null;
    try {
      a1 = a(p2Enumerations.p2DeviceAction.RunWaveform, paramVarArgs);
    } catch (Exception exception) {
      return p2Enumerations.p2AppManagerStatus.INVALID_RUN_PARAMETERS_ERROR;
    } 
    a(p2Enumerations.p2AppManagerState.WaveformPreview);
    this.D = paramb;
    a(a1, bool);
    return p2Enumerations.p2AppManagerStatus.NO_ERROR;
  }
  
  public double[][] t() {
    if (p2Enumerations.p2AppManagerState.Idle != w()) {
      b.error("p2Device is busy now");
      return (double[][])null;
    } 
    if (this.w == null) {
      b.error("there is no Waveform data may be you don't have any successful Waveform runs");
      return (double[][])null;
    } 
    return this.w;
  }
  
  public boolean c(String[] paramArrayOfString) {
    if (!(new File(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c }))).exists())
      try {
        (new File(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c }))).createNewFile();
      } catch (Exception exception) {
        return false;
      }  
    ArrayList arrayList = new ArrayList(Arrays.asList(paramArrayOfString));
    String[] arrayOfString = p2AppManagerUtils.readStringfile(p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c }));
    byte b1 = 0;
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      b1 = 0;
      if (arrayOfString[b2].equals(paramArrayOfString[0])) {
        arrayOfString[b2 + b1] = "TO_BE_DELETED";
        while (b2 + ++b1 < arrayOfString.length && !arrayOfString[b2 + b1].startsWith(".option")) {
          arrayOfString[b2 + b1] = "TO_BE_DELETED";
          b1++;
        } 
      } 
    } 
    arrayList.addAll(Arrays.asList(arrayOfString));
    arrayList.removeAll(Collections.singleton("TO_BE_DELETED"));
    boolean bool = p2AppManagerUtils.writeFileOfArray((String[])arrayList.toArray(new String[0]), p2AppManagerUtils.formatString(p2Constants.getPath(p2Constants.OPTICAL_SETTINGS_FILE_PATH), new Object[] { this.c }), "\n");
    return !(bool != true);
  }
  
  private class a {
    p2Enumerations.p2AppManagerState a;
    
    double b;
    
    short c;
    
    short d;
    
    int e;
    
    short f;
    
    int g;
    
    boolean h;
    
    String i;
    
    double j;
    
    String k;
    
    int l;
    
    double m;
    
    double n;
    
    String o;
    
    int p;
    
    int q;
    
    boolean r;
    
    boolean s;
    
    double t;
    
    int u;
    
    int v;
    
    String w;
    
    boolean x;
    
    boolean y;
    
    boolean z;
    
    boolean A;
    
    double B;
    
    String C;
    
    String D;
    
    long[] E;
    
    String[] F;
    
    String G;
    
    double H;
    
    double I;
    
    double J;
    
    double K;
    
    double L;
    
    double M;
    
    double N;
    
    double O;
    
    double P;
    
    double Q;
    
    double R;
    
    double S;
    
    double T;
    
    double U;
    
    double V;
    
    int W;
    
    boolean X;
    
    String Y;
    
    int Z;
    
    int aa;
    
    int ab;
    
    double ac;
    
    int ad;
    
    int ae;
    
    int af;
    
    int ag;
    
    String ah;
    
    private a(b this$0) {}
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\b\b.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */