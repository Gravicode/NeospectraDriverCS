package sws.p2AppManager;

import java.io.File;
import java.util.Observable;
import org.apache.log4j.Logger;
import sws.p2AppManager.a.b;
import sws.p2AppManager.b.a;
import sws.p2AppManager.b.b;
import sws.p2AppManager.utils.p2AppManagerException;
import sws.p2AppManager.utils.p2AppManagerNotification;
import sws.p2AppManager.utils.p2AppManagerUtils;
import sws.p2AppManager.utils.p2Constants;
import sws.p2AppManager.utils.p2DeviceNotificationResult;
import sws.p2AppManager.utils.p2Enumerations;

class p2AppManagerFullImpl extends p2AppManager {
  private b a;
  
  private a b;
  
  private static Logger c = Logger.getLogger(p2AppManagerImpl.class);
  
  private String d = System.getProperty("user.dir");
  
  public p2AppManagerFullImpl() {
    p2Constants.APPLICATION_WORKING_DIRECTORY = this.d;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = a();
    if (p2AppManagerStatus != p2Enumerations.p2AppManagerStatus.NO_ERROR);
  }
  
  public p2AppManagerFullImpl(String paramString) {
    p2Constants.APPLICATION_WORKING_DIRECTORY = paramString;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = a();
    if (p2AppManagerStatus != p2Enumerations.p2AppManagerStatus.NO_ERROR)
      throw new p2AppManagerException("Failed to initialize General Configurations", p2AppManagerStatus.getNumVal()); 
    p2AppManagerUtils.createDir(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs");
  }
  
  public p2Enumerations.p2AppManagerStatus initializeCore(String... paramVarArgs) {
    c.info("start initializeCore method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.a(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus checkDeviceStatus(String... paramVarArgs) {
    if (this.b == null)
      this.b = b(); 
    return this.b.b(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runSpec(String... paramVarArgs) {
    c.info("start runSpec method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.c(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus wavelengthCalibrationBG(String... paramVarArgs) {
    c.info("start wavelengthCalibrationBG method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.d(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus wavelengthCalibration(String... paramVarArgs) {
    c.info("start wavelengthCalibration method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.e(this.a, paramVarArgs);
  }
  
  public double getErrorData() {
    c.info("start getErrorData method ");
    return (this.b == null) ? 1.0D : this.b.b();
  }
  
  public double[][] getSpecData() {
    c.info("start getSpecData method ");
    return (this.b == null) ? (double[][])null : this.b.c();
  }
  
  public p2Enumerations.p2AppManagerStatus runInterSpecDSP(double[][] paramArrayOfDouble, String... paramVarArgs) {
    c.info("start runInterSpecDSP method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.a(this.a, paramArrayOfDouble, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runInterSpec(String... paramVarArgs) {
    c.info("start runInterSpec method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.f(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus updateFFT_SettingsInterSpec(String... paramVarArgs) {
    c.info("start updateFFT_SettingsInterSpec method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.g(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus updateFFT_SettingsSpec(String... paramVarArgs) {
    c.info("start updateFFT_SettingsSpec method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.h(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runSNR(String... paramVarArgs) {
    c.info("start runSNR method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.i(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runStability(String... paramVarArgs) {
    c.info("start runStability method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.j(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runCalibCorr(String... paramVarArgs) {
    c.info("start runCalibCorr method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.k(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runInterSpecGainAdj(String... paramVarArgs) {
    c.info("start runInterSpecGainAdj method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.l(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runSpecGainAdjBG(String... paramVarArgs) {
    c.info("start runSpecGainAdjBG method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.m(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus saveInterSpecGainSettings(String paramString, double[][] paramArrayOfDouble) {
    c.info("start saveInterSpecGainSettings method ");
    return this.b.a(paramString, paramArrayOfDouble);
  }
  
  public p2Enumerations.p2AppManagerStatus saveSpecGainSettings(String paramString, double[][] paramArrayOfDouble) {
    c.info("start saveSpecGainSettings method ");
    return this.b.b(paramString, paramArrayOfDouble);
  }
  
  public p2Enumerations.p2AppManagerStatus runSpecGainAdjSample(String... paramVarArgs) {
    c.info("start runSpecGainAdjSample method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.n(this.a, paramVarArgs);
  }
  
  public double[][] getRawData() {
    c.info("start getRawData method ");
    return (this.b == null) ? (double[][])null : this.b.d();
  }
  
  public double[][] getInterSpecData() {
    c.info("start getInterSpecData method ");
    return (this.b == null) ? (double[][])null : this.b.e();
  }
  
  public double[][] getGainAdjustInterSpecData() {
    c.info("start getGainAdjustInterSpecData method ");
    return (this.b == null) ? (double[][])null : this.b.f();
  }
  
  public double[][] getGainAdjustSpecData() {
    c.info("start getGainAdjustSpecData method ");
    return (this.b == null) ? (double[][])null : this.b.g();
  }
  
  public double[][] getSNR_Data() {
    c.info("start getSNR_Data method ");
    return (this.b == null) ? (double[][])null : this.b.h();
  }
  
  public double[][] getStabilityData() {
    c.info("start getStabilityData method ");
    return (this.b == null) ? (double[][])null : this.b.i();
  }
  
  public p2Enumerations.p2AppManagerStatus runCapTime_Calibration(String... paramVarArgs) {
    c.info("start runCapTime_Calibration method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.o(this.a, paramVarArgs);
  }
  
  public double[][] getCapTimeData() {
    c.info("start getCapTimeData method ");
    return (this.b == null) ? (double[][])null : this.b.j();
  }
  
  public p2Enumerations.p2AppManagerStatus runDelayCompensation_Calibration(String... paramVarArgs) {
    c.info("start runDelayCompensation_Calibration method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.p(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runCalibrationCore_Calibration(String... paramVarArgs) {
    c.info("start runCalibrationCore_Calibration method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.q(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus generateCalibration(String... paramVarArgs) {
    c.info("start generateCalibration method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.r(this.a, paramVarArgs);
  }
  
  public double[][] getCalibrationData() {
    c.info("start getCalibrationData method ");
    return (this.b == null) ? (double[][])null : this.b.k();
  }
  
  public p2Enumerations.p2AppManagerStatus runCapCurrent(String... paramVarArgs) {
    c.info("start runCapCurrent method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.s(this.a, paramVarArgs);
  }
  
  public double[][] getCapCurrentData() {
    c.info("start getCapCurrentData method ");
    return (this.b == null) ? (double[][])null : this.b.l();
  }
  
  public p2Enumerations.p2AppManagerStatus burnSampleID(String... paramVarArgs) {
    c.info("start burnSampleID method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.v(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus burnSampleFolders(String[] paramArrayOfString) {
    c.info("start burnSampleFolders method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.w(this.a, paramArrayOfString);
  }
  
  public p2Enumerations.p2AppManagerStatus restoreDefaultSettings(String... paramVarArgs) {
    c.info("start restoreDefaultSettings method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.x(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus burnSettings(String... paramVarArgs) {
    c.info("start restoreDefaultSettings method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.y(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus burnSpecificSettings(String... paramVarArgs) {
    c.info("start restoreDefaultSettings method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.J(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus readSampleFolders(String... paramVarArgs) {
    c.info("start readSampleFolders method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.z(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus readTemp(String... paramVarArgs) {
    c.info("start readTemp method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.A(this.a, paramVarArgs);
  }
  
  public double[][] getTempData() {
    c.info("start getTempData method ");
    return (this.b == null) ? (double[][])null : this.b.m();
  }
  
  public p2Enumerations.p2AppManagerStatus readASICRegisters(String... paramVarArgs) {
    c.info("start readASICRegisters method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.B(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus writeASICRegisters(long[] paramArrayOfLong) {
    c.info("start writeASICRegisters method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.a(this.a, paramArrayOfLong);
  }
  
  public long[] getASICRegisters() {
    c.info("start getASICRegisters method ");
    return (this.b == null) ? null : this.b.n();
  }
  
  public p2Enumerations.p2AppManagerStatus switchDevice(String... paramVarArgs) {
    c.info("start setActuation method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.t(this.a, paramVarArgs);
  }
  
  public void setSettings(String... paramVarArgs) {
    c.info("start setSampleFolder method ");
    if (this.b == null)
      this.b = b(); 
    this.b.u(this.a, paramVarArgs);
  }
  
  public void setOpticalSettings(String... paramVarArgs) {
    c.info("start setOpticalSettings method ");
    if (this.b == null)
      this.b = b(); 
    this.b.a(paramVarArgs);
  }
  
  public String getDeviceId() { return this.b.a(); }
  
  public String getSDKVersion() { return "4.3"; }
  
  public p2Enumerations.p2AppManagerStatus calculateResponse_ClosedLoop(String... paramVarArgs) {
    c.info("start calculateResponse_ClosedLoop method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.C(this.a, paramVarArgs);
  }
  
  public double[][] getResponseData() {
    c.info("start getResponseData method ");
    return (this.b == null) ? (double[][])null : this.b.o();
  }
  
  public p2Enumerations.p2AppManagerStatus calculateParameters_ClosedLoop(String... paramVarArgs) {
    c.info("start calculateParameters_ClosedLoop method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.D(this.a, paramVarArgs);
  }
  
  public double[][] getParametersData() {
    c.info("start getParametersData method ");
    return (this.b == null) ? (double[][])null : this.b.p();
  }
  
  public p2Enumerations.p2AppManagerStatus CoefficientsTrimming_ClosedLoop(String... paramVarArgs) {
    c.info("start CoefficientsTrimming_ClosedLoop method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.E(this.a, paramVarArgs);
  }
  
  public double[][] getCoefficientsTrimmingData() {
    c.info("start getCoefficientsTrimmingData method ");
    return (this.b == null) ? (double[][])null : this.b.q();
  }
  
  public p2Enumerations.p2AppManagerStatus PhaseTrimming_ClosedLoop(String... paramVarArgs) {
    c.info("start PhaseTrimming_ClosedLoop method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.F(this.a, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus PhaseTrimmingFast_ClosedLoop(String... paramVarArgs) {
    c.info("start PhaseTrimmingFast_ClosedLoop method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.G(this.a, paramVarArgs);
  }
  
  public double[][] getPhaseTrimmingData() {
    c.info("start getPhaseTrimmingData method ");
    return (this.b == null) ? (double[][])null : this.b.r();
  }
  
  public p2Enumerations.p2AppManagerStatus StabilityCheck_ClosedLoop(String... paramVarArgs) {
    c.info("start StabilityCheck_ClosedLoop method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.H(this.a, paramVarArgs);
  }
  
  public double[][] getStabilityCheckData() {
    c.info("start getStabilityCheckData method ");
    return (this.b == null) ? (double[][])null : this.b.s();
  }
  
  public p2Enumerations.p2AppManagerStatus WaveformPreview_ClosedLoop(String... paramVarArgs) {
    c.info("start WaveformPreview_ClosedLoop method ");
    if (this.b == null)
      this.b = b(); 
    return this.b.I(this.a, paramVarArgs);
  }
  
  public double[][] getWaveformPreviewData() {
    c.info("start getWaveformPreviewData method ");
    return (this.b == null) ? (double[][])null : this.b.t();
  }
  
  public void update(Observable paramObservable, Object paramObject) {
    c.info("start update method ");
    if (paramObject == null || !(paramObject instanceof p2DeviceNotificationResult)) {
      setChanged();
      notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_NOTIFICATION_ERROR.getNumVal(), null));
    } 
    p2DeviceNotificationResult p2DeviceNotificationResult = (p2DeviceNotificationResult)paramObject;
    p2Enumerations.p2DeviceAction p2DeviceAction = p2DeviceNotificationResult.getAction();
    if (p2DeviceAction == null) {
      setChanged();
      notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_ACTION_ERROR.getNumVal(), null));
    } 
    String str = p2DeviceNotificationResult.getDeviceId();
    if (p2AppManagerUtils.isEmptyString(str)) {
      setChanged();
      notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_DEVICE_ERROR.getNumVal(), null));
    } 
    switch (null.a[p2DeviceAction.ordinal()]) {
      case 1:
        c.info("initialize core....");
        a(str, p2DeviceNotificationResult.getStatus());
        return;
      case 2:
        c.info("run inter spec....");
        b(str, p2DeviceNotificationResult.getStatus());
        return;
      case 3:
        c.info("run FFT settings inter spec....");
        c(str, p2DeviceNotificationResult.getStatus());
        return;
      case 4:
        c.info("run FFT settings spec....");
        d(str, p2DeviceNotificationResult.getStatus());
        return;
      case 5:
        c.info("run Gain Adjustment InterSpec....");
        e(str, p2DeviceNotificationResult.getStatus());
        return;
      case 6:
        c.info("run Gain Adjustment Spec BG....");
        f(str, p2DeviceNotificationResult.getStatus());
        return;
      case 7:
        c.info("run Gain Adjustment Spec Sample....");
        g(str, p2DeviceNotificationResult.getStatus());
        return;
      case 8:
        c.info("run background ....");
        k(str, p2DeviceNotificationResult.getStatus());
        return;
      case 9:
        c.info("run spectrocopy ....");
        l(str, p2DeviceNotificationResult.getStatus());
        return;
      case 10:
        c.info("run BG wavelength calibration ....");
        m(str, p2DeviceNotificationResult.getStatus());
        return;
      case 11:
        c.info("run wavelength calibration ....");
        n(str, p2DeviceNotificationResult.getStatus());
        return;
      case 12:
        c.info("run SNR ....");
        h(str, p2DeviceNotificationResult.getStatus());
        return;
      case 13:
        c.info("run Stability ....");
        i(str, p2DeviceNotificationResult.getStatus());
        return;
      case 14:
        c.info("run Interferogram Corr ....");
        j(str, p2DeviceNotificationResult.getStatus());
        return;
      case 15:
        c.info("Setting Actuation....");
        o(str, p2DeviceNotificationResult.getStatus());
        return;
      case 16:
        c.info("Run CapTime Calibration....");
        p(str, p2DeviceNotificationResult.getStatus());
        return;
      case 17:
        c.info("Run DelayCompensation Calibration....");
        q(str, p2DeviceNotificationResult.getStatus());
        return;
      case 18:
        c.info("Run Core Calibration....");
        r(str, p2DeviceNotificationResult.getStatus());
        return;
      case 19:
        c.info("Generate Calibration....");
        s(str, p2DeviceNotificationResult.getStatus());
        return;
      case 20:
        c.info("Run Cap Current....");
        t(str, p2DeviceNotificationResult.getStatus());
        return;
      case 21:
        c.info("Burn SampleID....");
        u(str, p2DeviceNotificationResult.getStatus());
        return;
      case 22:
        c.info("Burn Sample Folders....");
        v(str, p2DeviceNotificationResult.getStatus());
        return;
      case 23:
        c.info("Read Sample Folders....");
        y(str, p2DeviceNotificationResult.getStatus());
        return;
      case 24:
        c.info("Read Temp....");
        z(str, p2DeviceNotificationResult.getStatus());
        return;
      case 25:
        c.info("Read ASIC Registers....");
        A(str, p2DeviceNotificationResult.getStatus());
        return;
      case 26:
        c.info("Write ASIC Registers....");
        B(str, p2DeviceNotificationResult.getStatus());
        return;
      case 27:
        c.info("Calculate Response....");
        C(str, p2DeviceNotificationResult.getStatus());
        return;
      case 28:
        c.info("Calculate Parameters....");
        D(str, p2DeviceNotificationResult.getStatus());
        return;
      case 29:
        c.info("Trim Coefficients....");
        E(str, p2DeviceNotificationResult.getStatus());
        return;
      case 30:
        c.info("Trim Phase....");
        F(str, p2DeviceNotificationResult.getStatus());
        return;
      case 31:
        c.info("Trim Phase....");
        G(str, p2DeviceNotificationResult.getStatus());
        return;
      case 32:
        c.info("Check Stability....");
        H(str, p2DeviceNotificationResult.getStatus());
        return;
      case 33:
        c.info("Run Waveform....");
        I(str, p2DeviceNotificationResult.getStatus());
        return;
      case 34:
        c.info("Burn Working Settings....");
        x(str, p2DeviceNotificationResult.getStatus());
        return;
      case 35:
        c.info("Restore Default Settings");
        w(str, p2DeviceNotificationResult.getStatus());
        return;
    } 
    setChanged();
    notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_ACTION_ERROR.getNumVal(), null));
  }
  
  private p2Enumerations.p2AppManagerStatus a() {
    this.a = new b();
    return this.a.d();
  }
  
  private a b() {
    b b1 = new b();
    b1.addObserver(this);
    return b1;
  }
  
  private void a(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("lynxinitializeCoreFinished");
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.initializeCore.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void b(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunInterSpecFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunInterSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void c(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunUpdateFFT_InterSpecFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsInterSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void d(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunUpdateFFT_SpecFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void e(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunAdaptiveGainFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunGainAdjustInterSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void f(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunGainAdjustSpecBG_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunGainAdjustSpecBG.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void g(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunGainAdjustSpecSampleFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunGainAdjustSpecSample.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void h(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunSNR_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunSNR.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void i(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunStabilityFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunStability.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void j(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunInterferogramCorr_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunSelfCorr.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void k(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunSpecBackgroundeFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunSpecBackground.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void l(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunSpecSampleFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunSpecSample.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void m(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunWavelengthCalibrationBG_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunWavelengthCalibrationBG.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void n(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunWavelengthCalibrationFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunWavelengthCalibration.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void o(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("SetActuationFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.SetActuation.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void p(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunCapTime_Calibration_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunCapTimeCalibration.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void q(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunDelayCompensation_Calibration_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunDelayCompensation.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void r(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunCore_Calibration_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunCalibration.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void s(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("GenerateCalibrationFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.GenerateCalibration.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void t(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunCapCurrentFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunCapCurrent.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void u(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("BurnSampleIDFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.BurnSampleID.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void v(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("BurnSampleFoldersFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.BurnSampleFolders.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void w(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RestoreDefaultSettingsFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RestoreDefaultSettings.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void x(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("BurnSettingsFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.BurnWorkingSettings.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void y(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("ReadSampleFoldersFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.ReadSampleFolders.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void z(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("readTempFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.ReadTemp.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void A(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("ReadASICRegistersFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.ReadASICRegisters.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void B(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("WriteASICRegistersFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.WriteASICRegisters.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void C(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("CalculateResponseFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.CalculateResponse.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void D(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("CalculateParametersFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.CalculateParameters.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void E(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("TrimCoefficientsFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.TrimCoefficients.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void F(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("TrimPhaseFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.TrimPhase.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void G(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("TrimPhaseFastFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.TrimPhaseFast.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void H(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("CheckStabilityFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.CheckStability.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void I(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    c.info("RunWaveformFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunWaveform.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  public void setWorkingDirectory(String paramString) {
    this.d = paramString;
    p2Constants.APPLICATION_WORKING_DIRECTORY = paramString;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = a();
    if (p2AppManagerStatus != p2Enumerations.p2AppManagerStatus.NO_ERROR)
      throw new p2AppManagerException("Failed to initialize General Configurations", p2AppManagerStatus.getNumVal()); 
    if (this.b == null)
      this.b = b(); 
    this.b.u();
    p2AppManagerUtils.createDir(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs");
  }
  
  public String getWorkingDirectory() { return this.d; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\p2AppManagerFullImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */