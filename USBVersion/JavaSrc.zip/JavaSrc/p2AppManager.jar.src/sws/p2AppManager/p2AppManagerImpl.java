package sws.p2AppManager;

import java.io.File;
import java.util.Observable;
import org.apache.log4j.Logger;
import sws.p2AppManager.a.b;
import sws.p2AppManager.b.a;
import sws.p2AppManager.b.b;
import sws.p2AppManager.utils.p2AppManagerException;
import sws.p2AppManager.utils.p2AppManagerNotification;
import sws.p2AppManager.utils.p2AppManagerUtils;
import sws.p2AppManager.utils.p2Constants;
import sws.p2AppManager.utils.p2DeviceNotificationResult;
import sws.p2AppManager.utils.p2Enumerations;

public class p2AppManagerImpl extends p2AppManager {
  private b globalSampleConfiguration;
  
  private a device;
  
  private static Logger logger = Logger.getLogger(p2AppManagerImpl.class);
  
  private String workingDirectory = System.getProperty("user.dir");
  
  public p2AppManagerImpl() {
    p2Constants.APPLICATION_WORKING_DIRECTORY = this.workingDirectory;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = a();
    if (p2AppManagerStatus != p2Enumerations.p2AppManagerStatus.NO_ERROR);
  }
  
  public p2AppManagerImpl(String paramString) {
    p2Constants.APPLICATION_WORKING_DIRECTORY = paramString;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = a();
    if (p2AppManagerStatus != p2Enumerations.p2AppManagerStatus.NO_ERROR)
      throw new p2AppManagerException("Failed to initialize General Configurations", p2AppManagerStatus.getNumVal()); 
    p2AppManagerUtils.createDir(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs");
  }
  
  public p2Enumerations.p2AppManagerStatus initializeCore(String... paramVarArgs) {
    logger.info("start initializeCore method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.a(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus checkDeviceStatus(String... paramVarArgs) {
    if (this.device == null)
      this.device = b(); 
    return this.device.b(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runSpec(String... paramVarArgs) {
    logger.info("start runSpec method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.c(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus wavelengthCalibrationBG(String... paramVarArgs) {
    logger.info("start wavelengthCalibrationBG method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.d(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus wavelengthCalibration(String... paramVarArgs) {
    logger.info("start wavelengthCalibration method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.e(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public double getErrorData() {
    logger.info("start getErrorData method ");
    return (this.device == null) ? 1.0D : this.device.b();
  }
  
  public double[][] getSpecData() {
    logger.info("start getSpecData method ");
    return (this.device == null) ? (double[][])null : this.device.c();
  }
  
  public p2Enumerations.p2AppManagerStatus runInterSpecDSP(double[][] paramArrayOfDouble, String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus runInterSpec(String... paramVarArgs) {
    logger.info("start runInterSpec method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.f(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus updateFFT_SettingsInterSpec(String... paramVarArgs) {
    logger.info("start updateFFT_SettingsInterSpec method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.g(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus updateFFT_SettingsSpec(String... paramVarArgs) {
    logger.info("start updateFFT_SettingsSpec method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.h(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runSNR(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus runStability(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus runCalibCorr(String... paramVarArgs) {
    logger.info("start runCalibCorr method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.k(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runInterSpecGainAdj(String... paramVarArgs) {
    logger.info("start runInterSpecGainAdj method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.l(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus runSpecGainAdjBG(String... paramVarArgs) {
    logger.info("start runSpecGainAdjBG method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.m(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus saveInterSpecGainSettings(String paramString, double[][] paramArrayOfDouble) {
    logger.info("start saveInterSpecGainSettings method ");
    return this.device.a(paramString, paramArrayOfDouble);
  }
  
  public p2Enumerations.p2AppManagerStatus saveSpecGainSettings(String paramString, double[][] paramArrayOfDouble) {
    logger.info("start saveSpecGainSettings method ");
    return this.device.b(paramString, paramArrayOfDouble);
  }
  
  public p2Enumerations.p2AppManagerStatus runSpecGainAdjSample(String... paramVarArgs) {
    logger.info("start runSpecGainAdjSample method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.n(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public double[][] getRawData() { return (double[][])null; }
  
  public double[][] getInterSpecData() {
    logger.info("start getInterSpecData method ");
    return (this.device == null) ? (double[][])null : this.device.e();
  }
  
  public double[][] getGainAdjustInterSpecData() {
    logger.info("start getGainAdjustInterSpecData method ");
    return (this.device == null) ? (double[][])null : this.device.f();
  }
  
  public double[][] getGainAdjustSpecData() {
    logger.info("start getGainAdjustSpecData method ");
    return (this.device == null) ? (double[][])null : this.device.g();
  }
  
  public double[][] getSNR_Data() { return (double[][])null; }
  
  public double[][] getStabilityData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus switchDevice(String... paramVarArgs) {
    logger.info("start setActuation method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.t(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public void setSettings(String... paramVarArgs) {
    logger.info("start setSampleFolder method ");
    if (this.device == null)
      this.device = b(); 
    this.device.u(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public void setOpticalSettings(String... paramVarArgs) {
    logger.info("start setOpticalSettings method ");
    if (this.device == null)
      this.device = b(); 
    this.device.a(paramVarArgs);
  }
  
  public String getDeviceId() { return this.device.a(); }
  
  public String getSDKVersion() { return "4.3"; }
  
  public void update(Observable paramObservable, Object paramObject) {
    logger.info("start update method ");
    if (paramObject == null || !(paramObject instanceof p2DeviceNotificationResult)) {
      setChanged();
      notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_NOTIFICATION_ERROR.getNumVal(), null));
    } 
    p2DeviceNotificationResult p2DeviceNotificationResult = (p2DeviceNotificationResult)paramObject;
    p2Enumerations.p2DeviceAction p2DeviceAction = p2DeviceNotificationResult.getAction();
    if (p2DeviceAction == null) {
      setChanged();
      notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_ACTION_ERROR.getNumVal(), null));
    } 
    String str = p2DeviceNotificationResult.getDeviceId();
    if (p2AppManagerUtils.isEmptyString(str)) {
      setChanged();
      notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_DEVICE_ERROR.getNumVal(), null));
    } 
    switch (null.a[p2DeviceAction.ordinal()]) {
      case 1:
        logger.info("initialize core....");
        a(str, p2DeviceNotificationResult.getStatus());
        return;
      case 2:
        logger.info("run inter spec....");
        b(str, p2DeviceNotificationResult.getStatus());
        return;
      case 3:
        logger.info("run FFT settings inter spec....");
        c(str, p2DeviceNotificationResult.getStatus());
        return;
      case 4:
        logger.info("run FFT settings spec....");
        d(str, p2DeviceNotificationResult.getStatus());
        return;
      case 5:
        logger.info("run Gain Adjustment InterSpec....");
        e(str, p2DeviceNotificationResult.getStatus());
        return;
      case 6:
        logger.info("run Gain Adjustment Spec BG....");
        f(str, p2DeviceNotificationResult.getStatus());
        return;
      case 7:
        logger.info("run Gain Adjustment Spec Sample....");
        g(str, p2DeviceNotificationResult.getStatus());
        return;
      case 8:
        logger.info("run background ....");
        h(str, p2DeviceNotificationResult.getStatus());
        return;
      case 9:
        logger.info("run spectrocopy ....");
        i(str, p2DeviceNotificationResult.getStatus());
        return;
      case 10:
        logger.info("run BG wavelength calibration ....");
        j(str, p2DeviceNotificationResult.getStatus());
        return;
      case 11:
        logger.info("run wavelength calibration ....");
        k(str, p2DeviceNotificationResult.getStatus());
        return;
      case 12:
        logger.info("Setting Actuation....");
        l(str, p2DeviceNotificationResult.getStatus());
        return;
      case 13:
        logger.info("Burn Working Settings....");
        o(str, p2DeviceNotificationResult.getStatus());
        return;
      case 14:
        logger.info("Restore Default Settings");
        m(str, p2DeviceNotificationResult.getStatus());
        return;
      case 15:
        logger.info("run Interferogram Corr ....");
        n(str, p2DeviceNotificationResult.getStatus());
        return;
    } 
    setChanged();
    notifyObservers(new p2AppManagerNotification(-1, p2Enumerations.p2AppManagerStatus.INVALID_ACTION_ERROR.getNumVal(), null));
  }
  
  private p2Enumerations.p2AppManagerStatus a() {
    this.globalSampleConfiguration = new b();
    return this.globalSampleConfiguration.d();
  }
  
  private a b() {
    b b1 = new b();
    b1.addObserver(this);
    return b1;
  }
  
  private void a(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("lynxinitializeCoreFinished");
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.initializeCore.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void b(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunInterSpecFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunInterSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void c(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunUpdateFFT_InterSpecFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsInterSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void d(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunUpdateFFT_SpecFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void e(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunGainAdjustInterSpecFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunGainAdjustInterSpec.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void f(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunGainAdjustSpecBG_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunGainAdjustSpecBG.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void g(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunGainAdjustSpecSampleFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunGainAdjustSpecSample.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void h(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunSpecBackgroundeFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunSpecBackground.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void i(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunSpecSampleFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunSpecSample.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void j(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunWavelengthCalibrationBG_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunWavelengthCalibrationBG.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void k(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunWavelengthCalibrationFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunWavelengthCalibration.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void l(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("SetActuationFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.SetActuation.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  public p2Enumerations.p2AppManagerStatus runCapTime_Calibration(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getCapTimeData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus runDelayCompensation_Calibration(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus runCalibrationCore_Calibration(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus generateCalibration(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getCalibrationData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus runCapCurrent(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getCapCurrentData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus burnSampleID(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus burnSampleFolders(String[] paramArrayOfString) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  private void m(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RestoreDefaultSettingsFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RestoreDefaultSettings.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void n(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("RunInterferogramCorr_Finished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.RunSelfCorr.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  private void o(String paramString, p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) {
    logger.info("BurnSettingsFinished with status : " + paramp2AppManagerStatus);
    setChanged();
    notifyObservers(new p2AppManagerNotification(p2Enumerations.p2DeviceAction.BurnWorkingSettings.getNumVal(), paramp2AppManagerStatus.getNumVal(), paramString));
  }
  
  public p2Enumerations.p2AppManagerStatus restoreDefaultSettings(String... paramVarArgs) {
    logger.info("start restoreDefaultSettings method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.x(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus burnSettings(String... paramVarArgs) {
    logger.info("start restoreDefaultSettings method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.y(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus burnSpecificSettings(String... paramVarArgs) {
    logger.info("start restoreDefaultSettings method ");
    if (this.device == null)
      this.device = b(); 
    return this.device.J(this.globalSampleConfiguration, paramVarArgs);
  }
  
  public p2Enumerations.p2AppManagerStatus readTemp(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getTempData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus readASICRegisters(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus writeASICRegisters(long[] paramArrayOfLong) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public long[] getASICRegisters() { return null; }
  
  public p2Enumerations.p2AppManagerStatus readSampleFolders(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus calculateResponse_ClosedLoop(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getResponseData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus calculateParameters_ClosedLoop(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getParametersData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus CoefficientsTrimming_ClosedLoop(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getCoefficientsTrimmingData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus PhaseTrimming_ClosedLoop(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public p2Enumerations.p2AppManagerStatus PhaseTrimmingFast_ClosedLoop(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getPhaseTrimmingData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus StabilityCheck_ClosedLoop(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getStabilityCheckData() { return (double[][])null; }
  
  public p2Enumerations.p2AppManagerStatus WaveformPreview_ClosedLoop(String... paramVarArgs) { return p2Enumerations.p2AppManagerStatus.SW_DOESNOT_SUPPORT_THIS_FEATURE; }
  
  public double[][] getWaveformPreviewData() { return (double[][])null; }
  
  public void setWorkingDirectory(String paramString) {
    this.workingDirectory = paramString;
    p2Constants.APPLICATION_WORKING_DIRECTORY = paramString;
    p2Enumerations.p2AppManagerStatus p2AppManagerStatus = a();
    if (p2AppManagerStatus != p2Enumerations.p2AppManagerStatus.NO_ERROR)
      throw new p2AppManagerException("Failed to initialize General Configurations", p2AppManagerStatus.getNumVal()); 
    if (this.device == null)
      this.device = b(); 
    this.device.u();
    p2AppManagerUtils.createDir(p2Constants.APPLICATION_WORKING_DIRECTORY + File.separatorChar + "logs");
  }
  
  public String getWorkingDirectory() { return this.workingDirectory; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\p2AppManagerImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */