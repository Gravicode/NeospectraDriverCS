package sws.p2AppManager.c;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class b extends ThreadPoolExecutor {
  static final int a = 3;
  
  static final int b = 3;
  
  static final long c = 3L;
  
  static final TimeUnit d = TimeUnit.MINUTES;
  
  static final BlockingQueue<Runnable> e = new LinkedBlockingQueue();
  
  private static b f;
  
  private b() { super(3, 3, 3L, d, e); }
  
  static b a() {
    if (f == null)
      f = new b(); 
    return f;
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\c\b.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */