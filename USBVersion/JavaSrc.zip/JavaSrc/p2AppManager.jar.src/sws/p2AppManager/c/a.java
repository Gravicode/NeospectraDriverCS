package sws.p2AppManager.c;

import java.util.concurrent.Callable;

public abstract class a<T> extends Object implements Callable<T> {
  public T call() throws Exception { return (T)b(); }
  
  protected abstract T b() throws Exception;
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\c\a.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */