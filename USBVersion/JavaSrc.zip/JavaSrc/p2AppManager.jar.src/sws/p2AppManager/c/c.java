package sws.p2AppManager.c;

import java.util.concurrent.Future;
import sws.p2AppManager.utils.p2AppManagerException;
import sws.p2AppManager.utils.p2Enumerations;

public class c {
  private static b a = b.a();
  
  public static <T> Future<T> a(a<T> parama) {
    try {
      return a.submit(parama);
    } catch (Exception exception) {
      throw new p2AppManagerException("Failed to sumbit current job ", p2Enumerations.p2AppManagerStatus.THREADING_ERROR.getNumVal());
    } 
  }
  
  public static void a() { a.shutdown(); }
  
  public static boolean b() { return a.isTerminated(); }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManager\c\c.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */