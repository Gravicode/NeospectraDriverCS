package sws.p2AppManager.utils;

import java.io.File;

public class p2Constants {
  public static String APPLICATION_WORKING_DIRECTORY = System.getProperty("user.dir");
  
  public static final String Original_APPLICATION_WORKING_DIRECTORY = System.getProperty("user.dir");
  
  public static final String PARAM_HEADER_FIE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "param.conf";
  
  public static final String CONFIG_SAMPLE_PATH_TEMPLATE = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Conf_Files" + File.separatorChar + "{0}";
  
  public static final String CONFIG_SAMPLE_PROFILE_PATH_TEMPLATE = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Conf_Files" + File.separatorChar + "{0}" + File.separatorChar + "{1}";
  
  public static final String TEMP_CONFIG_SAMPLE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Conf_Files" + File.separatorChar + "TempConf";
  
  public static final String CONFIG_SAMPLE_PROFILE_FILES_PATH_TEMPLATE = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Conf_Files" + File.separatorChar + "{0}" + File.separatorChar + "{1}" + File.separatorChar + "{2}";
  
  public static final String GLOBAL_CONFIG_FILES_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "{0}";
  
  public static final String GLOBAL_CONFIG_MEMS_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems";
  
  public static final String REGISTERS_OPTIONS_FOLDER_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers";
  
  public static final String CONF_FILES_FLODER = "Conf_Files";
  
  public static final String MEMS_FLODER = "mems";
  
  public static final String WHITE_LIGHT_FILES_DIR = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "white Light";
  
  public static final String WHITE_LIGHT_FILE = "WhiteLight.xml";
  
  public static final String OPTICAL_SETTINGS_FILE_NAME = "savedOpticalSettings.txt";
  
  public static final String OPTICAL_SETTINGS_TEMP_FILE_NAME = "tempOpticalSettings.txt";
  
  public static final String OPTICAL_SETTINGS_TEMP_FILE_NAME2 = "tempOpticalSettings2.txt";
  
  public static final String OPTICAL_SETTINGS_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Conf_Files" + File.separatorChar + "{0}" + File.separatorChar + "savedOpticalSettings.txt";
  
  public static final String OPTICAL_SETTINGS_TEMP_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Conf_Files" + File.separatorChar + "TempConf" + File.separatorChar + "tempOpticalSettings.txt";
  
  public static final String OPTICAL_SETTINGS_TEMP2_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Conf_Files" + File.separatorChar + "TempConf" + File.separatorChar + "tempOpticalSettings2.txt";
  
  public static final String OPTICAL_SETTINGS_CURRENT_RANGE = "CURRENT_RANGE";
  
  public static final String OPTICAL_SETTINGS_PGA1 = "PGA1";
  
  public static final String OPTICAL_SETTINGS_PGA2 = "PGA2";
  
  public static final String STANDARD_CALIBRATORS_FOLDER_NAME = "standard_calibrators";
  
  public static final String PARAM_COFIG_FILE = "param.conf";
  
  public static final String TREG_COFIG_FILE = "t.reg";
  
  public static final String C2X_COFIG_FILE = "C2x.cal";
  
  public static final String CORR_COFIG_FILE = "corr.cal";
  
  public static final String WL_CORR_COFIG_FILE = "wl_corr.cal";
  
  public static final String WAVE_LENGTH_COFIG_FILE = "wavelength_corr.cal";
  
  public static final String CALIBRATION = "Calibration";
  
  public static final String REGISTERS = "Registers";
  
  public static final String DETECTOR_AND_CURRENT_RANGE_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "OpticalPathSettings" + File.separatorChar + "DetectorAndCurrentRange.txt";
  
  public static final String PGA1_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "OpticalPathSettings" + File.separatorChar + "PGA1.txt";
  
  public static final String PGA2_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "OpticalPathSettings" + File.separatorChar + "PGA2.txt";
  
  public static final String ACTUATION_DIRECTION_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "OpenLoopSettings" + File.separatorChar + "ActuationDirection.txt";
  
  public static final String WAVEFORM_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "OpenLoopSettings" + File.separatorChar + "Waveform.txt";
  
  public static final String EXCITATION_VOLTAGE_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "CapSensingPathSettings" + File.separatorChar + "ExcitationVoltage.txt";
  
  public static final String SAMPLING_RATE_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "CapSensingPathSettings" + File.separatorChar + "SamplingRate.txt";
  
  public static final String C2V_GAIN_OPTION_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "Registers" + File.separatorChar + "CapSensingPathSettings" + File.separatorChar + "C2VGain.txt";
  
  public static final String CLOSED_LOOP_GAIN_VS_FREQ_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "moduleSettings" + File.separatorChar + "closedLoopSettings" + File.separatorChar + "bpfGainVsFreq.txt";
  
  public static final String STANDARD_CALIBRATORS_FOLDER_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "mems" + File.separatorChar + "standard_calibrators";
  
  public static final String STANDARD_CALIBRATORS_FILE_EXT = ".txt";
  
  public static final String OPTICAL_PATH_SETTINGS_BLOCK = "OpticalPathSettings";
  
  public static final String DETECTOR_AND_CURRENT_RANGE_OPTION = "DetectorAndCurrentRange.txt";
  
  public static final String PGA1_OPTION = "PGA1.txt";
  
  public static final String PGA2_OPTION = "PGA2.txt";
  
  public static final String OPEN_LOOP_SETTINGS_BLOCK = "OpenLoopSettings";
  
  public static final String WAVEFORM_OPTION = "Waveform.txt";
  
  public static final String ACTUATION_DIRECTION_OPTION = "ActuationDirection.txt";
  
  public static final String CAP_SENSING_PATH_SETTINGS_BLOCK = "CapSensingPathSettings";
  
  public static final String EXCITATION_VOLTAGE_OPTION = "ExcitationVoltage.txt";
  
  public static final String SAMPLING_RATE_OPTION = "SamplingRate.txt";
  
  public static final String C2V_GAIN_OPTION = "C2VGain.txt";
  
  public static final String LASER_FILE = "sl";
  
  public static final String WL_FILE = "wl";
  
  public static final String METH_FILE = "mc";
  
  public static final String CALIBRATION_FOLDER_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Calibration";
  
  public static final String LASER_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Calibration" + File.separatorChar + "sl";
  
  public static final String WL_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Calibration" + File.separatorChar + "wl";
  
  public static final String METH_FILE_PATH = Original_APPLICATION_WORKING_DIRECTORY + File.separatorChar + "Calibration" + File.separatorChar + "mc";
  
  public static final String TWO_POINTS_CORR_CALIB_FOLDER_NAME = "two_points_corr";
  
  public static final String STANDARD_CALIBRATOR_DEFAULT_CHOISE = "Choose Material ...";
  
  public static final int INTER_SPEC_WL_CORR = p2Enumerations.p2CorrectionType.Corrected.getNumVal();
  
  public static final short INTER_SPEC_NORMALIZE_SPECTRUM = 0;
  
  public static final short INTER_SPEC_PHASE_CORRECTION = 0;
  
  public static final short SELF_CORRECTION_DISABLED = 0;
  
  public static final short SELF_CORRECTION_ENABLED = 1;
  
  public static final String INTER_SPEC_INTERFERO_DATA_FILE = "Interferogram";
  
  public static final String INTER_SPEC_SPECTRA_DATA_FILE = "Spectra";
  
  public static final int SPEC_WL_CORR = p2Enumerations.p2CorrectionType.Corrected.getNumVal();
  
  public static final short SPEC_NORMALIZE_SPECTRUM = 0;
  
  public static final short SPEC_PHASE_CORRECTION = 0;
  
  public static final String SPEC_SPECTRUM_DATA_FILE = "Spectrum";
  
  public static final int BG_SPEC_WL_CORR = p2Enumerations.p2CorrectionType.Corrected.getNumVal();
  
  public static final short BG_SPEC_NORMALIZE_SPECTRUM = 0;
  
  public static final short BG_SPEC_PHASE_CORRECTION = 0;
  
  public static final int CALIB_WL_CORR = p2Enumerations.p2CorrectionType.Corrected.getNumVal();
  
  public static final int OPTICAL_PATH_DIFFERENCE_INDEX = 0;
  
  public static final int I_INDEX = 1;
  
  public static final int WAVENUMBER_INDEX = 2;
  
  public static final int POWER_SPECTRAL_DENSITY_INDEX = 3;
  
  public static final int POWER_SPECTRAL_DENSITY_EXTENDED_INDEX = 5;
  
  public static final int CORR_FACTORS_INDEX = 4;
  
  public static final int DSP_DATA_LENGTH = 5;
  
  public static final int DSP_FINAL_DATA_LENGTH = 5;
  
  public static final int DSP_FFT_DATA_LENGTH = 4;
  
  public static final int DSP_CALIB_CAP_TIME_DATA_LENGTH = 7;
  
  public static final int DSP_CALIB_DELAY_COMP_DATA_LENGTH = 3;
  
  public static final int DSP_CALIB_DATA_LENGTH = 7;
  
  public static final int DSP_CAP_CURRENT_DATA_LENGTH = 12;
  
  public static final int DSP_WL_CORR_LENGTH = 10;
  
  public static final int DSP_DISPLAY_DATA_LENGTH = 4;
  
  public static final int DSP_SNR_DATA_LENGTH = 17;
  
  public static final int DSP_STABILITY_DATA_LENGTH = 8;
  
  public static final String DEFAULT_REG_FILE_FOLDER = "TAIFReg";
  
  public static final int REG_FILE_COUNT = 89;
  
  public static double MAX_RUNTIME_MS = 10000.0D;
  
  public static final int MIN_RUNTIMR_MS = 10;
  
  public static final int MAX_NO_OF_SLICES_1000 = 16384000;
  
  public static final int MAX_INT_THRESHOLD_CALIBRATION = (int)Math.pow(2.0D, 11.0D);
  
  public static final int DMUX_MODE_CAPLPF = 15;
  
  public static final int DMUX_MODE_AMP = 23;
  
  public static final int DMUX_MODE_AACOUT = 27;
  
  public static final int MAX_NO_OF_PROFILES_ON_ROM = 8;
  
  public static final int MAX_LSB_WINDOW_CALIBRATION = 72000;
  
  public static final int TEMPERATURE_WINDOW = 20;
  
  public static final double MAX_TEMP_LSB = 1.34217727E8D;
  
  public static final String[] apodizationOptions = { "Rectangular", "Tukey .25" };
  
  public static final int apodizationDefaultIndex = 0;
  
  public static final String[] paddingOptions = { "0", "1", "3", "7" };
  
  public static final int paddingDefaultIndex = 1;
  
  public static final int SUB_PANELS_DIMENTION = 300;
  
  public static final int MAX_WIDTH_OF_FIELD = 110;
  
  public static final int PARAM_CONF_INDEX_interpolationThreshold = 1;
  
  public static final int PARAM_CONF_INDEX_I_adc_gain = 9;
  
  public static final int PARAM_CONF_INDEX_act_freq = 11;
  
  public static final int PARAM_CONF_INDEX_time_initialdly = 12;
  
  public static final int PARAM_CONF_INDEX_xinterp_lim_min = 14;
  
  public static final int PARAM_CONF_INDEX_xinterp_lim_max = 15;
  
  public static final int PARAM_CONF_INDEX_NPs_interp = 17;
  
  public static final int PARAM_CONF_INDEX_closedLoop = 47;
  
  public static final int PARAM_CONF_INDEX_KiStartUpFactor = 48;
  
  public static final int PARAM_CONF_INDEX_OpticalGainMargin = 49;
  
  public static final int PARAM_CONF_INDEX_LambdaMin = 23;
  
  public static final int PARAM_CONF_INDEX_LambdaMax = 24;
  
  public static final int PARAM_CONF_INDEX_CUSTOMER_CORR_SELECT = 56;
  
  public static final int PARAM_CONF_INDEX_Apodization = 19;
  
  public static final int PARAM_CONF_INDEX_ZeroPadding = 22;
  
  public static final int PARAM_CONF_INDEX_saturationThr = 44;
  
  public static final int PARAM_CONF_INDEX_Wavenumber_Corr_select = 54;
  
  public static final int PARAM_CONF_INDEX_COMMON_WAVENUMBER_EN = 57;
  
  public static final int PARAM_CONF_INDEX_WAVENUMBER_VECTOR_LENGTH = 55;
  
  public static final double adaptiveGainRunTime = 10.0D;
  
  public static final double adaptiveGain_OPT_ADC_REF = 1.35D;
  
  public static final double adaptiveGain_OPT_ADC_FULL_SCALE = 512.0D;
  
  public static final String[] currentRanges = { "Detector1->1uA", "Detector1->2.5uA", "Detector1->5uA", "Detector1->10uA", "Detector1->20uA", "Detector1->40uA", "Detector1->80uA" };
  
  public static final int[] PGA1_values = { 1, 2, 4, 6, 8, 10 };
  
  public static final int[] PGA2_values = { 1, 2, 4, 6, 8, 10 };
  
  public static final String InterSpecPrefix = "_InterSpec_";
  
  public static final String SpecPrefix = "_Spec_";
  
  public static final int OPEN_LOOP_SAMPLE_FOLDERS_VERSION = 0;
  
  public static final int CLOSED_LOOP_SAMPLE_FOLDERS_VERSION = 0;
  
  public static final int UNKNOWN_SAMPLE_FOLDERS_VERSION = 0;
  
  public static final int ADAPTIVE_GAIN_SAMPLE_FOLDERS_VERSION = 1;
  
  public static final int RESTORE_DEFAULT_SAMPLE_FOLDERS_VERSION = 2;
  
  public static final int FALLING_NEGATIVE_DIRECTION = 0;
  
  public static final int RISING_POSITIVE_DIRECTION = 1;
  
  public static final String SDK_VERSION_NO = "4.3";
  
  public static String getPath(String paramString) { return paramString.replace(Original_APPLICATION_WORKING_DIRECTORY, APPLICATION_WORKING_DIRECTORY); }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManage\\utils\p2Constants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */