package sws.p2AppManager.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class p2AppManagerUtils {
  private static Logger a = Logger.getLogger(p2AppManagerUtils.class);
  
  public static boolean isFilenameValid(String paramString) {
    for (char c : paramString.toCharArray()) {
      switch (c) {
        case '\000':
        case '\t':
        case '\n':
        case '\f':
        case '\r':
        case '"':
        case '*':
        case '/':
        case ':':
        case '<':
        case '>':
        case '?':
        case '\\':
        case '`':
        case '|':
          return false;
      } 
    } 
    return true;
  }
  
  public static boolean createDir(String paramString) {
    File file = new File(paramString);
    return !file.exists() ? file.mkdirs() : 1;
  }
  
  public static boolean removeDir(String paramString) {
    File file = new File(paramString);
    if (file.exists()) {
      String[] arrayOfString = file.list();
      for (String str : arrayOfString) {
        File file1 = new File(file.getPath(), str);
        file1.delete();
      } 
      return file.delete();
    } 
    return true;
  }
  
  public static boolean removeDir(String paramString, boolean paramBoolean) {
    File file = new File(paramString);
    if (file.exists()) {
      String[] arrayOfString = file.list();
      for (String str : arrayOfString) {
        File file1 = new File(file.getPath(), str);
        if (file1.isDirectory() && paramBoolean)
          removeDir(file1.getPath(), true); 
        file1.delete();
      } 
      return file.delete();
    } 
    return true;
  }
  
  public static boolean exist(String paramString) {
    File file = new File(paramString);
    return file.exists();
  }
  
  public static String[] getFolderSubFoldersNames(String paramString, ArrayList<String> paramArrayList, boolean paramBoolean) {
    File file = new File(paramString);
    File[] arrayOfFile = file.listFiles();
    for (File file1 : arrayOfFile) {
      if (file1.isDirectory() && !file1.isHidden()) {
        paramArrayList.add(file1.getName());
        if (paramBoolean)
          getFolderSubFoldersNames(file1.getAbsolutePath(), paramArrayList, true); 
      } 
    } 
    return (String[])paramArrayList.toArray(new String[paramArrayList.size()]);
  }
  
  public static String[] getFolderSubFilesNames(String paramString, ArrayList<String> paramArrayList) {
    File file = new File(paramString);
    File[] arrayOfFile = file.listFiles();
    for (File file1 : arrayOfFile) {
      if (!file1.isDirectory() && !file1.isHidden())
        paramArrayList.add(file1.getName()); 
    } 
    return (String[])paramArrayList.toArray(new String[paramArrayList.size()]);
  }
  
  public static boolean isEmptyString(String paramString) { return (paramString == null || "".equals(paramString)); }
  
  public static String formatString(String paramString, Object... paramVarArgs) { return MessageFormat.format(paramString, paramVarArgs); }
  
  public static double[] loadParamFile(String paramString) {
    ArrayList arrayList = new ArrayList();
    bufferedReader = null;
    try {
      bufferedReader = new BufferedReader(new FileReader(paramString));
      str = null;
      while ((str = bufferedReader.readLine()) != null) {
        String[] arrayOfString = str.split(":");
        if (arrayOfString.length == 2)
          arrayList.add(Double.valueOf(Double.parseDouble(arrayOfString[1]))); 
      } 
    } catch (Exception exception) {
      a.error(exception.getMessage());
      return null;
    } finally {
      try {
        bufferedReader.close();
      } catch (Exception exception) {
        a.error(exception.getMessage());
      } 
    } 
    double[] arrayOfDouble = new double[arrayList.size()];
    for (byte b = 0; b < arrayOfDouble.length; b++)
      arrayOfDouble[b] = ((Double)arrayList.get(b)).doubleValue(); 
    return arrayOfDouble;
  }
  
  public static double[] loadRawDataFile(String paramString) {
    ArrayList arrayList = new ArrayList();
    bufferedReader = null;
    try {
      bufferedReader = new BufferedReader(new FileReader(paramString));
      str = null;
      while ((str = bufferedReader.readLine()) != null)
        arrayList.add(Double.valueOf(Double.parseDouble(str))); 
    } catch (Exception exception) {
      a.error(exception.getMessage());
      return null;
    } finally {
      try {
        bufferedReader.close();
      } catch (Exception exception) {
        a.error(exception.getMessage());
      } 
    } 
    double[] arrayOfDouble = new double[arrayList.size()];
    for (byte b = 0; b < arrayOfDouble.length; b++)
      arrayOfDouble[b] = ((Double)arrayList.get(b)).doubleValue(); 
    return arrayOfDouble;
  }
  
  public static double[] concatenateMultipleArraysIntoOne(double[]... paramVarArgs) {
    try {
      int i = 0;
      for (double[] arrayOfDouble1 : paramVarArgs)
        i += arrayOfDouble1.length + 1; 
      double[] arrayOfDouble = new double[i];
      int j = 0;
      for (double[] arrayOfDouble1 : paramVarArgs) {
        arrayOfDouble[j] = arrayOfDouble1.length;
        System.arraycopy(arrayOfDouble1, 0, arrayOfDouble, j + true, (int)arrayOfDouble[j]);
        j += arrayOfDouble1.length + 1;
      } 
      return arrayOfDouble;
    } catch (Exception exception) {
      a.error(exception.getMessage());
      return null;
    } 
  }
  
  public static List<String> decodeBytesToValues(int paramInt, byte[] paramArrayOfByte) {
    byte b;
    ArrayList arrayList = new ArrayList();
    switch (paramInt) {
      case 0:
        for (b = 0; b < paramArrayOfByte.length; b += 8)
          arrayList.add((new Double(p2NumberConverter.toDouble(paramArrayOfByte, b))).toString()); 
        return arrayList;
      case 1:
        for (b = 0; b < paramArrayOfByte.length; b += 4)
          arrayList.add((new Integer(p2NumberConverter.ToInt(paramArrayOfByte, b))).toString()); 
        return arrayList;
      case 2:
        arrayList.add(new String(paramArrayOfByte, StandardCharsets.US_ASCII));
        return arrayList;
      case 3:
        for (b = 0; b < paramArrayOfByte.length; b += 4)
          arrayList.add((new Float(p2NumberConverter.ToSingle(paramArrayOfByte, b))).toString()); 
        return arrayList;
    } 
    a.error("invalid data type ");
    return null;
  }
  
  public static String[] readStringfile(String paramString) {
    ArrayList arrayList = new ArrayList();
    bufferedReader = null;
    try {
      bufferedReader = new BufferedReader(new FileReader(paramString));
      str = null;
      while ((str = bufferedReader.readLine()) != null)
        arrayList.add(str); 
    } catch (Exception exception) {
      a.error(exception.getMessage());
      return null;
    } finally {
      try {
        bufferedReader.close();
      } catch (Exception exception) {
        a.error(exception.getMessage());
      } 
    } 
    return (String[])arrayList.toArray(new String[arrayList.size()]);
  }
  
  public static boolean writeFileOfArray(int[] paramArrayOfInt, String paramString1, String paramString2) {
    bufferedWriter = null;
    boolean bool = (paramString2 != null) ? 1 : 0;
    try {
      bufferedWriter = new BufferedWriter(new FileWriter(paramString1));
      for (int i : paramArrayOfInt) {
        bufferedWriter.write(Integer.toString(i));
        if (bool)
          bufferedWriter.write(paramString2); 
      } 
      bufferedWriter.close();
      return true;
    } catch (IOException iOException) {
      a.error(iOException.getMessage());
      return false;
    } finally {
      try {
        bufferedWriter.close();
      } catch (Exception exception) {
        a.error(exception.getMessage());
      } 
    } 
  }
  
  public static boolean writeFileOfArray(double[] paramArrayOfDouble, String paramString1, String paramString2) {
    bufferedWriter = null;
    boolean bool = (paramString2 != null) ? 1 : 0;
    try {
      bufferedWriter = new BufferedWriter(new FileWriter(paramString1));
      for (double d : paramArrayOfDouble) {
        bufferedWriter.write(Double.toString(d));
        if (bool)
          bufferedWriter.write(paramString2); 
      } 
      bufferedWriter.close();
      return true;
    } catch (IOException iOException) {
      a.error(iOException.getMessage());
      return false;
    } finally {
      try {
        bufferedWriter.close();
      } catch (Exception exception) {
        a.error(exception.getMessage());
      } 
    } 
  }
  
  public static boolean writeFileOfArray(String[] paramArrayOfString, String paramString1, String paramString2) {
    bufferedWriter = null;
    boolean bool = (paramString2 != null) ? 1 : 0;
    try {
      bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(paramString1), "utf-8"));
      for (String str : paramArrayOfString) {
        bufferedWriter.write(str);
        if (bool)
          bufferedWriter.write(paramString2); 
      } 
      return true;
    } catch (IOException iOException) {
      a.error(iOException.getMessage());
      return false;
    } finally {
      try {
        bufferedWriter.close();
      } catch (Exception exception) {
        a.error(exception.getMessage());
      } 
    } 
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManage\\utils\p2AppManagerUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */