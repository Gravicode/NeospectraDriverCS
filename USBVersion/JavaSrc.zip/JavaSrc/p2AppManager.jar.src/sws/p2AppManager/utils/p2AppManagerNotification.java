package sws.p2AppManager.utils;

public class p2AppManagerNotification {
  private int a;
  
  private int b;
  
  private String c;
  
  public p2AppManagerNotification(int paramInt1, int paramInt2, String paramString) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramString;
  }
  
  public int getAction() { return this.a; }
  
  public void setAction(int paramInt) { this.a = paramInt; }
  
  public int getStatus() { return this.b; }
  
  public void setStatus(int paramInt) { this.b = paramInt; }
  
  public String getDeviceId() { return this.c; }
  
  public void setDeviceId(String paramString) { this.c = paramString; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManage\\utils\p2AppManagerNotification.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */