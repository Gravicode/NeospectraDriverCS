package sws.p2AppManager.utils;

public class p2Enumerations {
  public enum p2AppManagerStatus {
    NO_ERROR(0),
    DEVICE_BUSY_ERROR(1),
    BOARD_DISTCONNECTED_ERROR(2),
    BOARD_NOT_INITIALIZED_ERROR(3),
    UNKNOWN_ERROR(4),
    CONFIG_FILES_LOADING_ERROR(7),
    CONFIG_PARAM_LENGTH_ERROR(8),
    INVALID_RUN_TIME_ERROR(11),
    CAP_FILE_CREATION_ERROR(12),
    CURRENT_FILE_CREATION_ERROR(13),
    ACT_FILE_CREATION_ERROR(14),
    NO_SAMPLE_CONFIG_FOLDERS_ERROR(15),
    NO_VALID_SAMPLE_CONFIG_FOLDERS_ERROR(16),
    NO_SAMPLE_PROFILE_SELECTED_ERROR(17),
    INAVLID_REG_FILE_FORMAT_ERROR(23),
    NO_OF_SCANS_DSP_ERROR(24),
    DSP_INTERFEROGRAM_POST_PROCESSING_ERROR(25),
    DSP_INTERFEROGRAM_POST_EMPTY_DATA_ERROR(26),
    DSP_INTERFEROGRAM_POST_BAD_DATA_ERROR(27),
    UPDATE_CORR_FILE_ERROR(28),
    WHITE_LIGHT_PROCESSING_ERROR(29),
    DSP_INTERFEROGRAM_FFT_POST_PROCESSINF_ERROR(30),
    INVALID_RUN_PARAMETERS_ERROR(31),
    INVALID_RUN_TIME_NOT_EQUAL_BG_RUN_TIME_ERROR(32),
    NO_VALID_BG_DATA_ERROR(33),
    INTERFERO_FILE_CREATION_ERROR(34),
    PSD_FILE_CREATION_ERROR(35),
    SPECTRUM_FILE_CREATION_ERROR(36),
    GRAPHS_FOLDER_CREATION_ERROR(37),
    INITIATE_TAIFDRIVER_ERROR(42),
    INVALID_BOARD_CONFIGURATION_ERROR(43),
    DATA_STREAMING_TAIF_ERROR(50),
    DATA_STREAMING_ERROR(51),
    INVALID_NOTIFICATION_ERROR(52),
    INVALID_ACTION_ERROR(53),
    INVALID_DEVICE_ERROR(54),
    THREADING_ERROR(55),
    BOARD_ALREADY_INITIALIZED(56),
    INITIALIZATION_IN_PROGRESS(57),
    SW_DOESNOT_SUPPORT_THIS_FEATURE(58),
    ACTUATION_SETTING_ERROR(60),
    DEVICE_IS_TURNED_OFF_ERROR(61),
    ASIC_REGISTER_WRITING_ERROR(62),
    CALIBRATION_FOLDER_GEN_ERROR(63),
    DATA_FILES_SAVING_ERROR(67),
    DSP_CALIB_CAP_TIME_POST_PROCESSING_ERROR(68),
    DSP_CALIB_CAP_TIME_POST_EMPTY_DATA_ERROR(69),
    DSP_CALIB_CAP_TIME_POST_BAD_DATA_ERROR(70),
    DSP_CALIB_DELAY_COMP_POST_PROCESSING_ERROR(71),
    DSP_CALIB_DELAY_COMP_POST_EMPTY_DATA_ERROR(72),
    DSP_CALIB_DELAY_COMP_POST_BAD_DATA_ERROR(73),
    PARAM_CONF_NOT_EXIST_ERROR(74),
    LASER_FILE_NOT_EXIST_ERROR(75),
    WHITE_FILE_NOT_EXIST_ERROR(76),
    METH_FILE_NOT_EXIST_ERROR(77),
    CALIBRATION_GENERATION_ERROR(78),
    DSP_CAP_CURRENT_POST_PROCESSING_ERROR(79),
    DSP_CAP_CURRENT_POST_EMPTY_DATA_ERROR(80),
    DSP_CAP_CURRENT_POST_BAD_DATA_ERROR(81),
    SAMPLE_ID_INVALID_ERROR(82),
    SAMPLE_FOLDERS_NUMBER_ERROR(83),
    LENGTH_OF_FILE_NAME_ERROR(84),
    INVALID_FILE_NAME_ERROR(85),
    INVALID_NO_OF_FILES_ERROR(86),
    LENGTH_OF_FOLDER_NAME_ERROR(87),
    INVALID_FOLDER_NAME_ERROR(88),
    TYPE_OF_FILE_ERROR(89),
    INVALID_FILE_LENGTH_ERROR(90),
    INVALID_FILE_DATA_ERROR(91),
    READING_PROFILES_FROM_ROM_ERROR(92),
    WRITING_PROFILES_TO_ROM_ERROR(93),
    BURNING_SAMPLE_ID_ERROR(94),
    READING_ASIC_REGISTERS_ERROR(95),
    WRITING_ASIC_REGISTERS_ERROR(96),
    READING_TEMP_ERROR(97),
    TEMP_FOLDERS_ERROR(98),
    OPTIONS_FOLDERS_ERROR(99),
    INTERPOLATION_THRESHOLD_ERROR(100),
    DELAY_COMP_MAX_COUNT_ERROR(101),
    DSP_MEMS_RESPONSE_POST_PROCESSING_ERROR(102),
    DSP_PARAMETERS_CALC_RES_FREQ_QUALITY_FACTOR_POST_PROCESSING_ERROR(103),
    DSP_PARAMETERS_CALC_FORWARD_GAIN_POST_PROCESSING_ERROR(104),
    DSP_COEFFICIENTS_CALC_POST_PROCESSING_ERROR(105),
    DSP_PHASE_VALIDATION_POST_PROCESSING_ERROR(106),
    DSP_STABILITY_CHECK_POST_PROCESSING_ERROR(107),
    DSP_GAIN_MARGIN_CALC_POST_PROCESSING_ERROR(108),
    CLOSED_LOOP_FILE_CREATION_ERROR(109),
    FAILED_IN_ADAPTIVE_GAIN(110),
    ASIC_REGISTER_READING_ERROR(111),
    TWO_POINTS_CORR_CALIB_FOLDER_ERROR(112),
    FAILED_TO_WRITE_OPTICAL_OPTION_TO_FILE(113),
    FAILED_TO_CREATE_OPTICAL_SETTINGS_FILE(114),
    STANDARD_CALIBRATOR_FILE_NOT_EXIST_ERROR(115),
    WAVELENGTH_CALIBRATION_ERROR(116),
    NO_VALID_OLD_MEASUREMENT_ERROR(117),
    DSP_UPDATE_FFT_SETTINGS_ERROR(118),
    GAIN_OPTIONS_ERROR(119),
    DSP_COMMON_WAVENUMBER_GENERATION_ERROR(120);
    
    private final int a;
    
    p2AppManagerStatus(int param1Int1) { this.a = param1Int1; }
    
    public int getNumVal() { return this.a; }
    
    public static p2AppManagerStatus getAppManagerStatusByCode(int param1Int) {
      for (p2AppManagerStatus p2AppManagerStatus1 : values()) {
        if (p2AppManagerStatus1.getNumVal() == param1Int)
          return p2AppManagerStatus1; 
      } 
      return UNKNOWN_ERROR;
    }
  }
  
  public enum p2DeviceAction {
    initializeCore(0),
    RunInterSpec(1),
    RunSpecBackground(2),
    RunSpecSample(3),
    SetActuation(4),
    CheckBoardStatus(5),
    RunCapCurrent(6),
    RunCapTimeCalibration(7),
    RunDelayCompensation(8),
    RunCalibration(9),
    GenerateCalibration(10),
    BurnSampleID(11),
    BurnSampleFolders(12),
    ReadTemp(13),
    ReadASICRegisters(14),
    WriteASICRegisters(15),
    ReadSampleFolders(16),
    CalculateResponse(17),
    CalculateParameters(18),
    TrimCoefficients(19),
    TrimPhase(20),
    CheckStability(21),
    RunWaveform(22),
    RunGainAdjustInterSpec(23),
    RunSNR(24),
    RunSelfCorr(25),
    RunWavelengthCalibration(26),
    RunStability(27),
    RunGainAdjustSpecBG(28),
    RunGainAdjustSpecSample(29),
    RunWavelengthCalibrationBG(30),
    RunUpdateFFT_SettingsInterSpec(31),
    RunUpdateFFT_SettingsSpec(32),
    RestoreDefaultSettings(33),
    BurnWorkingSettings(34),
    TrimPhaseFast(35);
    
    private final int a;
    
    p2DeviceAction(int param1Int1) { this.a = param1Int1; }
    
    public int getNumVal() { return this.a; }
  }
  
  public enum p2AppManagerState {
    Idle(0),
    Initialize(1, p2Enumerations.p2DeviceAction.initializeCore),
    InterferogramRun(2, p2Enumerations.p2DeviceAction.RunInterSpec),
    SpectroscopySampleRun(3, p2Enumerations.p2DeviceAction.RunSpecSample),
    SpectroscopyBackgroundRun(4, p2Enumerations.p2DeviceAction.RunSpecBackground),
    ActuationProfileSetting(5, p2Enumerations.p2DeviceAction.SetActuation),
    CheckingDeviceStatus(6, p2Enumerations.p2DeviceAction.CheckBoardStatus),
    CapCurrentRun(7, p2Enumerations.p2DeviceAction.RunCapCurrent),
    CalibrationCapVsTimeRun(8, p2Enumerations.p2DeviceAction.RunCapTimeCalibration),
    CalibrationDelayCompensationRun(9, p2Enumerations.p2DeviceAction.RunDelayCompensation),
    CalibrationCoreRun(10, p2Enumerations.p2DeviceAction.RunCalibration),
    CalibrationGeneration(11, p2Enumerations.p2DeviceAction.GenerateCalibration),
    SampleIDBurn(12, p2Enumerations.p2DeviceAction.BurnSampleID),
    SampleFoldersBurn(13, p2Enumerations.p2DeviceAction.BurnSampleFolders),
    TempReading(14, p2Enumerations.p2DeviceAction.ReadTemp),
    ASICRegistersReading(15, p2Enumerations.p2DeviceAction.ReadASICRegisters),
    ASICRegistersWriting(16, p2Enumerations.p2DeviceAction.WriteASICRegisters),
    SampleFoldersReading(17, p2Enumerations.p2DeviceAction.ReadSampleFolders),
    ResponseCalculation(18, p2Enumerations.p2DeviceAction.CalculateResponse),
    ParametersCalculation(19, p2Enumerations.p2DeviceAction.CalculateParameters),
    CoefficientsTrimming(20, p2Enumerations.p2DeviceAction.TrimCoefficients),
    PhaseTrimming(21, p2Enumerations.p2DeviceAction.TrimPhase),
    StabilityCheck(22, p2Enumerations.p2DeviceAction.CheckStability),
    WaveformPreview(23, p2Enumerations.p2DeviceAction.RunWaveform),
    gainAdjustInterSpecRun(24, p2Enumerations.p2DeviceAction.RunGainAdjustInterSpec),
    SNR_Run(25, p2Enumerations.p2DeviceAction.RunSNR),
    selfCorr_Run(26, p2Enumerations.p2DeviceAction.RunSelfCorr),
    wavelengthCalibration_Run(27, p2Enumerations.p2DeviceAction.RunWavelengthCalibration),
    StabilityRun(28, p2Enumerations.p2DeviceAction.RunStability),
    gainAdjustSpecBG_Run(29, p2Enumerations.p2DeviceAction.RunGainAdjustSpecBG),
    gainAdjustSpecSampleRun(30, p2Enumerations.p2DeviceAction.RunGainAdjustSpecSample),
    wavelengthCalibrationBG_Run(31, p2Enumerations.p2DeviceAction.RunWavelengthCalibrationBG),
    updateFFT_SettingsInterSpecRun(32, p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsInterSpec),
    updateFFT_SettingsSpecRun(33, p2Enumerations.p2DeviceAction.RunUpdateFFT_SettingsSpec),
    RestoreDefault(34, p2Enumerations.p2DeviceAction.RestoreDefaultSettings),
    BurnSettings(35, p2Enumerations.p2DeviceAction.BurnWorkingSettings),
    FastPhaseTrimming(36, p2Enumerations.p2DeviceAction.TrimPhaseFast);
    
    private final int a;
    
    private final p2Enumerations.p2DeviceAction b;
    
    p2AppManagerState(int param1Int1) {
      this.a = param1Int1;
      this.b = null;
    }
    
    p2AppManagerState(p2Enumerations.p2DeviceAction param1p2DeviceAction1, p2Enumerations.p2DeviceAction param1p2DeviceAction2) {
      this.a = param1p2DeviceAction1;
      this.b = param1p2DeviceAction2;
    }
    
    public int getNumVal() { return this.a; }
    
    public p2Enumerations.p2DeviceAction getDeviceAtion() { return this.b; }
  }
  
  public enum p2CorrectionType {
    Corrected(0),
    Uncorrected(1);
    
    private final int a;
    
    p2CorrectionType(int param1Int1) { this.a = param1Int1; }
    
    public int getNumVal() { return this.a; }
  }
  
  public enum RestoreOptionsEnum {
    OPTICAL_GAIN_SETTINGS(0, "Optical gain settings"),
    CORRECTION_SETTINGS(1, "Correction settings"),
    ALL(3, "All");
    
    private final int a;
    
    private final String b;
    
    RestoreOptionsEnum(String param1String1, String param1String2) {
      this.a = param1String1;
      this.b = param1String2;
    }
    
    public int getNumVal() { return this.a; }
    
    public String getStringVal() { return this.b; }
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManage\\utils\p2Enumerations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */