package sws.p2AppManager.utils;

public class p2DeviceNotificationResult {
  private p2Enumerations.p2DeviceAction a;
  
  private String b;
  
  private p2Enumerations.p2AppManagerStatus c;
  
  public p2Enumerations.p2DeviceAction getAction() { return this.a; }
  
  public void setAction(p2Enumerations.p2DeviceAction paramp2DeviceAction) { this.a = paramp2DeviceAction; }
  
  public String getDeviceId() { return this.b; }
  
  public void setDeviceId(String paramString) { this.b = paramString; }
  
  public p2Enumerations.p2AppManagerStatus getStatus() { return this.c; }
  
  public void setStatus(p2Enumerations.p2AppManagerStatus paramp2AppManagerStatus) { this.c = paramp2AppManagerStatus; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\p2AppManager.jar!\sws\p2AppManage\\utils\p2DeviceNotificationResult.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */