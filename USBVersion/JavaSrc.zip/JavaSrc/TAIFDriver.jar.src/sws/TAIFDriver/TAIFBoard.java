package sws.TAIFDriver;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.apache.log4j.Logger;
import sws.TAIFDriver.a.a;
import sws.TAIFDriver.a.b;
import sws.TAIFDriver.a.c;
import sws.TAIFDriver.a.d;
import sws.TAIFDriver.a.e;
import sws.TAIFDriver.a.f;
import sws.TAIFDriver.a.g;
import sws.TAIFDriver.a.h;
import sws.TAIFDriver.a.i;
import sws.TAIFDriver.a.j;
import sws.TAIFDriver.a.k;
import sws.TAIFDriver.b.a;
import sws.TAIFDriver.c.a;

public class TAIFBoard {
  private static Logger b = Logger.getLogger(TAIFBoard.class);
  
  private String c;
  
  private int d;
  
  private int e;
  
  private boolean f = false;
  
  public String a;
  
  private native int cyDriver_init();
  
  private native int cyDriver_connect(short paramShort, byte[] paramArrayOfByte);
  
  private native int cyDriver_close();
  
  private native int cyDriver_dataOutTransfer(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte);
  
  private native int cyDriver_asyncDataOutTransfer(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte);
  
  private native int cyDriver_dataInTransfer(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte);
  
  private native int cyDriver_asyncDataInTransfer(int paramInt1, int paramInt2, int paramInt3);
  
  private native int cyDriver_asyncDataInGetData(byte[] paramArrayOfByte);
  
  private native int cyDriver_controlOutTransfer(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte);
  
  private native int cyDriver_controlInTransfer(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte);
  
  private native int cyDriver_selfTest();
  
  private native double cyDriver_getDataInProgress();
  
  private native double cyDriver_getDataOutProgress();
  
  private native double cyDriver_getControlInProgress();
  
  private native double cyDriver_getControlOutProgress();
  
  private native byte cyDriver_isAsyncDataInDone();
  
  private native byte cyDriver_isAsyncDataOutDone();
  
  private native int cyDriver_getAsyncDataInErrorCode();
  
  private native int cyDriver_getAsyncDataOutErrorCode();
  
  private native int cyDriver_resetDevice();
  
  private native int cyDriver_checkDeviceStatus(short paramShort);
  
  private native void cyDriver_setDataTimeoutMilliSec(int paramInt);
  
  private native void cyDriver_setControlTimeoutMilliSec(short paramShort);
  
  public TAIFBoard(int paramInt) {
    this.e = paramInt;
    this.a = System.getProperty("user.dir");
    cyDriver_init();
  }
  
  public TAIFBoard(int paramInt, String paramString) {
    this.e = paramInt;
    this.a = paramString;
    cyDriver_init();
  }
  
  public void a(boolean... paramVarArgs) throws a {
    b.info("initiateBoard method :: Start");
    long l = 0L;
    try {
      if (paramVarArgs == null) {
        l = a(c.i.a(), e.i.a(), d.i.a());
      } else if (paramVarArgs[0] == true) {
        l = 0L;
      } else {
        l = a(c.i.a(), e.i.a(), d.i.a());
      } 
      if (l == 0L) {
        this.f = false;
        throw new Exception();
      } 
      this.f = true;
    } catch (Exception exception) {
      this.f = false;
      e();
      cyDriver_close();
      byte[] arrayOfByte = new byte[this.a.getBytes(StandardCharsets.US_ASCII).length + 1];
      System.arraycopy(this.a.getBytes(StandardCharsets.US_ASCII), 0, arrayOfByte, 0, this.a.getBytes(StandardCharsets.US_ASCII).length);
      arrayOfByte[arrayOfByte.length - 1] = 0;
      int i = cyDriver_connect((short)this.e, arrayOfByte);
      if (i != b.a.a()) {
        b b1 = b.a(i);
        b.error("calling cyDriver_connect has failed with error code returned" + b1);
        throw new a("calling cyDriver_connect has failed with error code returned" + b1, b1);
      } 
      int j = cyDriver_selfTest();
      if (j == b.a.a()) {
        f();
        try {
          if (paramVarArgs[1] == true) {
            System.out.println("Stopping initialization after loading FW");
            return;
          } 
        } catch (Exception exception1) {}
        h();
        this.f = true;
      } else {
        b b1 = b.a(j);
        b.error("calling cyDriver_selfTest() has failed with error code " + b1);
        throw new a("calling cyDriver_selfTest() has failed with error code " + b1, b1);
      } 
    } 
    b.info("initiateBoard method :: END");
  }
  
  public int a() {
    int i = cyDriver_checkDeviceStatus((short)this.e);
    b.info(Integer.valueOf(i));
    b.info(Boolean.valueOf(this.f));
    if (i == b.a.a() && !this.f) {
      b.error("check board status succeeded from cyDriver side, but the initialization from TAIFBoardDriver side has failed ");
      i = b.aa.a();
    } 
    if (i != b.a.a() && i != b.aa.a() && i != b.g.a()) {
      b b1 = b.a(i);
      b.error("Calling cyDriver_checkDeviceStatus() method has returned unexpected error code " + b1);
      throw new a("Calling cyDriver_checkDeviceStatus() method has returned unexpected error code " + b1, b1);
    } 
    if (i == b.aa.a() || i == b.g.a())
      this.f = false; 
    return i;
  }
  
  public byte a(int paramInt) throws a, InterruptedException {
    b.info("TAIFBoard - readEEPROM(int address) :: Start :: address = " + paramInt);
    int i = b.a.a();
    byte[] arrayOfByte1 = a(g.a);
    byte[] arrayOfByte2 = a(g.a);
    arrayOfByte1[1] = (byte)f.e.a();
    arrayOfByte1[2] = a.a(paramInt)[0];
    arrayOfByte1[3] = a.a(paramInt)[1];
    if (arrayOfByte1[3] == 0 && (arrayOfByte1[2] == 0 || arrayOfByte1[2] == 1 || arrayOfByte1[2] == 2 || arrayOfByte1[2] == 3 || arrayOfByte1[2] == 4 || arrayOfByte1[2] == 5 || arrayOfByte1[2] == 6 || arrayOfByte1[2] == 7)) {
      b.error("TAIFBoard - readEEPROM(int address):: Error : illegalMemoryWritingAddress");
      throw new a("TAIFBoard - readEEPROM(int address):: Error : illegalMemoryWritingAddress", b.ae);
    } 
    i = cyDriver_controlOutTransfer(64, 64, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b3 = b.a(i);
      b.error("TAIFBoard - readEEPROM(int address):: Error : " + b3);
      throw new a("TAIFBoard - readEEPROM(int address):: Error : " + b3, b3);
    } 
    Thread.sleep(5L);
    i = cyDriver_controlInTransfer(64, 64, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b3 = b.a(i);
      b.error("TAIFBoard - readEEPROM(int address):: Error : " + b3);
      throw new a("TAIFBoard - readEEPROM(int address):: Error : " + b3, b3);
    } 
    for (byte b2 = 0; b2 < 12; b2++) {
      if (arrayOfByte2[b2] != arrayOfByte1[b2]) {
        b.error("TAIFBoard - readEEPROM(int address):: Error: out packet and in packet headers don't match");
        throw new a("TAIFBoard - readEEPROM(int address):: Error: out packet and in packet headers don't match", b.ab);
      } 
    } 
    byte b1 = arrayOfByte2[12];
    b.info("TAIFBoard - readEEPROM(int address) :: END :: value = " + b1);
    return b1;
  }
  
  public byte[] a(int paramInt1, int paramInt2) throws a, InterruptedException {
    int k;
    int j;
    byte b1;
    b.info("TAIFBoard - readEEPROM(int address, int size) :: START :: address= " + paramInt1 + ", size=" + paramInt2);
    int i = b.a.a();
    byte[] arrayOfByte = new byte[paramInt2];
    if (paramInt2 <= 32) {
      b1 = 0;
      k = 1;
      j = paramInt2;
    } else {
      b1 = 32;
      k = (int)Math.ceil(paramInt2 / 32.0D);
      j = 32 - k * 32 - paramInt2;
    } 
    b.info("TAIFBoard - readEEPROM(int address, int size) :: dataSizePerPacket= " + b1 + ", noPackets=" + k + ", dataSizePerLastPacket= " + j);
    int m = paramInt1;
    for (byte b2 = 0; b2 < k; b2++) {
      int n;
      b.info("TAIFBoard - readEEPROM(int address, int size) :: packet " + b2);
      byte[] arrayOfByte1 = a(g.a);
      byte[] arrayOfByte2 = a(g.a);
      arrayOfByte1[1] = (byte)f.e.a();
      arrayOfByte1[2] = a.a(m)[0];
      arrayOfByte1[3] = a.a(m)[1];
      if (arrayOfByte1[3] == 0 && (arrayOfByte1[2] == 0 || arrayOfByte1[2] == 1 || arrayOfByte1[2] == 2 || arrayOfByte1[2] == 3 || arrayOfByte1[2] == 4 || arrayOfByte1[2] == 5 || arrayOfByte1[2] == 6 || arrayOfByte1[2] == 7)) {
        b.error("TAIFBoard - readEEPROM(int address, int size) :: Illegal Memory Writing Address");
        throw new a("TAIFBoard - readEEPROM(int address, int size) :: Illegal Memory Writing Address", b.ae);
      } 
      if (b2 < k - 1) {
        n = b1;
      } else {
        n = j;
      } 
      m += n;
      arrayOfByte1[4] = a.a(n)[0];
      i = cyDriver_controlOutTransfer(64, 64, 1, arrayOfByte1);
      if (i != b.a.a()) {
        b b4 = b.a(i);
        b.error("TAIFBoard - readEEPROM(int address, int size) :: " + b4);
        throw new a("TAIFBoard - readEEPROM(int address, int size) :: " + b4, b4);
      } 
      Thread.sleep(5L);
      i = cyDriver_controlInTransfer(64, 64, 1, arrayOfByte2);
      if (i != b.a.a()) {
        b b4 = b.a(i);
        b.error("TAIFBoard - readEEPROM(int address, int size) :: " + b4);
        throw new a("TAIFBoard - readEEPROM(int address, int size) :: " + b4, b4);
      } 
      byte b3;
      for (b3 = 0; b3 < 12; b3++) {
        if (arrayOfByte2[b3] != arrayOfByte1[b3]) {
          b.error("TAIFBoard - readEEPROM(int address, int size) :: OUT and IN packets have Difffenet headers");
          throw new a("TAIFBoard - readEEPROM(int address, int size) :: OUT and IN packets have Difffenet headers", b.ab);
        } 
      } 
      for (b3 = 0; b3 < n; b3++)
        arrayOfByte[b2 * b1 + b3] = arrayOfByte2[12 + b3]; 
    } 
    b.info("TAIFBoard - readEEPROM(int address, int size) :: END : value = " + new String(arrayOfByte, Charset.forName("US-ASCII")));
    return arrayOfByte;
  }
  
  public void a(int paramInt, byte paramByte) throws a, InterruptedException {
    b.info("TAIFBoard - writeEEPROM(int address, byte value) :: START : address = " + paramInt + ", value = " + paramByte);
    int i = b.a.a();
    byte[] arrayOfByte1 = a(g.a);
    byte[] arrayOfByte2 = a(g.a);
    arrayOfByte1[1] = (byte)f.d.a();
    byte[] arrayOfByte3 = a.a(paramInt);
    arrayOfByte1[2] = arrayOfByte3[0];
    arrayOfByte1[3] = arrayOfByte3[1];
    arrayOfByte1[12] = paramByte;
    if (arrayOfByte1[3] == 0 && (arrayOfByte1[2] == 0 || arrayOfByte1[2] == 1 || arrayOfByte1[2] == 2 || arrayOfByte1[2] == 3 || arrayOfByte1[2] == 4 || arrayOfByte1[2] == 5 || arrayOfByte1[2] == 6 || arrayOfByte1[2] == 7)) {
      b.error("TAIFBoard - writeEEPROM(int address, byte value) :: " + b.ae);
      throw new a("TAIFBoard - writeEEPROM(int address, byte value) :: " + b.ae, b.ae);
    } 
    i = cyDriver_controlOutTransfer(64, 64, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("TAIFBoard - writeEEPROM(int address, byte value) :: " + b2);
      throw new a("TAIFBoard - writeEEPROM(int address, byte value) :: " + b2, b2);
    } 
    Thread.sleep(5L);
    i = cyDriver_controlInTransfer(64, 64, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("TAIFBoard - writeEEPROM(int address, byte value) :: " + b2);
      throw new a("TAIFBoard - writeEEPROM(int address, byte value) :: " + b2, b2);
    } 
    for (byte b1 = 0; b1 < 12; b1++) {
      if (arrayOfByte2[b1] != arrayOfByte1[b1]) {
        b.error("TAIFBoard - writeEEPROM(int address, byte value) :: OUT and IN packets have different headers");
        throw new a("TAIFBoard - writeEEPROM(int address, byte value) :: OUT and IN packets have different headers", b.ab);
      } 
    } 
    b.info("TAIFBoard - writeEEPROM(int address, byte value :: END");
  }
  
  public void a(int paramInt1, int paramInt2, byte[] paramArrayOfByte) throws a, InterruptedException {
    int k;
    int j;
    byte b1;
    b.info("TAIFBoard - writeEEPROM(int pAddress, int size, byte[] value) :: START : address = " + paramInt1 + ", size = " + paramInt2 + ", value = " + new String(paramArrayOfByte, Charset.forName("US-ASCII")));
    int i = b.a.a();
    if (paramInt2 <= 32) {
      b1 = 0;
      k = 1;
      j = paramInt2;
    } else {
      b1 = 32;
      k = (int)Math.ceil(paramInt2 / 32.0D);
      j = 32 - k * 32 - paramInt2;
    } 
    int m = paramInt1;
    for (byte b2 = 0; b2 < k; b2++) {
      int n;
      byte[] arrayOfByte1 = a(g.a);
      byte[] arrayOfByte2 = a(g.a);
      byte[] arrayOfByte3 = a(g.a);
      byte[] arrayOfByte4 = a(g.a);
      arrayOfByte1[1] = (byte)f.d.a();
      arrayOfByte3[1] = (byte)f.e.a();
      byte[] arrayOfByte5 = a.a(m);
      arrayOfByte1[2] = arrayOfByte5[0];
      arrayOfByte1[3] = arrayOfByte5[1];
      arrayOfByte3[2] = arrayOfByte5[0];
      arrayOfByte3[3] = arrayOfByte5[1];
      if (arrayOfByte1[3] == 0 && (arrayOfByte1[2] == 0 || arrayOfByte1[2] == 1 || arrayOfByte1[2] == 2 || arrayOfByte1[2] == 3 || arrayOfByte1[2] == 4 || arrayOfByte1[2] == 5 || arrayOfByte1[2] == 6 || arrayOfByte1[2] == 7)) {
        b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ae);
        throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ae, b.ae);
      } 
      if (arrayOfByte1[3] == 0 && (arrayOfByte1[2] == 0 || arrayOfByte1[2] == 1 || arrayOfByte1[2] == 2 || arrayOfByte1[2] == 3 || arrayOfByte1[2] == 4 || arrayOfByte1[2] == 5 || arrayOfByte1[2] == 6 || arrayOfByte1[2] == 7)) {
        b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ae);
        throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ae, b.ae);
      } 
      if (b2 < k - 1) {
        n = b1;
      } else {
        n = j;
      } 
      if (arrayOfByte1[3] != a.a(m + n - 1)[1] || (arrayOfByte1[2] & 0xC0) != (a.a(m + n - 1)[0] & 0xC0)) {
        b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ae);
        throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ae, b.ae);
      } 
      arrayOfByte1[4] = a.a(n)[0];
      arrayOfByte3[4] = a.a(n)[0];
      byte b3;
      for (b3 = 0; b3 < n; b3++)
        arrayOfByte1[12 + b3] = paramArrayOfByte[b2 * b1 + b3]; 
      i = cyDriver_controlOutTransfer(64, 64, 1, arrayOfByte1);
      if (i != b.a.a()) {
        b b4 = b.a(i);
        b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4);
        throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4, b4);
      } 
      Thread.sleep(5L);
      i = cyDriver_controlInTransfer(64, 64, 1, arrayOfByte2);
      if (i != b.a.a()) {
        b b4 = b.a(i);
        b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4);
        throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4, b4);
      } 
      for (b3 = 0; b3 < 12; b3++) {
        if (arrayOfByte2[b3] != arrayOfByte1[b3]) {
          b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ab);
          throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ab, b.ab);
        } 
      } 
      Thread.sleep(5L);
      cyDriver_controlOutTransfer(64, 64, 1, arrayOfByte3);
      if (i != b.a.a()) {
        b b4 = b.a(i);
        b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4);
        throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4, b4);
      } 
      Thread.sleep(5L);
      cyDriver_controlInTransfer(64, 64, 1, arrayOfByte4);
      if (i != b.a.a()) {
        b b4 = b.a(i);
        b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4);
        throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b4, b4);
      } 
      for (b3 = 0; b3 < 12; b3++) {
        if (arrayOfByte4[b3] != arrayOfByte3[b3]) {
          b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ab);
          throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.ab, b.ab);
        } 
      } 
      for (b3 = 0; b3 < n; b3++) {
        if (arrayOfByte4[12 + b3] != paramArrayOfByte[b2 * b1 + b3]) {
          b.error("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.am);
          throw new a("TAIFBoard - WriteEEPROM(int pAddress, int size, byte[] value) :: " + b.am, b.am);
        } 
      } 
      m += n;
    } 
    b.info("TAIFBoard - writeEEPROM(int pAddress, int size, byte[] value) :: END");
  }
  
  public void b() throws a {
    byte[] arrayOfByte1 = a(g.b);
    byte[] arrayOfByte2 = a(g.b);
    arrayOfByte1[1] = (byte)f.k.a();
    int i = cyDriver_dataOutTransfer(arrayOfByte1.length, arrayOfByte1.length, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_dataOutTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_dataOutTransfer() has failed with error code " + b1, b1);
    } 
    i = cyDriver_dataInTransfer(arrayOfByte2.length, arrayOfByte2.length, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_dataInTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_dataInTransfer() has failed with error code " + b1, b1);
    } 
  }
  
  public long a(int paramInt1, int paramInt2, int paramInt3) throws a {
    b.info("readFPGARegister method :: Start");
    long l1 = c(paramInt1);
    long l2 = a(l1, paramInt2, paramInt3);
    b.info("readFPGARegister method :: End");
    return l2;
  }
  
  public void a(int paramInt1, long paramLong, int paramInt2, int paramInt3) throws a {
    b.info("writeFPGARegister method :: Start");
    long l1 = c(paramInt1);
    long l2 = a(l1, paramLong, paramInt2, paramInt3);
    a(paramInt1, l2);
    b.info("writeFPGARegister method :: End");
  }
  
  public long b(int paramInt1, int paramInt2, int paramInt3) throws a {
    b.info("readASICRegister method :: Start");
    int i = b(paramInt1);
    long l1 = d(i);
    long l2 = a(l1, paramInt2, paramInt3);
    b.info("readASICRegister method :: END");
    return l2;
  }
  
  public void b(int paramInt1, long paramLong, int paramInt2, int paramInt3) throws a {
    b.info("writeASICRegister method :: Start");
    int i = b(paramInt1);
    long l1 = d(i);
    long l2 = a(l1, paramLong, paramInt2, paramInt3);
    b(i, l2);
    b.info("writeASICRegister method :: END");
  }
  
  public void a(long[] paramArrayOfLong) throws a {
    b.info("writeAllASICRegisters method :: Start");
    for (byte b1 = 0; b1 < 89; b1++) {
      int i = b(b1);
      b(i, paramArrayOfLong[b1]);
    } 
    b.info("writeAllASICRegisters method :: END");
  }
  
  public long[] c() throws a {
    b.info("readAllASICRegisters method :: Start");
    long[] arrayOfLong = new long[89];
    for (byte b1 = 0; b1 < 89; b1++) {
      int i = b(b1);
      arrayOfLong[b1] = d(i);
    } 
    b.info("readAllASICRegisters method :: END");
    return arrayOfLong;
  }
  
  public void d() throws a {
    b.info("resetFIFOs method :: Start");
    i();
    b();
    b.info("resetFIFOs method :: End");
  }
  
  public byte[] b(int paramInt1, int paramInt2) throws a, InterruptedException {
    b.info("streamIn method :: Start");
    b();
    cyDriver_setDataTimeoutMilliSec(paramInt2 + 5000);
    int i = cyDriver_asyncDataInTransfer(paramInt1, 512, 50);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1, b1);
    } 
    p();
    b.info("Finish submit in transfers");
    while (cyDriver_isAsyncDataInDone() == 0)
      b.info("wait for transfers to finish"); 
    b.info("streaming finished");
    b();
    byte[] arrayOfByte1 = new byte[paramInt1];
    i = cyDriver_asyncDataInGetData(arrayOfByte1);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInGetData() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInGetData() has failed with error code " + b1, b1);
    } 
    a(c.V.a(), 0L, e.V.a(), d.V.a());
    byte[] arrayOfByte2 = a(arrayOfByte1);
    b.info("streamIn method :: End");
    b.info("handleStreamInCompletedAction finished");
    return arrayOfByte2;
  }
  
  public byte[] c(int paramInt1, int paramInt2) throws a, InterruptedException {
    b.info("streamIn method :: Start");
    cyDriver_setDataTimeoutMilliSec(paramInt2 + 5000);
    int i = cyDriver_asyncDataInTransfer(paramInt1, 512, 50);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1, b1);
    } 
    p();
    b.info("Finish submit in transfers");
    while (cyDriver_isAsyncDataInDone() == 0)
      b.info("wait for transfers to finish"); 
    b.info("streaming finished");
    byte[] arrayOfByte = new byte[paramInt1];
    i = cyDriver_asyncDataInGetData(arrayOfByte);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInGetData() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInGetData() has failed with error code " + b1, b1);
    } 
    return arrayOfByte;
  }
  
  public byte[] d(int paramInt1, int paramInt2) throws a, InterruptedException {
    b.info("streamIn method :: Start");
    b();
    cyDriver_setDataTimeoutMilliSec(paramInt2 + 5000);
    int i = cyDriver_asyncDataInTransfer(paramInt1, 512, 512);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1, b1);
    } 
    p();
    b.info("Finish submit in transfers");
    while (cyDriver_isAsyncDataInDone() == 0)
      b.info("wait for transfers to finish"); 
    b.info("streaming finished");
    b();
    byte[] arrayOfByte1 = new byte[paramInt1];
    i = cyDriver_asyncDataInGetData(arrayOfByte1);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInGetData() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInGetData() has failed with error code " + b1, b1);
    } 
    a(c.w.a(), 0L, e.w.a(), d.w.a());
    byte[] arrayOfByte2 = a(arrayOfByte1);
    b.info("streamIn method :: End");
    b.info("handleStreamInCompletedAction finished");
    return arrayOfByte2;
  }
  
  public byte[] e(int paramInt1, int paramInt2) throws a, InterruptedException {
    b.info("streamInActualDMux method :: Start");
    b();
    cyDriver_setDataTimeoutMilliSec(paramInt2 + 5000);
    int i = cyDriver_asyncDataInTransfer(paramInt1, 512, 512);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInTransfer() has failed with error code " + b1, b1);
    } 
    p();
    b.info("Finish submit in transfers");
    while (cyDriver_isAsyncDataInDone() == 0)
      b.info("wait for transfers to finish"); 
    b.info("streaming finished");
    b();
    byte[] arrayOfByte1 = new byte[paramInt1];
    i = cyDriver_asyncDataInGetData(arrayOfByte1);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_asyncDataInGetData() has failed with error code " + b1);
      throw new a("calling cyDriver_asyncDataInGetData() has failed with error code " + b1, b1);
    } 
    a(c.v.a(), 0L, e.v.a(), d.v.a());
    byte[] arrayOfByte2 = a(arrayOfByte1);
    b.info("streamIn method :: End");
    b.info("handleStreamInCompletedAction finished");
    return arrayOfByte2;
  }
  
  private void e() throws a {
    String str = this.a;
    int i = 0;
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader(str + File.separatorChar + "Data" + File.separatorChar + "LargeBinary.dat"));
      i = Integer.parseInt(bufferedReader.readLine());
      bufferedReader.close();
    } catch (IOException iOException) {
      b.error(iOException.getMessage());
    } 
    if (i == 1) {
      b.info("Loading large binary file from directory: " + str);
      this.c = str + File.separatorChar + "TAIF_Binary" + File.separatorChar + "carma_top_large.bin";
      this.d = 464196;
    } else {
      b.info("Loading small binary file from directory: " + str);
      this.c = str + File.separatorChar + "TAIF_Binary" + File.separatorChar + "carma_top.bin";
      this.d = 169216;
    } 
  }
  
  private void f() throws a {
    byte b1 = g();
    if (b1 != 3) {
      b.error("Firmware version mismatch, FW version read from cyDriver " + b1 + " doesn't match " + '\003');
      throw new a("Firmware version mismatch", b.ag);
    } 
  }
  
  private byte g() {
    byte b1 = 0;
    byte[] arrayOfByte1 = a(g.a);
    byte[] arrayOfByte2 = a(g.a);
    arrayOfByte1[1] = (byte)f.f.a();
    int i = cyDriver_controlOutTransfer(arrayOfByte1.length, arrayOfByte1.length, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b3 = b.a(i);
      b.error("calling cyDriver_controlOutTransfer() has failed with error code" + b3);
      throw new a("calling cyDriver_controlOutTransfer() has failed with error code" + b3, b3);
    } 
    i = cyDriver_controlInTransfer(arrayOfByte2.length, arrayOfByte2.length, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b3 = b.a(i);
      b.error("calling cyDriver_controlInTransfer() has failed with error code " + b3);
      throw new a("calling cyDriver_controlInTransfer() has failed with error code " + b3, b3);
    } 
    for (byte b2 = 0; b2 < 12; b2++) {
      if (arrayOfByte2[b2] != arrayOfByte1[b2]) {
        b.error("readFWVersion() :: out packet and in packet headers don't match");
        throw new a("readFWVersion() :: out packet and in packet headers don't match", b.ab);
      } 
    } 
    b1 = arrayOfByte2[12];
    b.info("FW Version returned from cyDriver library: " + b1);
    return b1;
  }
  
  private byte[] a(g paramg) throws a {
    byte[] arrayOfByte = null;
    switch (null.a[paramg.ordinal()]) {
      case 1:
        arrayOfByte = new byte[64];
        arrayOfByte[0] = (byte)g.a.a();
        return arrayOfByte;
      case 2:
        arrayOfByte = new byte[64];
        arrayOfByte[0] = (byte)g.b.a();
        return arrayOfByte;
      case 3:
        arrayOfByte = new byte[512];
        arrayOfByte[0] = (byte)g.c.a();
        return arrayOfByte;
    } 
    b.error("unexpected packet type : " + paramg + ", failed to create packet");
    throw new a("unexpected packet type : " + paramg + ", failed to create packet", b.ar);
  }
  
  private void h() throws a {
    int i = (int)Math.ceil(this.d / 500.0D);
    i();
    byte[] arrayOfByte1 = j();
    int j = (int)(Math.ceil(i / 3.0D) * 3.0D);
    byte[] arrayOfByte2 = a(g.a);
    byte[] arrayOfByte3 = a(g.a);
    byte[] arrayOfByte4 = a.a(j);
    arrayOfByte2[1] = (byte)f.a.a();
    arrayOfByte2[2] = arrayOfByte4[0];
    arrayOfByte2[3] = arrayOfByte4[1];
    int k = cyDriver_controlOutTransfer(arrayOfByte2.length, arrayOfByte2.length, 1, arrayOfByte2);
    if (k != b.a.a()) {
      b b5 = b.a(k);
      b.error("calling cyDriver_controlOutTransfer() has failed with error code " + b5);
      throw new a("calling cyDriver_controlOutTransfer() has failed with error code " + b5, b5);
    } 
    k = cyDriver_controlInTransfer(arrayOfByte3.length, arrayOfByte3.length, 1, arrayOfByte3);
    if (k != b.a.a()) {
      b b5 = b.a(k);
      b.error("calling cyDriver_controlInTransfer() has failed with error code " + b5);
      throw new a("calling cyDriver_controlInTransfer() has failed with error code " + b5, b5);
    } 
    int m;
    for (m = 0; m < 12; m++) {
      if (arrayOfByte3[m] != arrayOfByte2[m]) {
        b.error("programFpga() :: out packet and in packet headers don't match");
        throw new a("programFpga() :: out packet and in packet headers don't match", b.ab);
      } 
    } 
    m = j * 512;
    byte[] arrayOfByte5 = new byte[m];
    byte b1 = 0;
    byte b2 = 0;
    byte b3 = 0;
    for (byte b4 = 0; b4 < i; b4++) {
      byte[] arrayOfByte = a.a(b3);
      arrayOfByte5[b2 + false] = (byte)g.c.a();
      arrayOfByte5[b2 + true] = (byte)f.o.a();
      arrayOfByte5[b2 + 2] = arrayOfByte[0];
      arrayOfByte5[b2 + 3] = arrayOfByte[1];
      arrayOfByte5[b2 + 4] = arrayOfByte[2];
      b2 += true;
      for (byte b5 = 0; b5 < 'Ǵ' && b1 < arrayOfByte1.length; b5++)
        arrayOfByte5[b2++] = arrayOfByte1[b1++]; 
      b3++;
    } 
    arrayOfByte1 = null;
    k = cyDriver_dataOutTransfer(arrayOfByte5.length, 512, 3, arrayOfByte5);
    if (k != b.a.a()) {
      b b5 = b.a(k);
      b.error("calling cyDriver_dataOutTransfer() has failed with error code " + b5);
      throw new a("calling cyDriver_dataOutTransfer() has failed with error code " + b5, b5);
    } 
    k();
    m();
    l();
  }
  
  private void i() throws a {
    byte[] arrayOfByte1 = a(g.a);
    byte[] arrayOfByte2 = a(g.a);
    arrayOfByte1[1] = (byte)f.i.a();
    int i = cyDriver_controlOutTransfer(arrayOfByte1.length, arrayOfByte1.length, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_controlOutTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_controlOutTransfer() has failed with error code " + b2, b2);
    } 
    i = cyDriver_controlInTransfer(arrayOfByte2.length, arrayOfByte2.length, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_controlInTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_controlInTransfer() has failed with error code " + b2, b2);
    } 
    for (byte b1 = 0; b1 < 12; b1++) {
      if (arrayOfByte2[b1] != arrayOfByte1[b1]) {
        b.error("resetMCUFifo() :: out packet and in packet headers don't match");
        throw new a("resetMCUFifo() :: out packet and in packet headers don't match", b.ab);
      } 
    } 
  }
  
  private byte[] j() throws a {
    byte[] arrayOfByte;
    File file = new File(this.c);
    if (file.exists()) {
      if (file.length() != this.d) {
        b.error("Bad FPGA binary file. FPGA configuration failed.");
        throw new a("Bad FPGA binary file. FPGA configuration failed.", b.af);
      } 
      arrayOfByte = new byte[(int)file.length()];
      try {
        FileInputStream fileInputStream = new FileInputStream(file);
        fileInputStream.read(arrayOfByte);
        fileInputStream.close();
      } catch (IOException iOException) {
        b.error("An exception has occurred while reading FPGA binary file " + this.c, iOException);
        throw new a(iOException, b.ac);
      } 
    } else {
      b.error("FPGA binary file " + this.c + "doesn't exist");
      throw new a("File doesn't exist in this location: " + this.c, b.ad);
    } 
    return arrayOfByte;
  }
  
  private void k() throws a {
    byte[] arrayOfByte = a(g.a);
    int i = cyDriver_controlInTransfer(arrayOfByte.length, arrayOfByte.length, 1, arrayOfByte);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_controlInTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_controlInTransfer() has failed with error code " + b1, b1);
    } 
    if (arrayOfByte[1] != (byte)f.c.a()) {
      b.error("inpacket[1] doesn't match " + f.c);
      throw new a("inpacket[1] doesn't match " + f.c, b.ab);
    } 
  }
  
  private void l() throws a {
    a(c.q.a(), 5L, e.q.a(), d.q.a());
    a(c.c.a(), 287L, e.c.a(), d.c.a());
    a(c.Z.a(), 287L, e.Z.a(), d.Z.a());
    b(i.cy.a(), 0L, k.cy.a(), j.cy.a());
    a(c.aa.a(), 0L, e.aa.a(), d.aa.a());
    a(c.ab.a(), 50L, e.ab.a(), d.ab.a());
    a(c.e.a(), 0L, e.e.a(), d.e.a());
    a(c.f.a(), 50L, e.f.a(), d.f.a());
    a(c.U.a(), 1L, e.U.a(), d.U.a());
    a(c.T.a(), 1L, e.T.a(), d.T.a());
  }
  
  private void m() throws a {
    n();
    d();
  }
  
  private void n() throws a {
    byte[] arrayOfByte1 = a(g.a);
    byte[] arrayOfByte2 = a(g.a);
    arrayOfByte1[1] = (byte)f.b.a();
    int i = cyDriver_controlOutTransfer(arrayOfByte1.length, arrayOfByte1.length, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_controlOutTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_controlOutTransfer() has failed with error code " + b2, b2);
    } 
    i = cyDriver_controlInTransfer(arrayOfByte2.length, arrayOfByte2.length, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_controlInTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_controlInTransfer() has failed with error code " + b2, b2);
    } 
    for (byte b1 = 0; b1 < 12; b1++) {
      if (arrayOfByte2[b1] != arrayOfByte1[b1]) {
        b.error("checkDone() :: out packet and in packet headers don't match");
        throw new a("checkDone() :: out packet and in packet headers don't match", b.ab);
      } 
    } 
    if (arrayOfByte2[12] != 1) {
      b.error("incoming packet error,inPacket[12] = " + arrayOfByte2[12] + " " + b.ai);
      throw new a("incoming packet error,inPacket[12]  = " + arrayOfByte2[12] + " " + b.ai, b.ai);
    } 
  }
  
  private long a(long paramLong, int paramInt1, int paramInt2) {
    b.info("readMask method :: Start");
    long l1 = paramLong;
    long l2 = l1 >> paramInt2;
    long l3 = (1L << paramInt1) - 1L;
    l2 &= l3;
    l2 &= 0xFFFFFFFFL;
    b.info("readMask method :: End");
    return l2;
  }
  
  private long a(long paramLong1, long paramLong2, int paramInt1, int paramInt2) {
    b.info("writeMask method :: Start");
    long l1 = paramLong1;
    long l2 = paramLong2;
    long l3 = (1L << (int)(paramInt1 + paramInt2)) - (1L << (int)paramInt2) ^ 0xFFFFFFFFFFFFFFFFL;
    l1 &= l3;
    l2 <<= paramInt2;
    l2 |= l1;
    l2 &= 0xFFFFFFFFL;
    b.info("writeMask method :: End");
    return l2;
  }
  
  private int b(int paramInt) throws a {
    b.info("getAbsAddressAndSetPage method :: Start");
    long l1 = (paramInt * 4);
    long l2 = l1 >> 7;
    long l3 = d(i.cy.a() * 4);
    long l4 = a(l3, l2, k.cy.a(), j.cy.a());
    b(i.cy.a() * 4, l4);
    long l5 = -129L;
    l1 &= l5;
    b.info("getAbsAddressAndSetPage method :: End");
    return (int)l1;
  }
  
  private long c(int paramInt) throws a {
    b.info("readFPGARow method :: Start");
    byte[] arrayOfByte1 = a(g.b);
    byte[] arrayOfByte2 = a(g.b);
    arrayOfByte1[1] = (byte)f.m.a();
    byte[] arrayOfByte3 = a.a(paramInt);
    arrayOfByte1[2] = arrayOfByte3[0];
    arrayOfByte1[3] = arrayOfByte3[1];
    arrayOfByte1[4] = arrayOfByte3[2];
    arrayOfByte1[5] = arrayOfByte3[3];
    int i = cyDriver_dataOutTransfer(arrayOfByte1.length, arrayOfByte1.length, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_dataOutTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_dataOutTransfer() has failed with error code " + b2, b2);
    } 
    i = cyDriver_dataInTransfer(arrayOfByte2.length, arrayOfByte2.length, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_dataInTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_dataInTransfer() has failed with error code " + b2, b2);
    } 
    for (byte b1 = 0; b1 < 12; b1++) {
      if (arrayOfByte2[b1] != arrayOfByte1[b1]) {
        b.error("readFPGARow(regAddress) :: out packet and in packet headers don't match");
        throw new a("readFPGARow(regAddress) :: out packet and in packet headers don't match", b.ab);
      } 
    } 
    byte[] arrayOfByte4 = new byte[8];
    arrayOfByte4[0] = arrayOfByte2[12];
    arrayOfByte4[1] = arrayOfByte2[13];
    arrayOfByte4[2] = arrayOfByte2[14];
    arrayOfByte4[3] = arrayOfByte2[15];
    arrayOfByte4[4] = 0;
    arrayOfByte4[5] = 0;
    arrayOfByte4[6] = 0;
    arrayOfByte4[7] = 0;
    ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte4);
    byteBuffer.order(ByteOrder.nativeOrder());
    b.info("readFPGARow method :: End");
    return byteBuffer.getLong(0);
  }
  
  private void a(int paramInt, long paramLong) throws a {
    b.info("writeFPGARow method :: Start");
    byte[] arrayOfByte1 = a(g.b);
    byte[] arrayOfByte2 = a(g.b);
    arrayOfByte1[1] = (byte)f.l.a();
    byte[] arrayOfByte3 = a.a(paramInt);
    arrayOfByte1[2] = arrayOfByte3[0];
    arrayOfByte1[3] = arrayOfByte3[1];
    arrayOfByte1[4] = arrayOfByte3[2];
    arrayOfByte1[5] = arrayOfByte3[3];
    byte[] arrayOfByte4 = a.a(paramLong);
    arrayOfByte1[12] = arrayOfByte4[0];
    arrayOfByte1[13] = arrayOfByte4[1];
    arrayOfByte1[14] = arrayOfByte4[2];
    arrayOfByte1[15] = arrayOfByte4[3];
    int i = cyDriver_dataOutTransfer(arrayOfByte1.length, arrayOfByte1.length, 1, arrayOfByte1);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_dataOutTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_dataOutTransfer() has failed with error code " + b2, b2);
    } 
    i = cyDriver_dataInTransfer(arrayOfByte2.length, arrayOfByte2.length, 1, arrayOfByte2);
    if (i != b.a.a()) {
      b b2 = b.a(i);
      b.error("calling cyDriver_dataInTransfer() has failed with error code " + b2);
      throw new a("calling cyDriver_dataInTransfer() has failed with error code " + b2, b2);
    } 
    for (byte b1 = 0; b1 < 12; b1++) {
      if (arrayOfByte2[b1] != arrayOfByte1[b1]) {
        b.error("writeFPGARow(regAddress,data) :: out packet and in packet headers don't match");
        throw new a("writeFPGARow(regAddress,data) :: out packet and in packet headers don't match", b.ab);
      } 
    } 
    b.info("writeFPGARow method :: End");
  }
  
  private long d(int paramInt) throws a {
    b.info("readASICRow method :: Start");
    long l1 = 127L;
    long l2 = 128L;
    long l3 = paramInt;
    l3 &= l1;
    long l4 = h.a.a() << 7;
    l4 &= l2;
    long l5 = l4 | l3;
    a(c.G.a(), l5, e.G.a(), d.G.a());
    a(c.L.a(), 0L, e.L.a(), d.L.a());
    a(c.L.a(), 1L, e.L.a(), d.L.a());
    long l6 = 0L;
    byte b1 = 0;
    do {
      l6 = a(c.F.a(), e.F.a(), d.F.a());
      b1++;
    } while (l6 == 0L && b1 < 10);
    byte[] arrayOfByte1 = new byte[8];
    long l7 = a(c.M.a(), e.M.a(), d.M.a());
    long l8 = a(c.N.a(), e.N.a(), d.N.a());
    long l9 = a(c.O.a(), e.O.a(), d.O.a());
    byte[] arrayOfByte2 = a.a(l7);
    byte[] arrayOfByte3 = a.a(l8);
    byte[] arrayOfByte4 = a.a(l9);
    arrayOfByte1[0] = arrayOfByte2[1];
    arrayOfByte1[1] = arrayOfByte3[0];
    arrayOfByte1[2] = arrayOfByte3[1];
    arrayOfByte1[3] = arrayOfByte4[0];
    arrayOfByte1[4] = 0;
    arrayOfByte1[5] = 0;
    arrayOfByte1[6] = 0;
    arrayOfByte1[7] = 0;
    ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte1);
    byteBuffer.order(ByteOrder.nativeOrder());
    b.info("readASICRow method :: End");
    return byteBuffer.getLong(0);
  }
  
  private void b(int paramInt, long paramLong) throws a {
    b.info("writeASICRow method :: Start");
    long l1 = 0L;
    byte b1 = 0;
    do {
      l1 = a(c.F.a(), e.F.a(), d.F.a());
      b1++;
    } while (l1 == 0L && b1 < 10);
    byte[] arrayOfByte = a.a(paramLong);
    long l2 = 65280L;
    long l3 = 255L;
    long l4 = 127L;
    long l5 = paramInt;
    l5 &= l4;
    long l6 = arrayOfByte[0] << 8;
    l6 &= l2;
    long l7 = l6 | l5;
    a(c.G.a(), l7, e.G.a(), d.G.a());
    l5 = arrayOfByte[1];
    l5 &= l3;
    l6 = arrayOfByte[2] << 8;
    l6 &= l2;
    long l8 = l6 | l5;
    a(c.H.a(), l8, e.H.a(), d.H.a());
    l5 = arrayOfByte[3];
    l5 &= l3;
    long l9 = l5;
    a(c.I.a(), l9, e.I.a(), d.I.a());
    a(c.L.a(), 0L, e.L.a(), d.L.a());
    a(c.L.a(), 1L, e.L.a(), d.L.a());
    b.info("writeASICRow method :: End");
  }
  
  private void o() throws a {
    b.info("resetTAIFController method :: Start");
    a(c.S.a(), 0L, e.S.a(), d.S.a());
    a(c.S.a(), 1L, e.S.a(), d.S.a());
    b.info("resetTAIFController method :: End");
  }
  
  private void p() throws a {
    byte[] arrayOfByte = a(g.b);
    arrayOfByte[1] = (byte)f.j.a();
    int i = cyDriver_dataOutTransfer(arrayOfByte.length, arrayOfByte.length, 1, arrayOfByte);
    if (i != b.a.a()) {
      b b1 = b.a(i);
      b.error("calling cyDriver_dataOutTransfer() has failed with error code " + b1);
      throw new a("calling cyDriver_dataOutTransfer() has failed with error code " + b1, b1);
    } 
  }
  
  private byte[] a(byte[] paramArrayOfByte) throws a {
    int i = cyDriver_getAsyncDataInErrorCode();
    if (i == b.a.a()) {
      b(paramArrayOfByte);
      b.info("Async data headers validations is finished");
      return c(paramArrayOfByte);
    } 
    b b1 = b.a(i);
    b.error("calling cyDriver_getAsyncDataInErrorCode() has failed with error code " + b1);
    throw new a("calling cyDriver_getAsyncDataInErrorCode() has failed with error code " + b1, b1);
  }
  
  private void b(byte[] paramArrayOfByte) throws a {
    byte b1 = 1;
    b.info("Data received from TAIF has length: " + paramArrayOfByte.length);
    d();
    for (byte b2 = 0; b2 < paramArrayOfByte.length; b2 += 512) {
      if (paramArrayOfByte[b2 + false] != (byte)g.c.a()) {
        b.error("Error in validating async in packets header, ASYNC_IN_PACKET_TYPE_ERROR index: " + b2);
        a(paramArrayOfByte, "errorStreamingBytes.txt");
        throw new a("Error in validating async in packets header, ASYNC_IN_PACKET_TYPE_ERROR index: " + b2, b.at);
      } 
      if (paramArrayOfByte[b2 + 1] != (byte)f.p.a()) {
        b.error("Error in validating async in packets header, ASYNC_IN_PACKET_ID_ERROR index: " + b2);
        a(paramArrayOfByte, "errorStreamingBytes.txt");
        throw new a("Error in validating async in packets header, ASYNC_IN_PACKET_ID_ERROR index: " + b2, b.au);
      } 
      byte[] arrayOfByte = a.a(b1);
      if (paramArrayOfByte[b2 + 2] != arrayOfByte[0] || paramArrayOfByte[b2 + 3] != arrayOfByte[1] || paramArrayOfByte[b2 + 4] != arrayOfByte[2]) {
        b.error("Error in validating async in packets header, ASYNC_IN_PACKET_INDEX_ERROR index: " + b2);
        a(paramArrayOfByte, "errorStreamingBytes.txt");
        throw new a("Error in validating async in packets header, ASYNC_IN_PACKET_INDEX_ERROR index: " + b2, b.av);
      } 
      if (paramArrayOfByte[b2 + 5] != 0) {
        if ((paramArrayOfByte[b2 + 5] & (byte)a.a.a()) != 0)
          b.error("Error in validating async in packets header, ASYNC_IN_EP2_FULL index: " + b2); 
        if ((paramArrayOfByte[b2 + 5] & (byte)a.b.a()) != 0) {
          b.error("Error in validating async in packets header, ASYNC_IN_FPGA_FIFO_FULL index: " + b2);
          a(paramArrayOfByte, "errorStreamingBytes.txt");
          throw new a(b.ax);
        } 
      } 
      b1++;
    } 
    if (a.h == true) {
      long[] arrayOfLong = c();
      a(arrayOfLong, "t_after_run.reg");
    } 
  }
  
  private void a(byte[] paramArrayOfByte, String paramString) {
    try {
      BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(this.a + File.separatorChar + "logs" + File.separatorChar + paramString));
      for (b1 = 0; b1 < paramArrayOfByte.length; b1++)
        bufferedWriter.write(paramArrayOfByte[b1] + "\n"); 
      bufferedWriter.close();
      try (FileOutputStream null = new FileOutputStream(this.a + File.separatorChar + "logs" + File.separatorChar + paramString + ".hex", true)) {
        fileOutputStream.write(paramArrayOfByte);
        fileOutputStream.close();
      } catch (IOException b1) {
        IOException iOException;
        iOException.printStackTrace();
      } 
    } catch (IOException iOException) {
      b.error(iOException.getMessage());
    } 
  }
  
  public void a(long[] paramArrayOfLong, String paramString) {
    try {
      BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(this.a + File.separatorChar + "logs" + File.separatorChar + paramString));
      for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++)
        bufferedWriter.write(Long.toHexString(paramArrayOfLong[b1]) + "\n"); 
      bufferedWriter.close();
    } catch (IOException iOException) {
      b.error(iOException.getMessage());
    } 
  }
  
  private byte[] c(byte[] paramArrayOfByte) throws a {
    byte b2 = 0;
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    for (byte b1 = 12; b2 < arrayOfByte.length && b1 < paramArrayOfByte.length; b1 += 12) {
      for (byte b3 = 0; b3 < 'Ǵ' && b2 < arrayOfByte.length; b3++)
        arrayOfByte[b2++] = paramArrayOfByte[b1++]; 
    } 
    return arrayOfByte;
  }
  
  static  {
    try {
      System.loadLibrary("cyDriver");
    } catch (Exception exception) {
      b.error("An exception is thrown while loading cyDriver library.", exception);
    } 
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\TAIFBoard.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */