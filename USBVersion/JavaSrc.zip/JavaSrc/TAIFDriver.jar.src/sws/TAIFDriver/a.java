package sws.TAIFDriver;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import org.apache.log4j.Logger;
import sws.TAIFDriver.a.a;
import sws.TAIFDriver.a.b;
import sws.TAIFDriver.a.c;
import sws.TAIFDriver.a.d;
import sws.TAIFDriver.a.e;
import sws.TAIFDriver.a.i;
import sws.TAIFDriver.a.j;
import sws.TAIFDriver.a.k;
import sws.TAIFDriver.b.a;
import sws.TAIFDriver.c.a;

public class a {
  private static Logger i = Logger.getLogger(a.class);
  
  private TAIFBoard j;
  
  public static boolean a = false;
  
  public static boolean b = false;
  
  public static boolean c = false;
  
  public static int d = 5;
  
  public static int e = 5;
  
  public static boolean f = false;
  
  public static boolean g = false;
  
  public static boolean h = false;
  
  private static int k = 1;
  
  private int l = 0;
  
  private int m = 0;
  
  public a(int paramInt) { this.j = new TAIFBoard(paramInt); }
  
  public a(int paramInt, String paramString) { this.j = new TAIFBoard(paramInt, paramString); }
  
  public void a(String paramString) { this.j.a = paramString; }
  
  public void a(boolean... paramVarArgs) throws a {
    i.info("initiateTAIF method :: Start");
    try {
      a();
      this.j.d();
    } catch (Exception exception) {}
    try {
      this.j.d();
    } catch (Exception exception) {}
    this.j.a(paramVarArgs);
    i.info("initiateTAIF method :: End");
  }
  
  public int a() throws a {
    i.info("checkBoardStatus method :: Start");
    int n = this.j.a();
    i.info("checkBoardStatus method :: End with status: " + n);
    return n;
  }
  
  public void a(long[] paramArrayOfLong) throws a {
    a(c.U.a(), 0L, e.U.a(), d.U.a());
    this.j.a(paramArrayOfLong);
    this.j.b(i.c.a(), 1L, k.c.a(), j.c.a());
    this.j.b(i.c.a(), 0L, k.c.a(), j.c.a());
    try {
      Thread.sleep(100L);
    } catch (InterruptedException interruptedException) {
      interruptedException.printStackTrace();
    } 
    a(c.U.a(), 1L, e.U.a(), d.U.a());
    try {
      Thread.sleep(100L);
    } catch (InterruptedException interruptedException) {
      interruptedException.printStackTrace();
    } 
  }
  
  public long[] b() throws a { return this.j.c(); }
  
  public long a(int paramInt1, int paramInt2, int paramInt3) throws a { return this.j.a(paramInt1, paramInt2, paramInt3); }
  
  public void a(int paramInt1, long paramLong, int paramInt2, int paramInt3) throws a { this.j.a(paramInt1, paramLong, paramInt2, paramInt3); }
  
  public void c() throws a { this.j.b(); }
  
  public byte[] a(int paramInt1, int paramInt2) throws a {
    int n = 512 * paramInt1;
    return this.j.c(n, paramInt2);
  }
  
  public long b(int paramInt1, int paramInt2, int paramInt3) throws a { return this.j.b(paramInt1, paramInt2, paramInt3); }
  
  public void b(int paramInt1, long paramLong, int paramInt2, int paramInt3) throws a { this.j.b(paramInt1, paramLong, paramInt2, paramInt3); }
  
  public long d() throws a {
    this.j.b(i.gY.a(), 0L, k.gY.a(), j.gY.a());
    this.j.b(i.u.a(), 0L, k.u.a(), j.u.a());
    this.j.b(i.bU.a(), 1L, k.bU.a(), j.bU.a());
    this.j.b(i.gX.a(), 1L, k.gX.a(), j.gX.a());
    this.j.b(i.eS.a(), 1L, k.eS.a(), j.eS.a());
    this.j.b(i.eR.a(), 1L, k.eR.a(), j.eR.a());
    try {
      Thread.sleep(30L);
    } catch (InterruptedException interruptedException) {
      i.error(interruptedException.getMessage());
    } 
    long l1 = this.j.b(i.gS.a(), k.gS.a(), j.gS.a());
    this.j.b(i.bU.a(), 0L, k.bU.a(), j.bU.a());
    this.j.b(i.u.a(), 1L, k.u.a(), j.u.a());
    return l1;
  }
  
  public String e() throws a, InterruptedException {
    i.info("TAIFDriver readROMID method :: Start");
    byte b1 = 8;
    byte b2 = this.j.a(b1);
    if (b2 >= 56)
      return "Error! ID isn't valid"; 
    byte[] arrayOfByte = this.j.a(b1 + 1, b2);
    i.info("TAIFDriver readROMID method :: END");
    return new String(arrayOfByte, Charset.forName("US-ASCII"));
  }
  
  public void a(byte[] paramArrayOfByte) throws a, InterruptedException {
    i.info("TAIFDriver writeROMID(byte[] value) :: Start");
    byte b1 = 8;
    if (paramArrayOfByte.length >= 56) {
      i.error("TAIFDriver WriteTAIFID(byte[] value) :: " + b.ae);
      throw new a("TAIFDriver WriteTAIFID(byte[] value) :: " + b.ae, b.ae);
    } 
    this.j.a(b1, (byte)paramArrayOfByte.length);
    this.j.a(b1 + 1, paramArrayOfByte.length, paramArrayOfByte);
    i.info("writeROMID method :: END");
  }
  
  public byte[] b(int paramInt1, int paramInt2) throws a {
    i.info("readROMData method :: Start");
    b b1 = b.a;
    if (64 + paramInt1 + paramInt2 > 65536) {
      b1 = b.ae;
      i.error("readTAIFData method :: Error : " + b1);
      throw new a("readTAIFData method :: Error : " + b1, b1);
    } 
    byte[] arrayOfByte = this.j.a(64 + paramInt1, paramInt2);
    i.info("readROMData method :: END");
    return arrayOfByte;
  }
  
  public void a(int paramInt1, int paramInt2, byte[] paramArrayOfByte) throws a, InterruptedException {
    i.info("writeROMData method :: Start");
    b b1 = b.a;
    if (64 + paramInt1 + paramInt2 > 65536) {
      b1 = b.ae;
      throw new a("Exception in writeTAIFData, error code: " + b1, b1);
    } 
    this.j.a(64 + paramInt1, paramInt2, paramArrayOfByte);
    i.info("writeROMData method :: End");
  }
  
  public void a(boolean paramBoolean1, boolean paramBoolean2, int paramInt) throws a {
    i.info("setupActuation method :: Start");
    if (paramBoolean2) {
      if (paramBoolean1) {
        this.j.b(i.cI.a(), 0L, k.cI.a(), j.cI.a());
        this.j.b(i.k.a(), 1L, k.k.a(), j.k.a());
        this.j.b(i.cX.a(), 1L, k.cX.a(), j.cX.a());
      } else {
        this.j.b(i.cI.a(), 0L, k.cI.a(), j.cI.a());
        this.j.b(i.k.a(), 1L, k.k.a(), j.k.a());
        this.j.b(i.cX.a(), 0L, k.cX.a(), j.cX.a());
      } 
    } else if (paramBoolean1) {
      this.j.b(i.cI.a(), 0L, k.cI.a(), j.cI.a());
      this.j.b(i.k.a(), 1L, k.k.a(), j.k.a());
      this.j.b(i.cX.a(), 0L, k.cX.a(), j.cX.a());
      this.j.b(i.da.a(), 0L, k.da.a(), j.da.a());
      this.j.b(i.k.a(), 0L, k.k.a(), j.k.a());
      this.j.b(i.cI.a(), 1L, k.cI.a(), j.cI.a());
      try {
        Thread.sleep(100L);
      } catch (InterruptedException interruptedException) {}
      this.j.b(i.da.a(), 1L, k.da.a(), j.da.a());
      long l1 = this.j.b(i.dj.a(), k.dj.a(), j.dj.a());
      this.j.b(i.dj.a(), l1 * paramInt, k.dj.a(), j.dj.a());
      try {
        Thread.sleep(500L);
      } catch (InterruptedException interruptedException) {}
      this.j.b(i.dj.a(), l1, k.dj.a(), j.dj.a());
    } else {
      this.j.b(i.cX.a(), 0L, k.cX.a(), j.cX.a());
      this.j.b(i.cI.a(), 0L, k.cI.a(), j.cI.a());
      this.j.b(i.k.a(), 1L, k.k.a(), j.k.a());
    } 
    i.info("setupActuation method :: End");
  }
  
  public boolean a(boolean paramBoolean) throws a {
    if (paramBoolean) {
      long l2 = this.j.b(i.cX.a(), k.cX.a(), j.cX.a());
      return (l2 == 1L);
    } 
    long l1 = this.j.b(i.k.a(), k.k.a(), j.k.a());
    return !(l1 == 1L);
  }
  
  public int[][] c(int paramInt1, int paramInt2, int paramInt3) throws a {
    i.info("streamInterpolation method :: Start");
    try {
      if (h == true) {
        long[] arrayOfLong = this.j.c();
        this.j.a(arrayOfLong, "t_before_run.reg");
      } 
      c(paramInt1, paramInt2);
      byte[] arrayOfByte = a(paramInt3);
      int[][] arrayOfInt = b(arrayOfByte);
      this.j.b();
      i.info("streamInterpolation method :: End");
      if (g == true) {
        File file = new File(this.j.a + File.separatorChar + String.valueOf(k));
        file.mkdirs();
        try {
          BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(this.j.a + File.separatorChar + String.valueOf(k) + File.separatorChar + "I1.txt"));
          byte b1;
          for (b1 = 0; b1 < arrayOfInt[0].length; b1++)
            bufferedWriter.write(arrayOfInt[0][b1] + "\n"); 
          bufferedWriter.close();
          bufferedWriter = new BufferedWriter(new FileWriter(this.j.a + File.separatorChar + String.valueOf(k) + File.separatorChar + "I2.txt"));
          for (b1 = 0; b1 < arrayOfInt[1].length; b1++)
            bufferedWriter.write(arrayOfInt[1][b1] + "\n"); 
          bufferedWriter.close();
        } catch (IOException iOException) {
          i.error(iOException.getMessage());
        } 
        k++;
      } 
      this.m = 0;
      return arrayOfInt;
    } catch (Exception exception) {
      i.error("An exception has occurred in streamInterpolation function.", exception);
      this.m++;
      if (this.m > e)
        throw new a(exception, b.ac); 
      int[][] arrayOfInt = c(paramInt1, paramInt2, paramInt3);
      this.m = 0;
      return arrayOfInt;
    } 
  }
  
  public int[][] d(int paramInt1, int paramInt2, int paramInt3) throws a {
    i.info("streamADCs method :: Start");
    try {
      int n = paramInt2 / 8;
      long l1 = (long)Math.ceil(n / 24.0D);
      a(paramInt1, l1);
      byte[] arrayOfByte = a(l1, paramInt3);
      int[][] arrayOfInt = a(arrayOfByte, paramInt2, paramInt1);
      this.j.b();
      i.info("streamADCs method :: End");
      this.l = 0;
      return arrayOfInt;
    } catch (Exception exception) {
      i.error("An exception has occurred in streamADCs function.", exception);
      this.l++;
      if (this.l > d)
        throw new a(exception, b.ac); 
      int[][] arrayOfInt = d(paramInt1, paramInt2, paramInt3);
      this.l = 0;
      return arrayOfInt;
    } 
  }
  
  public int[][] e(int paramInt1, int paramInt2, int paramInt3) throws a {
    i.info("streamActualDMUX method :: Start");
    int n = paramInt2 / 8;
    long l1 = (long)Math.ceil(n / 24.0D);
    b(paramInt1, l1);
    byte[] arrayOfByte = b(l1, paramInt3);
    int[][] arrayOfInt = b(arrayOfByte, paramInt2, paramInt1);
    this.j.b();
    i.info("streamActualDMUX method :: End");
    this.l = 0;
    return arrayOfInt;
  }
  
  public int f() throws a { return 89; }
  
  private void c(int paramInt1, int paramInt2) throws a {
    i.info("setupInterpolationRegisters method :: Start");
    this.j.b(i.cy.a(), 0L, k.cy.a(), j.cy.a());
    this.j.a(c.V.a(), 0L, e.V.a(), d.V.a());
    this.j.b(i.aX.a(), (paramInt1 - 1), k.aX.a(), j.aX.a());
    this.j.b(i.gu.a(), (paramInt1 - 1), k.gu.a(), j.gu.a());
    this.j.b(i.bk.a(), paramInt2, k.bk.a(), j.bk.a());
    this.j.b(i.gH.a(), paramInt2, k.gH.a(), j.gH.a());
    this.j.b(i.dA.a(), 0L, k.dA.a(), j.dA.a());
    this.j.b(i.dB.a(), 0L, k.dB.a(), j.dB.a());
    this.j.b(i.U.a(), 1L, k.U.a(), j.U.a());
    if (b == true)
      this.j.a(c.C.a(), 1L, e.C.a(), d.C.a()); 
    this.j.a(c.V.a(), 1L, e.V.a(), d.V.a());
    if (c == true) {
      long l1 = 0L;
      long l2 = 0L;
      l1 = this.j.b(i.aU.a(), k.aU.a(), j.aU.a());
      l2 = this.j.b(i.gr.a(), k.gr.a(), j.gr.a());
      this.j.b(i.aM.a(), 0L, k.aM.a(), j.aM.a());
      this.j.b(i.aM.a(), 1L, k.aM.a(), j.aM.a());
      this.j.b(i.aN.a(), 0L, k.aN.a(), j.aN.a());
      this.j.b(i.aN.a(), 1L, k.aN.a(), j.aN.a());
      do {
        if (l1 == 0L)
          l1 = this.j.b(i.aU.a(), k.aU.a(), j.aU.a()); 
        if (l2 != 0L)
          continue; 
        l2 = this.j.b(i.gr.a(), k.gr.a(), j.gr.a());
      } while (l1 == 0L || l2 == 0L);
      this.j.b(i.aL.a(), 1L, k.aL.a(), j.aL.a());
      this.j.b(i.gk.a(), 1L, k.gk.a(), j.gk.a());
      long l3 = 0L;
      long l4 = 0L;
      try {
        BufferedWriter bufferedWriter1 = new BufferedWriter(new FileWriter(this.j.a + File.separatorChar + "logs" + File.separatorChar + "streamingASIC_INT1.txt"));
        BufferedWriter bufferedWriter2 = new BufferedWriter(new FileWriter(this.j.a + File.separatorChar + "logs" + File.separatorChar + "streamingASIC_INT2.txt"));
        for (byte b1 = 0; b1 < 'က'; b1++) {
          l3 = this.j.b(i.aQ.a(), k.aQ.a(), j.aQ.a());
          l4 = this.j.b(i.gn.a(), k.gn.a(), j.gn.a());
          bufferedWriter1.write(l3 + "\n");
          bufferedWriter2.write(l4 + "\n");
        } 
        bufferedWriter1.close();
        bufferedWriter2.close();
      } catch (IOException iOException) {
        i.error(iOException.getMessage());
      } 
      l1 = this.j.b(i.aU.a(), k.aU.a(), j.aU.a());
      l2 = this.j.b(i.gr.a(), k.gr.a(), j.gr.a());
      long l5 = this.j.b(i.aI.a(), k.aI.a(), j.aI.a());
      long l6 = this.j.b(i.aJ.a(), k.aJ.a(), j.aJ.a());
      System.out.println("---I1_MASK_INT1_DRDY = " + l5);
      System.out.println("---I1_MASK_INT2_DRDY = " + l6);
      l5 = this.j.b(i.S.a(), k.S.a(), j.S.a());
      l6 = this.j.b(i.U.a(), k.U.a(), j.U.a());
      System.out.println("---I1_EN = " + l5);
      System.out.println("---I2_EN = " + l6);
      l5 = this.j.b(i.Z.a(), k.Z.a(), j.Z.a());
      System.out.println("---I1_source = " + l5);
    } 
    i.info("setupInterpolationRegisters method :: End");
  }
  
  private void a(int paramInt, long paramLong) throws a {
    i.info("setupADCsRegisters method :: Start");
    int n = 0;
    int i1 = 0;
    byte[] arrayOfByte1 = new byte[4];
    byte[] arrayOfByte2 = new byte[4];
    arrayOfByte1[2] = 0;
    arrayOfByte1[3] = 0;
    arrayOfByte2[2] = 0;
    arrayOfByte2[3] = 0;
    byte[] arrayOfByte3 = a.a(paramLong);
    if (arrayOfByte3.length > 0) {
      arrayOfByte1[0] = arrayOfByte3[0];
    } else {
      arrayOfByte1[0] = 0;
    } 
    if (arrayOfByte3.length > 1) {
      arrayOfByte1[1] = arrayOfByte3[1];
    } else {
      arrayOfByte1[1] = 0;
    } 
    if (arrayOfByte3.length > 2) {
      arrayOfByte2[0] = arrayOfByte3[2];
    } else {
      arrayOfByte2[0] = 0;
    } 
    if (arrayOfByte3.length > 3) {
      arrayOfByte2[1] = arrayOfByte3[3];
    } else {
      arrayOfByte2[1] = 0;
    } 
    ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte1);
    byteBuffer.order(ByteOrder.nativeOrder());
    n = byteBuffer.getInt(0);
    byteBuffer = ByteBuffer.wrap(arrayOfByte2);
    byteBuffer.order(ByteOrder.nativeOrder());
    i1 = byteBuffer.getInt(0);
    this.j.a(c.w.a(), 0L, e.w.a(), d.w.a());
    this.j.b(i.eQ.a(), 15L, k.eQ.a(), j.eQ.a());
    this.j.b(i.dD.a(), paramInt, k.dD.a(), j.dD.a());
    this.j.b(i.dA.a(), 1L, k.dA.a(), j.dA.a());
    this.j.b(i.dB.a(), 1L, k.dB.a(), j.dB.a());
    this.j.a(c.e.a(), i1, e.e.a(), d.e.a());
    this.j.a(c.f.a(), n, e.f.a(), d.f.a());
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "sampleRate" + File.separatorChar + "test.txt"));
      f = Boolean.parseBoolean(bufferedReader.readLine());
      bufferedReader.close();
    } catch (IOException iOException) {
      f = false;
    } 
    if (f == true) {
      System.out.println("Test mode = " + f);
      int i2 = 48;
      try {
        BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "sampleRate" + File.separatorChar + "rate.txt"));
        i2 = Integer.parseInt(bufferedReader.readLine());
        bufferedReader.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      System.out.println("Sample rate = " + i2);
      this.j.a(c.d.a(), 1L, e.d.a(), d.d.a());
      this.j.a(c.p.a(), i2, e.p.a(), d.p.a());
    } 
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "SPI" + File.separatorChar + "test.txt"));
      a = Boolean.parseBoolean(bufferedReader.readLine());
      bufferedReader.close();
    } catch (IOException iOException) {
      a = false;
    } 
    if (a == true) {
      try {
        long l1 = 0L;
        try {
          BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "SPI" + File.separatorChar + "count.txt"));
          l1 = Long.parseLong(bufferedReader.readLine());
          bufferedReader.close();
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
        BufferedWriter bufferedWriter1 = new BufferedWriter(new FileWriter("mems" + File.separatorChar + "SPI" + File.separatorChar + "Output_Log.txt", false));
        BufferedWriter bufferedWriter2 = new BufferedWriter(new FileWriter("mems" + File.separatorChar + "SPI" + File.separatorChar + "Output_Failure_Counts.txt", false));
        byte b1 = 0;
        long l2;
        for (l2 = 0L; l2 < l1; l2++) {
          long l3 = (long)(2.147483647E9D * Math.random());
          this.j.b(i.b.a(), l3, k.b.a(), j.b.a());
          long l4 = this.j.b(i.b.a(), k.b.a(), j.b.a());
          if (l3 != l4)
            bufferedWriter2.write("Error occurred at loop index " + l2 + ". total number of errors so far is " + ++b1 + "\n"); 
          bufferedWriter1.write("Current count is " + l2 + " out of " + l1 + ". value written is " + l3 + " and value read is " + l4 + ". total number of errors so far is " + b1 + "\n");
          System.out.println("Current count is " + l2 + " out of " + l1 + ". value written is " + l3 + " and value read is " + l4 + ". total number of errors so far is " + b1 + "\n");
        } 
        bufferedWriter1.close();
        bufferedWriter2.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      a = false;
    } 
    this.j.a(c.w.a(), 1L, e.w.a(), d.w.a());
    i.info("setupADCsRegisters method :: End");
  }
  
  private void b(int paramInt, long paramLong) throws a {
    i.info("setupActualDMuxRegisters method :: Start");
    int n = 0;
    int i1 = 0;
    byte[] arrayOfByte1 = new byte[4];
    byte[] arrayOfByte2 = new byte[4];
    arrayOfByte1[2] = 0;
    arrayOfByte1[3] = 0;
    arrayOfByte2[2] = 0;
    arrayOfByte2[3] = 0;
    byte[] arrayOfByte3 = a.a(paramLong);
    if (arrayOfByte3.length > 0) {
      arrayOfByte1[0] = arrayOfByte3[0];
    } else {
      arrayOfByte1[0] = 0;
    } 
    if (arrayOfByte3.length > 1) {
      arrayOfByte1[1] = arrayOfByte3[1];
    } else {
      arrayOfByte1[1] = 0;
    } 
    if (arrayOfByte3.length > 2) {
      arrayOfByte2[0] = arrayOfByte3[2];
    } else {
      arrayOfByte2[0] = 0;
    } 
    if (arrayOfByte3.length > 3) {
      arrayOfByte2[1] = arrayOfByte3[3];
    } else {
      arrayOfByte2[1] = 0;
    } 
    ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte1);
    byteBuffer.order(ByteOrder.nativeOrder());
    n = byteBuffer.getInt(0);
    byteBuffer = ByteBuffer.wrap(arrayOfByte2);
    byteBuffer.order(ByteOrder.nativeOrder());
    i1 = byteBuffer.getInt(0);
    this.j.a(c.v.a(), 0L, e.v.a(), d.v.a());
    this.j.b(i.eQ.a(), 15L, k.eQ.a(), j.eQ.a());
    this.j.b(i.dD.a(), paramInt, k.dD.a(), j.dD.a());
    this.j.b(i.dA.a(), 1L, k.dA.a(), j.dA.a());
    this.j.b(i.dB.a(), 1L, k.dB.a(), j.dB.a());
    this.j.a(c.e.a(), i1, e.e.a(), d.e.a());
    this.j.a(c.f.a(), n, e.f.a(), d.f.a());
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "sampleRate" + File.separatorChar + "test.txt"));
      f = Boolean.parseBoolean(bufferedReader.readLine());
      bufferedReader.close();
    } catch (IOException iOException) {
      f = false;
    } 
    if (f == true) {
      System.out.println("Test mode = " + f);
      int i2 = 48;
      try {
        BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "sampleRate" + File.separatorChar + "rate.txt"));
        i2 = Integer.parseInt(bufferedReader.readLine());
        bufferedReader.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      System.out.println("Sample rate = " + i2);
      this.j.a(c.d.a(), 1L, e.d.a(), d.d.a());
      this.j.a(c.p.a(), i2, e.p.a(), d.p.a());
    } 
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "SPI" + File.separatorChar + "test.txt"));
      a = Boolean.parseBoolean(bufferedReader.readLine());
      bufferedReader.close();
    } catch (IOException iOException) {
      a = false;
    } 
    if (a == true) {
      try {
        long l1 = 0L;
        try {
          BufferedReader bufferedReader = new BufferedReader(new FileReader("mems" + File.separatorChar + "SPI" + File.separatorChar + "count.txt"));
          l1 = Long.parseLong(bufferedReader.readLine());
          bufferedReader.close();
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
        BufferedWriter bufferedWriter1 = new BufferedWriter(new FileWriter("mems" + File.separatorChar + "SPI" + File.separatorChar + "Output_Log.txt", false));
        BufferedWriter bufferedWriter2 = new BufferedWriter(new FileWriter("mems" + File.separatorChar + "SPI" + File.separatorChar + "Output_Failure_Counts.txt", false));
        byte b1 = 0;
        long l2;
        for (l2 = 0L; l2 < l1; l2++) {
          long l3 = (long)(2.147483647E9D * Math.random());
          this.j.b(i.b.a(), l3, k.b.a(), j.b.a());
          long l4 = this.j.b(i.b.a(), k.b.a(), j.b.a());
          if (l3 != l4)
            bufferedWriter2.write("Error occurred at loop index " + l2 + ". total number of errors so far is " + ++b1 + "\n"); 
          bufferedWriter1.write("Current count is " + l2 + " out of " + l1 + ". value written is " + l3 + " and value read is " + l4 + ". total number of errors so far is " + b1 + "\n");
          System.out.println("Current count is " + l2 + " out of " + l1 + ". value written is " + l3 + " and value read is " + l4 + ". total number of errors so far is " + b1 + "\n");
        } 
        bufferedWriter1.close();
        bufferedWriter2.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
      a = false;
    } 
    this.j.a(c.v.a(), 1L, e.v.a(), d.v.a());
    i.info("setupActualDMuxRegisters method :: End");
  }
  
  private byte[] a(int paramInt) throws a {
    i.info("startStreamingInterpolation method :: Start");
    byte b1 = 50;
    i.info("async in packets count: " + b1);
    char c1 = b1 * 'Ȁ';
    i.info("asyncDataInLength " + c1);
    byte[] arrayOfByte = this.j.b(c1, paramInt);
    i.info("startStreamingInterpolation method :: End");
    return arrayOfByte;
  }
  
  private byte[] a(long paramLong, int paramInt) throws a {
    i.info("startStreamingADCs method :: Start");
    int n = (int)paramLong;
    i.info("async in packets count: " + n);
    int i1 = n * 512;
    i.info("asyncDataInLength " + i1);
    byte[] arrayOfByte = this.j.d(i1, paramInt);
    i.info("startStreamingADCs method :: End");
    return arrayOfByte;
  }
  
  private byte[] b(long paramLong, int paramInt) throws a {
    i.info("startStreamingADCs method :: Start");
    int n = (int)paramLong;
    i.info("async in packets count: " + n);
    int i1 = n * 512;
    i.info("asyncDataInLength " + i1);
    byte[] arrayOfByte = this.j.e(i1, paramInt);
    i.info("startStreamingADCs method :: End");
    return arrayOfByte;
  }
  
  private int[][] b(byte[] paramArrayOfByte) throws a {
    i.info("changeByteToSampleInterpolation method :: Start");
    byte[] arrayOfByte = new byte[4];
    byte b1 = 0;
    int[][] arrayOfInt = new int[2][];
    arrayOfInt[0] = new int[4096];
    arrayOfInt[1] = new int[4096];
    try {
      BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(this.j.a + File.separatorChar + "logs" + File.separatorChar + "packets_raw_data.txt"));
      for (byte b2 = 0; b2 < paramArrayOfByte.length; b2++)
        bufferedWriter.write(paramArrayOfByte[b2] + " \n"); 
      bufferedWriter.close();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    char c1;
    for (c1 = Character.MIN_VALUE; b1 < arrayOfInt[0].length && c1 < paramArrayOfByte.length / 2; c1++) {
      byte b2;
      for (b2 = 0; b1 < arrayOfInt[0].length && b2 < 164; b2++) {
        arrayOfByte[3] = paramArrayOfByte[c1++];
        arrayOfByte[2] = paramArrayOfByte[c1++];
        arrayOfByte[1] = paramArrayOfByte[c1++];
        arrayOfByte[0] = 0;
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
        byteBuffer.order(ByteOrder.nativeOrder());
        arrayOfInt[0][b1++] = byteBuffer.getInt(0) >> 8;
      } 
      if (b1 == arrayOfInt[0].length) {
        for (b2 = 0; b2 < 18; b2++)
          c1++; 
      } else {
        for (b2 = 0; b2 < 6; b2++)
          c1++; 
      } 
      b2 = paramArrayOfByte[c1++];
      if (!b) {
        if ((b2 & (byte)a.a.a()) != 0)
          i.error("I2_STAT_INT1_END_TIMEOUT in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.a.a())); 
        if ((b2 & (byte)a.b.a()) != 0)
          i.error("I2_STAT_INT1_END_INVALID in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.b.a())); 
        if ((b2 & (byte)a.c.a()) != 0)
          i.error("I2_STAT_INT1_AVG_OVERFLOW in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.c.a())); 
        if ((b2 & (byte)a.d.a()) != 0)
          i.error("I2_STAT_INT1_CORE_INVALID_REGION in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.d.a())); 
        if ((b2 & (byte)a.e.a()) != 0)
          i.error("I2_STAT_INT1_CORE_TIMEOUT in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.e.a())); 
        if ((b2 & (byte)a.f.a()) != 0)
          i.error("I2_STAT_INT1_CORE_OVERFLOW in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.f.a())); 
        if ((b2 & (byte)a.g.a()) != 0)
          i.error("I2_STAT_INT1_START_TIMEOUT in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.g.a())); 
        if ((b2 & (byte)a.h.a()) != 0) {
          i.error("I2_STAT_INT1_RUN_FAILED in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.h.a()));
          long[] arrayOfLong = this.j.c();
          this.j.a(arrayOfLong, "t_after_error.reg");
          throw new a(b.aI);
        } 
      } 
    } 
    b1 = 0;
    c1 = 'ピ';
    while (b1 < arrayOfInt[1].length && c1 < paramArrayOfByte.length) {
      byte b2;
      for (b2 = 0; b1 < arrayOfInt[1].length && b2 < 164; b2++) {
        arrayOfByte[3] = paramArrayOfByte[c1++];
        arrayOfByte[2] = paramArrayOfByte[c1++];
        arrayOfByte[1] = paramArrayOfByte[c1++];
        arrayOfByte[0] = 0;
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
        byteBuffer.order(ByteOrder.nativeOrder());
        arrayOfInt[1][b1++] = byteBuffer.getInt(0) >> 8;
      } 
      if (b1 == arrayOfInt[1].length) {
        for (b2 = 0; b2 < 18; b2++)
          c1++; 
      } else {
        for (b2 = 0; b2 < 6; b2++)
          c1++; 
      } 
      c1++;
      b2 = paramArrayOfByte[++c1];
      if (!b) {
        if ((b2 & (byte)a.a.a()) != 0)
          i.error("I2_STAT_INT2_END_TIMEOUT in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.a.a())); 
        if ((b2 & (byte)a.b.a()) != 0)
          i.error("I2_STAT_INT2_END_INVALID in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.b.a())); 
        if ((b2 & (byte)a.c.a()) != 0)
          i.error("I2_STAT_INT2_AVG_OVERFLOW in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.c.a())); 
        if ((b2 & (byte)a.d.a()) != 0)
          i.error("I2_STAT_INT2_CORE_INVALID_REGION in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.d.a())); 
        if ((b2 & (byte)a.e.a()) != 0)
          i.error("I2_STAT_INT2_CORE_TIMEOUT in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.e.a())); 
        if ((b2 & (byte)a.f.a()) != 0)
          i.error("I2_STAT_INT2_CORE_OVERFLOW in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.f.a())); 
        if ((b2 & (byte)a.g.a()) != 0)
          i.error("I2_STAT_INT2_START_TIMEOUT in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.g.a())); 
        if ((b2 & (byte)a.h.a()) != 0) {
          i.error("I2_STAT_INT2_RUN_FAILED in sample no. " + (b1 - 1) + "-- original value: " + (b2 & (byte)a.h.a()));
          long[] arrayOfLong = this.j.c();
          this.j.a(arrayOfLong, "t_after_error.reg");
          throw new a(b.aQ);
        } 
      } 
    } 
    i.info("changeByteToSampleInterpolation method :: END");
    return arrayOfInt;
  }
  
  private int[][] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws a {
    i.info("changeByteToSampleADCs method :: Start");
    byte[] arrayOfByte = new byte[4];
    byte b1 = 0;
    byte b2 = 0;
    byte b3 = 0;
    int n = paramInt1 / 8;
    int i1 = n * 8 + n * 1 + n * 1;
    int[][] arrayOfInt = new int[3][];
    arrayOfInt[0] = new int[n * 1];
    arrayOfInt[1] = new int[n * 1];
    arrayOfInt[2] = new int[n * 8];
    for (byte b4 = 0; b1 + b2 + b3 < i1 && b4 < paramArrayOfByte.length; b4 += 20) {
      for (byte b5 = 0; b5 < 24 && b1 + b2 + b3 < i1; b5++) {
        if (paramInt2 == 15) {
          byte b7;
          for (b7 = 0; b7 < 1; b7++) {
            arrayOfByte[3] = paramArrayOfByte[b4++];
            arrayOfByte[2] = paramArrayOfByte[b4++];
            arrayOfByte[1] = 0;
            arrayOfByte[0] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[0][b1++] = byteBuffer.getInt(0) >> 16;
          } 
          for (b7 = 0; b7 < 1; b7++) {
            arrayOfByte[3] = paramArrayOfByte[b4++];
            arrayOfByte[2] = paramArrayOfByte[b4++];
            arrayOfByte[1] = 0;
            arrayOfByte[0] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[1][b2++] = byteBuffer.getInt(0) >> 16;
          } 
        } else {
          byte b7;
          for (b7 = 0; b7 < 1; b7++) {
            arrayOfByte[3] = paramArrayOfByte[b4++];
            arrayOfByte[2] = paramArrayOfByte[b4++];
            arrayOfByte[1] = paramArrayOfByte[b4++];
            arrayOfByte[0] = paramArrayOfByte[b4++];
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[0][b1++] = byteBuffer.getInt(0);
          } 
          for (b7 = 0; b7 < 1; b7++) {
            arrayOfByte[3] = 0;
            arrayOfByte[2] = 0;
            arrayOfByte[1] = 0;
            arrayOfByte[0] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[1][b2++] = byteBuffer.getInt(0);
          } 
        } 
        for (byte b6 = 0; b6 < 8; b6++) {
          arrayOfByte[3] = paramArrayOfByte[b4++];
          arrayOfByte[2] = paramArrayOfByte[b4++];
          arrayOfByte[1] = 0;
          arrayOfByte[0] = 0;
          ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
          byteBuffer.order(ByteOrder.nativeOrder());
          arrayOfInt[2][b3++] = byteBuffer.getInt(0) >> 16;
        } 
      } 
    } 
    i.info("changeByteToSampleADCs method :: END");
    return arrayOfInt;
  }
  
  private int[][] b(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws a {
    i.info("changeByteToSampleActualDMux method :: Start");
    byte[] arrayOfByte = new byte[4];
    byte b1 = 0;
    byte b2 = 0;
    byte b3 = 0;
    int n = paramInt1 / 8;
    int i1 = n * 8 + n * 1 + n * 1;
    int[][] arrayOfInt = new int[2][];
    arrayOfInt[0] = new int[n * 1];
    arrayOfInt[1] = new int[n * 1];
    for (byte b4 = 0; b1 + b2 + b3 < i1 && b4 < paramArrayOfByte.length; b4 += 8) {
      for (byte b5 = 0; b5 < 82 && b1 + b2 + b3 < i1; b5++) {
        if (paramInt2 == 15) {
          byte b6;
          for (b6 = 0; b6 < 1; b6++) {
            arrayOfByte[3] = paramArrayOfByte[b4++];
            arrayOfByte[2] = paramArrayOfByte[b4++];
            arrayOfByte[1] = 0;
            arrayOfByte[0] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[0][b1++] = byteBuffer.getInt(0) >> 16;
          } 
          for (b6 = 0; b6 < 1; b6++) {
            arrayOfByte[3] = paramArrayOfByte[b4++];
            arrayOfByte[2] = paramArrayOfByte[b4++];
            arrayOfByte[1] = 0;
            arrayOfByte[0] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[1][b2++] = byteBuffer.getInt(0) >> 16;
          } 
        } else {
          byte b6;
          for (b6 = 0; b6 < 1; b6++) {
            arrayOfByte[3] = paramArrayOfByte[b4++];
            arrayOfByte[2] = paramArrayOfByte[b4++];
            arrayOfByte[1] = paramArrayOfByte[b4++];
            arrayOfByte[0] = paramArrayOfByte[b4++];
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[0][b1++] = byteBuffer.getInt(0);
          } 
          for (b6 = 0; b6 < 1; b6++) {
            arrayOfByte[3] = 0;
            arrayOfByte[2] = 0;
            arrayOfByte[1] = 0;
            arrayOfByte[0] = 0;
            ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            arrayOfInt[1][b2++] = byteBuffer.getInt(0);
          } 
        } 
        b4++;
        b4++;
        b3++;
        b3++;
      } 
    } 
    i.info("changeByteToSampleActualDMux method :: END");
    return arrayOfInt;
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */