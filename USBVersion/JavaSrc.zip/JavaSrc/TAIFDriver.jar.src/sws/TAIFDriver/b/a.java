package sws.TAIFDriver.b;

import sws.TAIFDriver.a.b;

public class a extends Exception {
  private static final long a = -5771960360292389271L;
  
  private b b;
  
  public a() {}
  
  public a(b paramb) { this.b = paramb; }
  
  public a(Throwable paramThrowable, b paramb) {
    super(paramThrowable);
    this.b = paramb;
  }
  
  public a(String paramString) { super(paramString); }
  
  public a(String paramString, b paramb) {
    super(paramString);
    this.b = paramb;
  }
  
  public b a() { return this.b; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\b\a.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */