package sws.TAIFDriver.a;

public static enum g {
  a(0),
  b(16),
  c(17);
  
  private int d;
  
  g(int paramInt1) { this.d = paramInt1; }
  
  public int a() { return this.d; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\g.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */