package sws.TAIFDriver.a;

public static enum a {
  a(1),
  b(2),
  c(4),
  d(8),
  e(16),
  f(32),
  g(64),
  h(128),
  i(0);
  
  private int j;
  
  a(int paramInt1) { this.j = paramInt1; }
  
  public int a() { return this.j; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\a.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */