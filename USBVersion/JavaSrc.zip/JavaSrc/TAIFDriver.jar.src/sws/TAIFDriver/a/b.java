package sws.TAIFDriver.a;

public static enum b {
  a(0),
  b(1),
  c(10),
  d(11),
  e(12),
  f(13),
  g(14),
  h(15),
  i(16),
  j(17),
  k(18),
  l(19),
  m(20),
  n(21),
  o(22),
  p(30),
  q(31),
  r(32),
  s(33),
  t(34),
  u(35),
  v(36),
  w(37),
  x(38),
  y(39),
  z(40),
  A(41),
  B(45),
  C(46),
  D(47),
  E(48),
  F(49),
  G(50),
  H(51),
  I(52),
  J(53),
  K(54),
  L(55),
  M(56),
  N(57),
  O(58),
  P(59),
  Q(60),
  R(61),
  S(65),
  T(66),
  U(67),
  V(68),
  W(70),
  X(71),
  Y(72),
  Z(73),
  aa(74),
  ab(200),
  ac(201),
  ad(202),
  ae(203),
  af(204),
  ag(205),
  ah(206),
  ai(207),
  aj(208),
  ak(209),
  al(210),
  am(211),
  an(212),
  ao(213),
  ap(214),
  aq(215),
  ar(216),
  as(217),
  at(218),
  au(219),
  av(220),
  aw(221),
  ax(222),
  ay(223),
  az(224),
  aA(225),
  aB(226),
  aC(227),
  aD(228),
  aE(229),
  aF(230),
  aG(231),
  aH(232),
  aI(233),
  aJ(234),
  aK(235),
  aL(236),
  aM(237),
  aN(238),
  aO(239),
  aP(240),
  aQ(241);
  
  private int aR;
  
  b(int paramInt1) { this.aR = paramInt1; }
  
  public int a() { return this.aR; }
  
  public static b a(int paramInt) {
    for (b b1 : values()) {
      if (b1.aR == paramInt)
        return b1; 
    } 
    return null;
  }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\b.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */