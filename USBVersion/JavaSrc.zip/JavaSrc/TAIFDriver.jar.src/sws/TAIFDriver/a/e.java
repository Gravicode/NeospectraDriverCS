package sws.TAIFDriver.a;

public static enum e {
  a(8),
  b(1),
  c(9),
  d(1),
  e(8),
  f(16),
  g(8),
  h(16),
  i(8),
  j(1),
  k(1),
  l(1),
  m(1),
  n(1),
  o(1),
  p(14),
  q(8),
  r(1),
  s(1),
  t(1),
  u(1),
  v(1),
  w(1),
  x(1),
  y(1),
  z(1),
  A(1),
  B(1),
  C(1),
  D(1),
  E(1),
  F(1),
  G(16),
  H(16),
  I(16),
  J(16),
  K(16),
  L(1),
  M(16),
  N(16),
  O(16),
  P(16),
  Q(16),
  R(1),
  S(1),
  T(1),
  U(1),
  V(1),
  W(3),
  X(16),
  Y(16),
  Z(9),
  aa(8),
  ab(16),
  ac(16),
  ad(16),
  ae(16),
  af(16),
  ag(4),
  ah(16),
  ai(16),
  aj(16),
  ak(16),
  al(16),
  am(16),
  an(7),
  ao(2),
  ap(16),
  aq(2),
  ar(2),
  as(2),
  at(2);
  
  private int au;
  
  e(int paramInt1) { this.au = paramInt1; }
  
  public int a() { return this.au; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\e.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */