package sws.TAIFDriver.a;

public static enum d {
  a(0),
  b(0),
  c(0),
  d(0),
  e(0),
  f(0),
  g(0),
  h(0),
  i(0),
  j(0),
  k(1),
  l(2),
  m(3),
  n(4),
  o(5),
  p(0),
  q(0),
  r(0),
  s(1),
  t(2),
  u(3),
  v(4),
  w(5),
  x(6),
  y(7),
  z(8),
  A(9),
  B(0),
  C(1),
  D(2),
  E(3),
  F(0),
  G(0),
  H(0),
  I(0),
  J(0),
  K(0),
  L(0),
  M(0),
  N(0),
  O(0),
  P(0),
  Q(0),
  R(0),
  S(0),
  T(1),
  U(2),
  V(0),
  W(0),
  X(0),
  Y(0),
  Z(0),
  aa(0),
  ab(0),
  ac(0),
  ad(0),
  ae(0),
  af(0),
  ag(0),
  ah(0),
  ai(0),
  aj(0),
  ak(0),
  al(0),
  am(0),
  an(0),
  ao(0),
  ap(0),
  aq(0),
  ar(0),
  as(0),
  at(0);
  
  private int au;
  
  d(int paramInt1) { this.au = paramInt1; }
  
  public int a() { return this.au; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\d.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */