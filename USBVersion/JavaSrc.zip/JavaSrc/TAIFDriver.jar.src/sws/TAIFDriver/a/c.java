package sws.TAIFDriver.a;

public static enum c {
  a(0),
  b(1),
  c(2),
  d(3),
  e(4),
  f(5),
  g(6),
  h(7),
  i(8),
  j(9),
  k(9),
  l(9),
  m(9),
  n(9),
  o(9),
  p(10),
  q(11),
  r(12),
  s(12),
  t(12),
  u(12),
  v(12),
  w(12),
  x(12),
  y(12),
  z(12),
  A(12),
  B(13),
  C(13),
  D(13),
  E(13),
  F(14),
  G(15),
  H(16),
  I(17),
  J(18),
  K(19),
  L(20),
  M(21),
  N(22),
  O(23),
  P(24),
  Q(25),
  R(26),
  S(27),
  T(27),
  U(27),
  V(28),
  W(29),
  X(30),
  Y(31),
  Z(32),
  aa(33),
  ab(34),
  ac(35),
  ad(36),
  ae(37),
  af(38),
  ag(39),
  ah(40),
  ai(41),
  aj(42),
  ak(43),
  al(44),
  am(45),
  an(46),
  ao(47),
  ap(48),
  aq(49),
  ar(50),
  as(51),
  at(52);
  
  private int au;
  
  c(int paramInt1) { this.au = paramInt1; }
  
  public int a() { return this.au; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\c.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */