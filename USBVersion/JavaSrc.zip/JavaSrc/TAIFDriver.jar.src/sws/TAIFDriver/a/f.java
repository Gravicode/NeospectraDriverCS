package sws.TAIFDriver.a;

public static enum f {
  a(1),
  b(2),
  c(3),
  d(16),
  e(17),
  f(32),
  g(48),
  h(49),
  i(96),
  j(1),
  k(2),
  l(16),
  m(17),
  n(64),
  o(80),
  p(96);
  
  private int q;
  
  f(int paramInt1) { this.q = paramInt1; }
  
  public int a() { return this.q; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\f.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */