package sws.TAIFDriver.a;

public static enum h {
  a(1),
  b(0);
  
  private int c;
  
  h(int paramInt1) { this.c = paramInt1; }
  
  public int a() { return this.c; }
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\a\h.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */