package sws.TAIFDriver.c;

public class c {
  public static final int a = 89;
  
  public static final byte b = 3;
  
  public static final int c = 1;
  
  public static final int d = 1;
  
  public static final int e = 8;
  
  public static final int f = 1;
  
  public static final int g = 1;
  
  public static final int h = 1;
  
  public static final int i = 50;
  
  public static final int j = 4096;
  
  public static final int k = 164;
  
  public static final int l = 20;
  
  public static final int m = 6;
  
  public static final int n = 6;
  
  public static final int o = 18;
  
  public static final int p = 24;
  
  public static final int q = 82;
  
  public static final int r = 1;
  
  public static final int s = 8;
  
  public static final int t = 64;
  
  public static final int u = 65408;
  
  public static final int v = 464196;
  
  public static final int w = 169216;
  
  public static final int x = 10;
  
  public static final int y = 5000;
  
  public static final int z = (int)(9.6D * Math.pow(10.0D, 3.0D) / 4.0D);
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\c\c.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */