package sws.TAIFDriver.c;

public class b {
  public static final int a = 64;
  
  public static final int b = 512;
  
  public static final int c = 512;
  
  public static final int d = 50;
  
  public static final int e = 3;
  
  public static final int f = 12;
  
  public static final int g = 0;
  
  public static final int h = 500;
  
  public static final int i = 500;
  
  public static final int j = 1;
  
  public static final int k = 65536;
  
  public static final int l = 32;
}


/* Location:              D:\jobs\BalitTanah.SoilSensingKit\Decompile Driver\SDK v4.3\SDKv4.3\bin_win_x64\TAIFDriver.jar!\sws\TAIFDriver\c\b.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */